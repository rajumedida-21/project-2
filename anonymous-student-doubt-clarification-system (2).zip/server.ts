import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import mammoth from 'mammoth';
import * as pdfModule from 'pdf-parse';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '35mb' }));

// ----------------------------------------------------
// AI Client & Helpers
// ----------------------------------------------------
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not configured on the server.');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Deterministic fallback vector if API quota/network issues occur
function generateDeterministicVector(text: string, dimensions = 64): number[] {
  const vec = new Array(dimensions).fill(0);
  const words = text.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/);
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    if (!word) continue;
    let hash = 0;
    for (let j = 0; j < word.length; j++) {
      hash = (hash << 5) - hash + word.charCodeAt(j);
      hash |= 0;
    }
    const idx = Math.abs(hash) % dimensions;
    vec[idx] += 1;
  }
  let norm = 0;
  for (const v of vec) norm += v * v;
  if (norm > 0) {
    const sqrtNorm = Math.sqrt(norm);
    for (let i = 0; i < dimensions; i++) vec[i] /= sqrtNorm;
  }
  return vec;
}

async function getEmbedding(text: string): Promise<number[]> {
  try {
    const ai = getAI();
    const res = await ai.models.embedContent({
      model: 'gemini-embedding-2-preview',
      contents: text.substring(0, 2048),
    });
    const values = (res as any).embeddings?.[0]?.values || (res as any).embedding?.values;
    if (Array.isArray(values) && values.length > 0) {
      return values;
    }
  } catch (err) {
    console.warn('Primary embedding call failed, trying text-embedding-004 fallback:', err);
    try {
      const ai = getAI();
      const res = await ai.models.embedContent({
        model: 'text-embedding-004',
        contents: text.substring(0, 2048),
      });
      const values = (res as any).embeddings?.[0]?.values || (res as any).embedding?.values;
      if (Array.isArray(values) && values.length > 0) {
        return values;
      }
    } catch (err2) {
      console.warn('Fallback embedding model also failed:', err2);
    }
  }
  return generateDeterministicVector(text, 64);
}

function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length === 0 || vecB.length === 0) return 0;
  const len = Math.min(vecA.length, vecB.length);
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < len; i++) {
    dot += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

// Semantic text chunker (600-900 chars with 120-char overlap)
function chunkText(
  text: string,
  chunkSize = 800,
  overlap = 120
): Array<{ chunkIndex: number; content: string; pageOrSection: string }> {
  const clean = text.replace(/\r\n/g, '\n').trim();
  if (!clean) return [];

  const paragraphs = clean.split(/\n\s*\n/);
  const chunks: Array<{ chunkIndex: number; content: string; pageOrSection: string }> = [];
  let currentChunk = '';
  let chunkIdx = 0;

  for (const para of paragraphs) {
    const trimmed = para.trim();
    if (!trimmed) continue;

    if ((currentChunk.length + trimmed.length) <= chunkSize) {
      currentChunk += (currentChunk ? '\n\n' : '') + trimmed;
    } else {
      if (currentChunk) {
        chunks.push({
          chunkIndex: chunkIdx++,
          content: currentChunk.trim(),
          pageOrSection: `Section ${chunkIdx}`,
        });
        const words = currentChunk.split(/\s+/);
        const overlapCount = Math.min(words.length, Math.max(5, Math.floor(overlap / 7)));
        const overlapWords = words.slice(-overlapCount).join(' ');
        currentChunk = overlapWords + '\n\n' + trimmed;
      } else {
        let remaining = trimmed;
        while (remaining.length > chunkSize) {
          const slice = remaining.substring(0, chunkSize);
          const lastPeriod = Math.max(slice.lastIndexOf('. '), slice.lastIndexOf('.\n'));
          const splitPoint = lastPeriod > chunkSize * 0.4 ? lastPeriod + 1 : chunkSize;
          chunks.push({
            chunkIndex: chunkIdx++,
            content: remaining.substring(0, splitPoint).trim(),
            pageOrSection: `Section ${chunkIdx}`,
          });
          remaining = remaining.substring(splitPoint).trim();
        }
        currentChunk = remaining;
      }
    }
  }

  if (currentChunk.trim()) {
    chunks.push({
      chunkIndex: chunkIdx++,
      content: currentChunk.trim(),
      pageOrSection: `Section ${chunkIdx}`,
    });
  }

  return chunks;
}

async function extractTextFromPDF(buffer: Buffer): Promise<string> {
  try {
    const PDFParse = (pdfModule as any).PDFParse || (pdfModule as any).default?.PDFParse;
    if (PDFParse) {
      const parser = new PDFParse({ data: buffer });
      if (typeof parser.load === 'function') {
        await parser.load();
      }
      if (typeof parser.getText === 'function') {
        const textResult = await parser.getText();
        if (typeof textResult === 'string' && textResult.trim()) return textResult.trim();
        if (textResult?.text && typeof textResult.text === 'string') return textResult.text.trim();
      }
    }
  } catch (e1) {
    console.warn('PDFParse class attempt failed:', e1);
  }

  try {
    const fn = (pdfModule as any).default || pdfModule;
    if (typeof fn === 'function') {
      const data = await fn(buffer);
      if (data?.text) return data.text.trim();
    }
  } catch (e2) {
    console.warn('Legacy pdf-parse function failed:', e2);
  }

  // Graceful fallback for non-encrypted text chunks in PDF stream
  const rawStr = buffer.toString('binary');
  const matches = rawStr.match(/[a-zA-Z0-9.,;:?!'"()-_/\s]{6,}/g);
  if (matches && matches.length > 5) {
    return matches.slice(0, 1000).join(' ');
  }
  return 'Unable to extract clean text from this PDF. Please ensure the PDF is not password protected.';
}

// ----------------------------------------------------
// AI Endpoint 1: AI Doubt Assistant & Teaching Chat (Multimodal)
// ----------------------------------------------------
app.post('/api/ai/doubt-assistant', async (req, res) => {
  try {
    const {
      message,
      image = null,
      conversationHistory = [],
      actionType = 'normal',
      subject = '',
      language = 'English',
    } = req.body;

    if (!message && !image) {
      return res.status(400).json({ error: 'Message or image is required' });
    }

    const ai = getAI();

    let systemInstruction = `You are a dedicated, encouraging Academic AI Tutor on the Anonymous Student Learning & Doubt Clarification Platform.
You have full multimodal vision capabilities and can understand textbook photos, mathematics problems, handwritten questions, diagrams, flowcharts, circuit schematics, programming screenshots, and compiler error logs.
Your purpose is to TEACH and foster deep conceptual mastery, rather than simply handing over raw answers.
Subject context: ${subject || 'General Academic & STEM'}

Follow this pedagogical guideline:
For conceptual & academic questions:
1. Understand the Question: Paraphrase the core doubt briefly so the student knows you understood.
2. Simple Explanation: Explain the concept in clear, intuitive, jargon-free language.
3. Step-by-Step Reasoning: Break down how and why it works logically.
4. Concrete Example: Provide a clear code example, math formula, or real-life analogy.
5. Common Mistakes: Highlight a frequent pitfall or misconception students run into.
6. Practice Question: Give a quick, fun 1-question check to verify their understanding.

When an image is provided:
For mathematics / scientific equations:
- 1. Identify the problem and transcribe the equations/variables clearly.
- 2. Explain what is being asked in plain terms.
- 3. Solve it step-by-step with clear algebraic or logical steps.
- 4. Explain the underlying theorem, concept, or formula.
- 5. Provide a similar practice question with an answer check.

For programming screenshots or compiler errors:
- 1. Identify the language and transcribe the relevant code snippet.
- 2. Pinpoint the exact bug or compiler error message.
- 3. Explain the underlying root cause.
- 4. Suggest the clean, corrected code with comments.
- 5. Explain why the correction works.

For diagrams or flowcharts:
- 1. Identify the components, flow direction, and relationships.
- 2. Explain the overall process step by step.

If the image is blurry, cropped, or illegible:
- Kindly and specifically tell the student that the image is difficult to read, indicate what part is unclear, and ask for a clearer photo or typed text.

Use Markdown formatting: headings (###), bullet points, bolding for emphasis, and formatted code blocks (\`\`\`language).
Keep your tone supportive, academic, professional, and empowering.`;

    if (actionType === 'simpler') {
      systemInstruction += `\n\nCRITICAL MODIFIER: The student clicked "Explain simpler". Explain the previous concept using an everyday analogy or kindergarten-level clarity with zero intimidating jargon.`;
    } else if (actionType === 'example') {
      systemInstruction += `\n\nCRITICAL MODIFIER: The student clicked "Give an example". Provide a practical, concrete, real-world scenario or code walkthrough demonstrating the concept in action.`;
    } else if (actionType === 'hint') {
      systemInstruction += `\n\nCRITICAL MODIFIER: The student clicked "Give me a hint". Do NOT give the full answer. Provide a guiding nudge, clue, or question that helps them discover the solution themselves.`;
    } else if (actionType === 'solution') {
      systemInstruction += `\n\nCRITICAL MODIFIER: The student clicked "Show solution". Provide the complete, fully explained, step-by-step master solution with verification.`;
    } else if (actionType === 'practice_question') {
      systemInstruction += `\n\nCRITICAL MODIFIER: The student clicked "Give practice question". Generate a tailored practice problem related to the current topic with a hidden spoiler/hint.`;
    }

    // Prepare contents
    const contents: any[] = [];
    if (Array.isArray(conversationHistory) && conversationHistory.length > 0) {
      for (const item of conversationHistory.slice(-6)) {
        if (item.role === 'user' || item.role === 'model') {
          contents.push({
            role: item.role,
            parts: [{ text: item.content || item.text || '' }],
          });
        }
      }
    }

    const currentParts: any[] = [];
    if (image) {
      let mimeType = 'image/jpeg';
      let base64Data = '';
      if (typeof image === 'string' && image.startsWith('data:')) {
        const match = image.match(/^data:(image\/[a-zA-Z0-9+.-]+);base64,(.+)$/);
        if (match) {
          mimeType = match[1];
          base64Data = match[2];
        }
      } else if (typeof image === 'object' && image.data) {
        mimeType = image.mimeType || 'image/jpeg';
        base64Data = image.data;
      }
      if (base64Data) {
        currentParts.push({
          inlineData: {
            mimeType,
            data: base64Data,
          },
        });
      }
    }

    currentParts.push({ text: message || 'Please analyze this image and explain the problem step by step.' });

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'I could not generate an answer at this time.';
    res.json({ reply });
  } catch (err: any) {
    console.error('Error in /api/ai/doubt-assistant:', err);
    res.status(500).json({
      error: 'AI is temporarily unavailable. Please try again.',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 2: AI Study Advisor (Personalized Plan)
// ----------------------------------------------------
app.post('/api/ai/study-plan', async (req, res) => {
  try {
    const {
      subjects = [],
      topics = '',
      examDate = '',
      hoursPerDay = 3,
      knowledgeLevel = 'Intermediate',
      strongSubjects = '',
      weakSubjects = '',
      preferredTime = 'Evening',
      dailyGoal = '',
    } = req.body;

    const ai = getAI();

    const prompt = `Act as an expert Academic Study Strategist. Create a realistic, personalized, high-yield study plan based on this student profile:
- Target Subjects: ${Array.isArray(subjects) ? subjects.join(', ') : subjects}
- Specific Topics of Focus: ${topics || 'Comprehensive syllabus'}
- Target Exam / Deadline: ${examDate || 'In 15 days'}
- Available Daily Study Time: ${hoursPerDay} hours/day
- Current Knowledge Level: ${knowledgeLevel}
- Strong Areas: ${strongSubjects || 'None specified'}
- Weak Areas (needs prioritized practice): ${weakSubjects || 'None specified'}
- Preferred Study Hours: ${preferredTime}
- Daily Study Goal: ${dailyGoal || 'Master high-weightage topics'}

Requirements:
1. Provide an executive summary of strategy (how to allocate hours between theory, active recall, and problem solving).
2. Detail a Day-by-Day realistic schedule (e.g. Day 1, Day 2, etc.) breaking down each day into exact hour-blocks with specific topic objectives (not vague advice).
3. Include active revision milestones and buffer catch-up days.
4. Keep the pace achievable so the student avoids burnout.

Format with clear Markdown sections:
### 🎯 Strategy Blueprint
### 📅 Daily Structured Schedule
(List Day 1, Day 2, Day 3... with specific bullet points and hour splits)
### 💡 High-Yield Advice for Weak Areas`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.6,
      },
    });

    const planText = response.text || 'Unable to generate study plan.';

    // Generate 4-6 actionable starter tasks for the Study Planner
    let suggestedTasks: any[] = [];
    try {
      const taskResponse = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Based on this study plan text, extract 5 concrete upcoming study tasks for the student planner:
Plan:
${planText.substring(0, 2000)}

Return JSON array of tasks.`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                subject: { type: Type.STRING },
                topic: { type: Type.STRING },
                durationMinutes: { type: Type.NUMBER },
                priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] },
                dayOffset: { type: Type.NUMBER, description: 'Days from today (0 for today, 1 for tomorrow, etc.)' },
              },
              required: ['title', 'subject', 'topic', 'durationMinutes', 'priority', 'dayOffset'],
            },
          },
        },
      });

      if (taskResponse.text) {
        suggestedTasks = JSON.parse(taskResponse.text.trim());
      }
    } catch (taskErr) {
      console.warn('Could not extract structured tasks:', taskErr);
    }

    res.json({ planText, suggestedTasks });
  } catch (err: any) {
    console.error('Error in /api/ai/study-plan:', err);
    res.status(500).json({
      error: 'AI is temporarily unavailable. Please try again.',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 3: AI Quiz Generator
// ----------------------------------------------------
app.post('/api/ai/quiz', async (req, res) => {
  try {
    const {
      subject = 'Computer Science',
      topic = 'Data Structures',
      difficulty = 'Medium',
      questionCount = 5,
    } = req.body;

    const count = Math.min(Math.max(Number(questionCount) || 5, 3), 15);
    const ai = getAI();

    const prompt = `Generate an academic multiple-choice quiz testing student knowledge on:
Subject: ${subject}
Topic: ${topic}
Difficulty: ${difficulty}
Number of Questions: ${count}

Each question MUST:
- Be academically rigorous and clear.
- Have exactly 4 options.
- Have one indisputably correct answer.
- Include a concise, illuminating explanation of WHY the correct answer is right and why the others are common traps.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Exactly 4 multiple choice options',
              },
              correctIndex: {
                type: Type.INTEGER,
                description: '0-based index (0, 1, 2, or 3) of the correct option',
              },
              explanation: {
                type: Type.STRING,
                description: 'Detailed explanation of why the correct answer is correct',
              },
            },
            required: ['id', 'question', 'options', 'correctIndex', 'explanation'],
          },
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '[]');
    res.json({ questions: parsed });
  } catch (err: any) {
    console.error('Error in /api/ai/quiz:', err);
    res.status(500).json({
      error: 'AI is temporarily unavailable. Please try again.',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 4: "Ask AI" for Community Doubts (Multimodal)
// ----------------------------------------------------
app.post('/api/ai/answer-doubt', async (req, res) => {
  try {
    const { questionTitle, questionDescription, subjectName, imageUrl, image } = req.body;

    if (!questionTitle) {
      return res.status(400).json({ error: 'Question title is required' });
    }

    const ai = getAI();

    let prompt = `A student asked the following academic doubt on our student doubt clarification platform:
Subject: ${subjectName || 'Academic Subject'}
Title: ${questionTitle}
Description / Code / Problem context:
${questionDescription || 'No additional details provided'}

You are the Academic AI Assistant. Generate an insightful, structured educational explanation.
Structure your answer using Markdown with the following exact sections:
### 🤖 AI Explanation
1. **Core Problem & Concept**: Clearly state what is being asked or what the key concept is.
2. **Step-by-Step Solution & Walkthrough**: Explain the logical, mathematical, or algorithmic steps thoroughly.
3. **Key Example / Code Correction**: Provide clear, commented code or a concrete mathematical/diagrammatic breakdown.
4. **Practice Check**: Conclude with a single practice question or quick quiz challenge for the student.

Rules:
- Clearly format as an AI Explanation. Do not pretend to be a fellow student.
- If an image or diagram is provided, thoroughly analyze its visual contents, equations, code lines, or errors.`;

    const contents: any[] = [];
    const parts: any[] = [];

    const activeImage = image || imageUrl;
    if (activeImage && typeof activeImage === 'string' && activeImage.startsWith('data:image/')) {
      const match = activeImage.match(/^data:(image\/[a-zA-Z0-9+.-]+);base64,(.+)$/);
      if (match) {
        parts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          },
        });
      }
    }

    parts.push({ text: prompt });
    contents.push({ role: 'user', parts });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        temperature: 0.6,
      },
    });

    const explanation = response.text || 'Unable to generate explanation.';
    res.json({ explanation });
  } catch (err: any) {
    console.error('Error in /api/ai/answer-doubt:', err);
    res.status(500).json({
      error: 'AI is temporarily unavailable. Please try again.',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 5: AI Weak Topic & Progress Analysis
// ----------------------------------------------------
app.post('/api/ai/learning-analysis', async (req, res) => {
  try {
    const {
      quizzesTaken = 0,
      averageScore = 0,
      quizHistory = [],
      doubtsAsked = [],
      completedTasks = [],
      streakDays = 0,
    } = req.body;

    const ai = getAI();

    const prompt = `Analyze this real college student's learning activity and deliver grounded educational guidance:
- Total Quizzes Completed: ${quizzesTaken}
- Overall Quiz Accuracy: ${averageScore}%
- Quiz History Sample: ${JSON.stringify(quizHistory.slice(-5))}
- Doubts / Questions Asked: ${JSON.stringify(doubtsAsked.slice(-5))}
- Completed Tasks in Study Planner: ${JSON.stringify(completedTasks.slice(-5))}
- Current Study Streak: ${streakDays} days

Rules:
- Ground your analysis STRICTLY in the provided data. Do not make unsupported claims.
- If data is sparse, acknowledge that they are just getting started and offer encouraging next steps.
- Provide a summary highlighting their strongest observed areas, areas needing targeted practice, and one specific recommended topic to study next.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overview: { type: Type.STRING, description: '2-3 sentence overview of their study momentum' },
            strengthAreas: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Observed strong topics or habits',
            },
            improvementAreas: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Topics that showed lower scores or repeated doubts',
            },
            recommendedTopic: { type: Type.STRING, description: 'The single most high-priority topic to study next' },
            actionPlan: { type: Type.STRING, description: 'Concrete next study action recommendation' },
          },
          required: ['overview', 'strengthAreas', 'improvementAreas', 'recommendedTopic', 'actionPlan'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    res.json(parsed);
  } catch (err: any) {
    console.error('Error in /api/ai/learning-analysis:', err);
    res.status(500).json({
      error: 'AI is temporarily unavailable. Please try again.',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 6: Extract Text from Document (PDF, DOCX, TXT)
// ----------------------------------------------------
app.post('/api/ai/document/extract-text', async (req, res) => {
  try {
    const { fileData, fileName, fileType } = req.body;

    if (!fileData) {
      return res.status(400).json({ error: 'No file data provided' });
    }

    let buffer: Buffer;
    if (fileData.startsWith('data:')) {
      const base64Index = fileData.indexOf(';base64,');
      const rawBase64 = base64Index !== -1 ? fileData.slice(base64Index + 8) : fileData;
      buffer = Buffer.from(rawBase64, 'base64');
    } else {
      buffer = Buffer.from(fileData, 'base64');
    }

    let extractedText = '';
    const lowerType = (fileType || '').toLowerCase();
    const lowerName = (fileName || '').toLowerCase();

    if (lowerType.includes('pdf') || lowerName.endsWith('.pdf')) {
      extractedText = await extractTextFromPDF(buffer);
    } else if (
      lowerType.includes('word') ||
      lowerType.includes('docx') ||
      lowerName.endsWith('.docx')
    ) {
      const result = await mammoth.extractRawText({ buffer });
      extractedText = result.value || '';
    } else {
      // Text or Notes
      extractedText = buffer.toString('utf-8');
    }

    extractedText = extractedText.replace(/\r\n/g, '\n').trim();

    if (!extractedText || extractedText.length < 10) {
      return res.status(422).json({
        error: 'Could not extract sufficient text from this document. Please ensure it contains readable text.',
      });
    }

    res.json({
      text: extractedText,
      charCount: extractedText.length,
      wordCount: extractedText.split(/\s+/).filter(Boolean).length,
    });
  } catch (err: any) {
    console.error('Error in /api/ai/document/extract-text:', err);
    res.status(500).json({
      error: 'Failed to extract text from document',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 7: Chunk and Embed Document (RAG Pipeline)
// ----------------------------------------------------
app.post('/api/ai/document/chunk-and-embed', async (req, res) => {
  try {
    const { documentId, documentName, text } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Document text is required' });
    }

    // 1. Chunk text into semantic pieces
    const rawChunks = chunkText(text, 750, 120);

    // Limit to reasonable batch size for performance
    const selectedChunks = rawChunks.slice(0, 40);

    // 2. Generate embeddings for each chunk
    const chunksWithEmbeddings = await Promise.all(
      selectedChunks.map(async (c, i) => {
        const chunkId = `${documentId || 'doc'}_chunk_${i}`;
        const embedding = await getEmbedding(c.content);
        return {
          chunkId,
          documentId: documentId || 'unknown',
          documentName: documentName || 'Study Material',
          chunkIndex: i,
          content: c.content,
          embedding,
          pageOrSection: c.pageOrSection,
        };
      })
    );

    res.json({
      chunkCount: chunksWithEmbeddings.length,
      chunks: chunksWithEmbeddings,
    });
  } catch (err: any) {
    console.error('Error in /api/ai/document/chunk-and-embed:', err);
    res.status(500).json({
      error: 'Failed to process and embed document chunks',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 8: RAG Document Chat (Vector Search + Grounded Generation)
// ----------------------------------------------------
app.post('/api/ai/document/rag-chat', async (req, res) => {
  try {
    const {
      question,
      documentName = 'Uploaded Document',
      chunks = [],
      conversationHistory = [],
    } = req.body;

    if (!question || typeof question !== 'string') {
      return res.status(400).json({ error: 'Question is required' });
    }

    const ai = getAI();

    // 1. If chunks have embeddings, perform cosine similarity retrieval
    let retrievedChunks: Array<{
      documentId: string;
      documentName: string;
      chunkIndex: number;
      content: string;
      pageOrSection?: string;
      similarity: number;
    }> = [];

    if (Array.isArray(chunks) && chunks.length > 0) {
      const queryEmbedding = await getEmbedding(question);

      const scored = chunks
        .map(c => {
          let score = 0;
          if (Array.isArray(c.embedding) && c.embedding.length > 0) {
            score = cosineSimilarity(queryEmbedding, c.embedding);
          } else {
            // Keyword relevance fallback
            const qWords = question.toLowerCase().split(/\s+/).filter(w => w.length > 3);
            const contentLower = (c.content || '').toLowerCase();
            const matches = qWords.filter(w => contentLower.includes(w)).length;
            score = qWords.length > 0 ? matches / qWords.length : 0;
          }
          return {
            documentId: c.documentId || '',
            documentName: c.documentName || documentName,
            chunkIndex: c.chunkIndex ?? 0,
            content: c.content || '',
            pageOrSection: c.pageOrSection,
            similarity: Math.max(0, Math.min(1, score)),
          };
        })
        .sort((a, b) => b.similarity - a.similarity);

      // Take top 4 most relevant chunks
      retrievedChunks = scored.slice(0, 4);
    }

    const maxSimilarity = retrievedChunks[0]?.similarity || 0;
    const isMaterialRelevant = retrievedChunks.length > 0 && maxSimilarity >= 0.35;

    let answer = '';
    let sourceUsed = false;

    if (!isMaterialRelevant) {
      // Prompt asks to indicate material did not contain it, followed by general answer
      const generalPrompt = `A student asked this question about their study material "${documentName}":
"${question}"

The uploaded study material was searched, but no closely matching sections were found.
Respond in this exact required pattern:
1. Start with the sentence: "I couldn't find this information in your uploaded material. I can provide a general explanation instead."
2. Provide a clean, accurate, academic explanation of the topic.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: generalPrompt,
        config: { temperature: 0.6 },
      });

      answer = response.text || "I couldn't find this information in your uploaded material. I can provide a general explanation instead.";
      sourceUsed = false;
    } else {
      sourceUsed = true;
      const contextText = retrievedChunks
        .map((c, i) => `[Excerpt ${i + 1} - ${c.pageOrSection || `Part ${c.chunkIndex + 1}`}]\n${c.content}`)
        .join('\n\n');

      const systemInstruction = `You are a dedicated Academic Study Assistant for the student's uploaded material: "${documentName}".
You must answer the student's question based STRICTLY and FAITHFULLY on the retrieved context below.

Retrieved Context from Student Document:
${contextText}

Instructions:
1. Ground your answer in the retrieved material.
2. If the excerpts answer the question, cite the excerpt and explain clearly.
3. If the excerpts only partially cover the question, answer what is present, and state what is missing.
4. Keep the tone encouraging, structured, and pedagogical.`;

      const contents: any[] = [];
      if (Array.isArray(conversationHistory) && conversationHistory.length > 0) {
        for (const item of conversationHistory.slice(-4)) {
          if (item.role === 'user' || item.role === 'model') {
            contents.push({
              role: item.role,
              parts: [{ text: item.content || item.text || '' }],
            });
          }
        }
      }

      contents.push({
        role: 'user',
        parts: [{ text: question }],
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.5,
        },
      });

      answer = response.text || 'I could not generate an answer from the document.';
    }

    res.json({
      answer,
      sourceUsed,
      retrievedChunks: sourceUsed ? retrievedChunks : [],
    });
  } catch (err: any) {
    console.error('Error in /api/ai/document/rag-chat:', err);
    res.status(500).json({
      error: 'Failed to query document with AI',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 9: Document Analyzer (Summaries, MCQs, Questions, Flashcards)
// ----------------------------------------------------
app.post('/api/ai/document/analyze', async (req, res) => {
  try {
    const {
      documentName = 'Study Document',
      text = '',
      analysisType = 'summarize',
      summarySubtype = 'quick',
    } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Document text is required' });
    }

    const ai = getAI();
    // Use up to first 25,000 characters for rich analysis
    const sampleText = text.substring(0, 25000);

    if (analysisType === 'summarize') {
      let promptGuidance = '';
      if (summarySubtype === 'quick') {
        promptGuidance = 'Generate a high-yield Quick Summary (2-3 crisp paragraphs) followed by bullet points of core takeaways.';
      } else if (summarySubtype === 'detailed') {
        promptGuidance = 'Generate a comprehensive Detailed Summary breaking down all chapters, concepts, and logical proofs/flows.';
      } else if (summarySubtype === 'exam_notes') {
        promptGuidance = 'Generate Exam Revision Notes highlighting high-weightage topics, exam traps, formulas, and memory mnemonics.';
      } else if (summarySubtype === 'important_points') {
        promptGuidance = 'Generate a clean, high-priority list of Key Important Points every student must memorize.';
      } else if (summarySubtype === 'one_page_sheet') {
        promptGuidance = 'Generate a condensed One-Page Revision Cheat Sheet formatted with compact sections, formulas, and definitions.';
      }

      const prompt = `You are an expert Academic Study Coach. Analyze this uploaded document titled "${documentName}":
Document Text:
${sampleText}

Task: ${promptGuidance}

Structure your response cleanly using Markdown with these headings:
### 📌 Executive Overview
### 🔑 Key Concepts & Definitions
### 📐 Important Formulas & Theorems (if applicable)
### 💡 Core Takeaways & Exam Points`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: { temperature: 0.6 },
      });

      return res.json({ result: response.text || 'Unable to generate summary.' });
    }

    if (analysisType === 'explain') {
      const prompt = `Act as an encouraging personal tutor. Explain the uploaded study material "${documentName}" step-by-step so a beginner can understand it:
Document Text:
${sampleText}

Requirements:
1. Break down the core concepts into intuitive, plain-English explanations.
2. Use relatable analogies or real-world examples.
3. Walk through any complex definitions or formulas step by step.
4. Conclude with a quick 3-point check of what they learned.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: { temperature: 0.6 },
      });

      return res.json({ result: response.text || 'Unable to generate explanation.' });
    }

    if (analysisType === 'mcqs') {
      const prompt = `Based STRICTLY on this uploaded study material "${documentName}", generate 6 multiple-choice questions for exam practice:
Document Text:
${sampleText}

Rules:
- Questions must be directly answered by the text.
- 4 options per question.
- Exactly one correct index (0-3).
- Detailed explanation for each.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                question: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                correctIndex: { type: Type.INTEGER },
                explanation: { type: Type.STRING },
              },
              required: ['id', 'question', 'options', 'correctIndex', 'explanation'],
            },
          },
        },
      });

      const mcqs = JSON.parse(response.text?.trim() || '[]');
      return res.json({ mcqs });
    }

    if (analysisType === 'questions') {
      const prompt = `Extract 5 high-yield, important exam questions with model answers from this study material "${documentName}":
Document Text:
${sampleText}

Return as JSON array of questions.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                answer: { type: Type.STRING },
                highYieldTag: { type: Type.STRING, description: 'e.g. 5-Mark Question, High Probability, Conceptual' },
              },
              required: ['question', 'answer', 'highYieldTag'],
            },
          },
        },
      });

      const questions = JSON.parse(response.text?.trim() || '[]');
      return res.json({ questions });
    }

    if (analysisType === 'flashcards') {
      const prompt = `Create 8 interactive digital flashcards for active recall based on this study material "${documentName}":
Document Text:
${sampleText}

Each flashcard must have:
- front: A question, term, formula name, or concept prompt
- back: The concise definition, answer, or formula
- category: Topic category name`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                front: { type: Type.STRING },
                back: { type: Type.STRING },
                category: { type: Type.STRING },
              },
              required: ['id', 'front', 'back', 'category'],
            },
          },
        },
      });

      const flashcards = JSON.parse(response.text?.trim() || '[]');
      return res.json({ flashcards });
    }

    if (analysisType === 'key_concepts') {
      const prompt = `Extract all key concepts, definitions, and formulas from this study material "${documentName}":
Document Text:
${sampleText}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                concept: { type: Type.STRING },
                definition: { type: Type.STRING },
                formulaOrExample: { type: Type.STRING },
                examRelevance: { type: Type.STRING },
              },
              required: ['concept', 'definition'],
            },
          },
        },
      });

      const keyConcepts = JSON.parse(response.text?.trim() || '[]');
      return res.json({ keyConcepts });
    }

    res.status(400).json({ error: 'Unsupported analysisType' });
  } catch (err: any) {
    console.error('Error in /api/ai/document/analyze:', err);
    res.status(500).json({
      error: 'Failed to analyze document',
      details: err?.message || String(err),
    });
  }
});

// ----------------------------------------------------
// AI Endpoint 10: Similar Doubts (Concept Matching)
// ----------------------------------------------------
app.post('/api/ai/similar-doubts', async (req, res) => {
  try {
    const {
      currentQuestionId,
      title = '',
      description = '',
      subjectId = '',
      allQuestions = [],
    } = req.body;

    if (!title && !description) {
      return res.json({ similarQuestions: [] });
    }

    const queryText = `${title} ${description}`.trim();
    const queryVector = await getEmbedding(queryText);

    const candidates = (Array.isArray(allQuestions) ? allQuestions : [])
      .filter((q: any) => q.questionId !== currentQuestionId)
      .slice(0, 35);

    if (candidates.length === 0) {
      return res.json({ similarQuestions: [] });
    }

    const scored = await Promise.all(
      candidates.map(async (c: any) => {
        const candidateText = `${c.title || ''} ${c.description || ''}`.trim();
        const candidateVector = await getEmbedding(candidateText);
        let sim = cosineSimilarity(queryVector, candidateVector);

        // Subject boost if exact subject match
        if (subjectId && c.subjectId === subjectId) {
          sim = Math.min(1, sim + 0.08);
        }

        return {
          questionId: c.questionId,
          title: c.title,
          subjectName: c.subjectName,
          similarityScore: Math.round(sim * 100),
          matchedConcept: sim > 0.65 ? 'Conceptually Related' : 'Related Topic',
        };
      })
    );

    // Keep those with similarity >= 40%
    const filtered = scored
      .filter(s => s.similarityScore >= 40)
      .sort((a, b) => b.similarityScore - a.similarityScore)
      .slice(0, 4);

    res.json({ similarQuestions: filtered });
  } catch (err: any) {
    console.error('Error in /api/ai/similar-doubts:', err);
    res.json({ similarQuestions: [] });
  }
});

// ----------------------------------------------------
// AI Endpoint 11: Semantic Search
// ----------------------------------------------------
app.post('/api/ai/semantic-search', async (req, res) => {
  try {
    const { query = '', questions = [] } = req.body;

    if (!query || !Array.isArray(questions) || questions.length === 0) {
      return res.json({ results: [] });
    }

    const queryVector = await getEmbedding(query);

    const scored = await Promise.all(
      questions.slice(0, 30).map(async (q: any) => {
        const text = `${q.title || ''} ${q.description || ''} ${q.subjectName || ''}`.trim();
        const vector = await getEmbedding(text);
        const sim = cosineSimilarity(queryVector, vector);
        return {
          questionId: q.questionId,
          title: q.title,
          subjectName: q.subjectName,
          similarityScore: Math.round(sim * 100),
          matchedConcept: sim >= 0.7 ? 'High Semantic Match' : 'Related Concept',
        };
      })
    );

    const results = scored
      .filter(s => s.similarityScore >= 35)
      .sort((a, b) => b.similarityScore - a.similarityScore);

    res.json({ results });
  } catch (err: any) {
    console.error('Error in /api/ai/semantic-search:', err);
    res.json({ results: [] });
  }
});

// ----------------------------------------------------
// AI Endpoint 8: AI Comprehensive Learning Report
// ----------------------------------------------------
app.post('/api/ai/learning-report', async (req, res) => {
  try {
    const {
      quizzesTaken = 0,
      averageScore = 0,
      quizHistory = [],
      doubtsAsked = [],
      completedTasks = [],
      streakDays = 0,
      flashcardsCount = 0,
      flashcardMastery = { mastered: 0, difficult: 0, learning: 0, new: 0 },
      studyMinutes = 0,
    } = req.body;

    const ai = getAI();

    const prompt = `You are the Lead Academic AI Advisor on the Student Learning Platform. Generate an in-depth, encouraging, yet rigorous and mathematically supported "AI Learning Report" for this student based strictly on their learning telemetry.

Student Learning Telemetry:
- Study Streak: ${streakDays} days
- Total Study Time Logged: ${studyMinutes} minutes
- Total Quizzes Taken: ${quizzesTaken}
- Average Quiz Score: ${averageScore}%
- Doubts / Questions Asked: ${doubtsAsked.length} (${doubtsAsked.map((d: any) => d.title || d).slice(0, 5).join(', ') || 'None'})
- Tasks Completed in Study Plan: ${completedTasks.length}
- Quiz History Details: ${JSON.stringify(quizHistory.slice(-5))}
- Flashcards Status: ${JSON.stringify(flashcardMastery)} (Total: ${flashcardsCount})

Follow this structure strictly in Markdown:
# Comprehensive Student Learning Report
*Generated on: ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}*

### 1. Executive Summary & Mastery Level
Provide a 2-3 paragraph analytical assessment of the student's learning momentum, consistency, and current concept grasp. State their estimated academic mastery level (Foundational, Intermediate, Advanced, or Exam-Ready).

### 2. Demonstrated Strengths & Mastered Concepts
Highlight 3-5 specific topics, skills, and areas where the student demonstrates strong recall, high quiz accuracy, or consistent active practice.

### 3. Vulnerability Areas & High-Priority Improvements
Identify 2-4 specific concepts, question patterns, or subjects where mistakes or unreviewed flashcards indicate risk of knowledge decay.

### 4. Spaced Revision & Actionable Next Steps
Provide a concrete 5-step prioritized study routine for the upcoming week.

### 5. AI Advisor Motivational Note
A brief, uplifting closing thought encouraging academic curiosity and steady effort.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.7,
      },
    });

    const reportText = response.text || 'Unable to generate learning report at this time.';
    res.json({
      reportText,
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Error in /api/ai/learning-report:', err);
    res.status(500).json({ error: 'Failed to generate learning report' });
  }
});

// ----------------------------------------------------
// AI Endpoint 9: Break Down Learning Goal
// ----------------------------------------------------
app.post('/api/ai/break-down-goal', async (req, res) => {
  try {
    const { goalTitle, subject, targetDate, currentLevel = 'Intermediate' } = req.body;

    if (!goalTitle) {
      return res.status(400).json({ error: 'Goal title is required' });
    }

    const ai = getAI();

    const prompt = `You are an expert academic curriculum designer. A student has set the following academic learning goal:
Goal: "${goalTitle}"
Subject: "${subject || 'General'}"
Target Completion Date: "${targetDate || '2 weeks'}"
Current Proficiency: "${currentLevel}"

Deconstruct this high-level goal into 4 to 7 structured, actionable, and sequential micro-milestone study tasks.
Provide realistic estimated durations in minutes (between 15 and 45 minutes each).

Respond ONLY with valid JSON in this exact structure:
{
  "tasks": [
    {
      "id": "task_1",
      "title": "Clear concise task name (e.g. Master tree traversal basics with recursive DFS)",
      "estimatedMinutes": 30,
      "priority": "High"
    }
  ],
  "suggestedNextStep": "Immediate first step recommendation for today."
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.6,
      },
    });

    let result = { tasks: [], suggestedNextStep: '' };
    try {
      result = JSON.parse(response.text || '{}');
    } catch {
      result = {
        tasks: [
          { id: 'task_1', title: `Review foundational concepts for ${goalTitle}`, estimatedMinutes: 25, priority: 'High' },
          { id: 'task_2', title: `Practice 5 core problems on ${goalTitle}`, estimatedMinutes: 35, priority: 'Medium' },
          { id: 'task_3', title: `Take a 10-question self-assessment quiz`, estimatedMinutes: 20, priority: 'High' },
        ],
        suggestedNextStep: `Start by reviewing foundational notes on ${goalTitle}.`,
      };
    }

    res.json(result);
  } catch (err: any) {
    console.error('Error in /api/ai/break-down-goal:', err);
    res.status(500).json({ error: 'Failed to break down goal' });
  }
});

// ----------------------------------------------------
// AI Endpoint 10: Personalized Daily Learning Feed
// ----------------------------------------------------
app.post('/api/ai/daily-feed-recommendation', async (req, res) => {
  try {
    const {
      weakTopics = [],
      streakDays = 0,
      recentDoubts = [],
      dueFlashcardsCount = 0,
      activeGoals = [],
    } = req.body;

    const ai = getAI();

    const prompt = `You are a personalized daily learning companion. Generate a tailored, balanced 4-item daily study schedule for a college student today.
Student context:
- Current Streak: ${streakDays} days
- Weak / Struggling Topics: ${weakTopics.join(', ') || 'General fundamentals'}
- Recent Doubts Asked: ${recentDoubts.join(', ') || 'None recently'}
- Flashcards Due for Review: ${dueFlashcardsCount}
- Active Goals: ${activeGoals.join(', ') || 'Ongoing academic coursework'}

Respond ONLY with valid JSON in this exact structure:
{
  "greeting": "A warm, uplifting greeting with an emoji (e.g. Good morning! Ready to crush recursion today?)",
  "summaryMessage": "A motivating 1-sentence thought for today's session.",
  "tasks": [
    {
      "id": "feed_1",
      "title": "20 min — DBMS normalization with 3NF examples",
      "category": "study",
      "durationMinutes": 20,
      "subject": "Computer Science"
    },
    {
      "id": "feed_2",
      "title": "10 min — Review due active recall flashcards",
      "category": "flashcard",
      "durationMinutes": 10,
      "subject": "Revision"
    },
    {
      "id": "feed_3",
      "title": "25 min — Practice recursion tree tracing",
      "category": "practice",
      "durationMinutes": 25,
      "subject": "Algorithms"
    },
    {
      "id": "feed_4",
      "title": "15 min — Take a quick 5-question mastery quiz",
      "category": "quiz",
      "durationMinutes": 15,
      "subject": "Assessment"
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.7,
      },
    });

    let data = {
      greeting: 'Good morning! Ready for today’s learning session? 🚀',
      summaryMessage: 'Steady daily practice turns difficult concepts into second nature.',
      tasks: [
        { id: 'feed_1', title: '20 min — Review core lecture notes and key formulas', category: 'study', durationMinutes: 20 },
        { id: 'feed_2', title: '10 min — Active recall with due flashcards', category: 'flashcard', durationMinutes: 10 },
        { id: 'feed_3', title: '25 min — Solve 3 practice exercises', category: 'practice', durationMinutes: 25 },
        { id: 'feed_4', title: '15 min — Take a quick concept quiz', category: 'quiz', durationMinutes: 15 },
      ],
    };

    try {
      data = JSON.parse(response.text || '{}');
    } catch {
      // Fallback
    }

    res.json(data);
  } catch (err: any) {
    console.error('Error in /api/ai/daily-feed-recommendation:', err);
    res.status(500).json({ error: 'Failed to generate daily feed recommendation' });
  }
});

// ----------------------------------------------------
// Health check
// ----------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    aiConfigured: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// ----------------------------------------------------
// Vite Middleware / Static Serving
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI-Powered Learning Platform server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
