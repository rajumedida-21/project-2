# Security Specification & Threat Model
## Anonymous Student Doubt Clarification System

### 1. Core Data Invariants & Access Control Policy
1. **Public Anonymity & PII Isolation:**
   - User profiles in `/users/{uid}` contain private PII (email, role, real name). Read access must be restricted to the document owner (`request.auth.uid == uid`) or an Admin (`isAdmin()`).
   - Public question/answer views NEVER fetch user profile documents of other students. Public entities only store anonymous tags or verified role badge flags (`isVerifiedMentor: true` if mentor, `isAnonymous: true`).
2. **Immutability of Authorship & Timestamps:**
   - `authorId` on `questions` and `answers` cannot be forged on create, and cannot be updated after creation.
   - `reportedBy` on `reports` must equal `request.auth.uid`.
3. **Vote Integrity:**
   - Vote documents in `/questionVotes/{voteId}` and `/answerVotes/{voteId}` use deterministic IDs (`${questionId}_${userId}`) and cannot be created for other users (`userId == request.auth.uid`).
4. **Answer Acceptance Authority:**
   - Marking an answer `isAccepted: true` or setting `acceptedAnswerId` on a question can ONLY be performed by the question author (`request.auth.uid == question.authorId`) or Admin.
5. **Administrative Privilege Isolation:**
   - Only Admins can modify user roles (`role`), verify mentors (`isVerifiedMentor`), delete arbitrary questions/answers, or resolve content reports.
   - Regular users cannot elevate their own role to `admin` during registration or document update.

---

### 2. The Dirty Dozen (12 Malicious Attack Payloads)

| # | Attack Vector | Target Path | Malicious Payload / Action | Expected Result |
|---|---|---|---|---|
| 1 | PII Scraping | `GET /users/victim123` | Non-owner authenticated user attempts to read victim's private email/profile. | **PERMISSION_DENIED** |
| 2 | Privilege Escalation (Self-Admin) | `POST /users/attackerUid` | `{ uid: "attackerUid", role: "admin", isVerifiedMentor: true, ... }` | **PERMISSION_DENIED** |
| 3 | Role Tampering via Update | `UPDATE /users/student123` | `{ role: "admin" }` | **PERMISSION_DENIED** |
| 4 | Author Spoofing on Question | `POST /questions/q_999` | `{ authorId: "innocentStudent", title: "Fake Question", ... }` with `request.auth.uid == "attacker"` | **PERMISSION_DENIED** |
| 5 | Unauthorized Content Deletion | `DELETE /questions/q_100` | User B attempts to delete question created by User A. | **PERMISSION_DENIED** |
| 6 | Unauthorized Answer Acceptance | `UPDATE /answers/ans_1` | User B (not question owner) attempts to update `isAccepted: true`. | **PERMISSION_DENIED** |
| 7 | Vote Duplication / Hijack | `POST /questionVotes/q_1_victim` | Attacker votes under victim's `userId`. | **PERMISSION_DENIED** |
| 8 | Arbitrary Report Resolution | `UPDATE /reports/rep_1` | Regular student tries to change report status to `"dismissed"`. | **PERMISSION_DENIED** |
| 9 | Oversized Payload (Denial of Wallet) | `POST /questions/q_overflow` | Title with 50,000 characters or description with 5MB text. | **PERMISSION_DENIED** |
| 10 | Immutable Field Mutability | `UPDATE /questions/q_1` | Author tries to modify `authorId` or `createdAt`. | **PERMISSION_DENIED** |
| 11 | Direct Manipulation of Counter Fields | `UPDATE /questions/q_1` | User tries to manually overwrite `upvotes: 999999` without vote record. | **PERMISSION_DENIED** |
| 12 | Unauthenticated Question Creation | `POST /questions/q_anon` | Unauthenticated visitor tries to write to questions. | **PERMISSION_DENIED** |
