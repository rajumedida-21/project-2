export type UserRole = 'student' | 'mentor' | 'admin';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  profileImage?: string;
  createdAt: string;
  isVerifiedMentor: boolean;
  subjectSpecialization?: string;
  bio?: string;
}

export interface Question {
  questionId: string;
  authorId: string;
  title: string;
  description: string;
  subjectId: string;
  subjectName?: string;
  imageUrl?: string;
  isAnonymous: boolean;
  createdAt: string;
  updatedAt?: string;
  status: 'open' | 'resolved' | 'closed';
  views: number;
  upvotes: number;
  answerCount: number;
  acceptedAnswerId?: string;
  aiExplanation?: string;
  aiExplanationCreatedAt?: string;
}

export interface Answer {
  answerId: string;
  questionId: string;
  authorId: string;
  authorRole: UserRole;
  isVerifiedMentor: boolean;
  isMentor?: boolean;
  mentorSpecialization?: string;
  mentorName?: string;
  answerText: string;
  imageUrl?: string;
  isAnonymous?: boolean;
  createdAt: string;
  updatedAt?: string;
  upvotes: number;
  isAccepted: boolean;
}

export interface Report {
  reportId: string;
  reportedBy: string;
  contentType: 'question' | 'answer';
  contentId: string;
  contentSnippet?: string;
  reason: 'Spam' | 'Offensive content' | 'Incorrect information' | 'Harassment' | 'Other';
  details?: string;
  createdAt: string;
  status: 'pending' | 'reviewed' | 'resolved' | 'dismissed';
}

export interface Subject {
  subjectId: string;
  name: string;
  description: string;
  questionCount?: number;
  icon?: string;
}

export interface NotificationItem {
  notificationId: string;
  recipientId: string;
  type: 'answer' | 'upvote' | 'accepted' | 'report';
  title: string;
  message: string;
  linkQuestionId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface QuestionVote {
  voteId: string;
  questionId: string;
  userId: string;
  createdAt: string;
}

export interface AnswerVote {
  voteId: string;
  answerId: string;
  userId: string;
  createdAt: string;
}

export type QuestionFilter = 'all' | 'recent' | 'popular' | 'unanswered';

export interface StudyPlan {
  planId: string;
  userId: string;
  subjects: string[];
  topics: string;
  examDate: string;
  hoursPerDay: number;
  knowledgeLevel: string;
  strongSubjects: string;
  weakSubjects: string;
  preferredTime: string;
  dailyGoal: string;
  planContent: string;
  createdAt: string;
  updatedAt?: string;
  status: 'active' | 'completed' | 'archived';
}

export interface StudyTask {
  taskId: string;
  userId: string;
  subject: string;
  topic: string;
  title: string;
  date: string; // YYYY-MM-DD
  startTime?: string; // e.g. "14:00"
  durationMinutes: number;
  priority: 'High' | 'Medium' | 'Low';
  completed: boolean;
  completedAt?: string;
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizResult {
  resultId: string;
  userId: string;
  subject: string;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  totalQuestions: number;
  correctCount: number;
  scorePercentage: number;
  questions: QuizQuestion[];
  userAnswers: Record<string, number>;
  createdAt: string;
}

export interface AIChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  actionType?: 'normal' | 'simpler' | 'example' | 'hint' | 'solution' | 'practice_question';
  imageUrl?: string;
}

export interface UserAchievement {
  id: string;
  userId: string;
  badgeId: string;
  title: string;
  description: string;
  icon: string;
  category: 'doubts' | 'answers' | 'quizzes' | 'streak' | 'planner';
  unlockedAt: string;
}

export interface LearningAnalysis {
  overview: string;
  strengthAreas: string[];
  improvementAreas: string[];
  recommendedTopic: string;
  actionPlan: string;
  updatedAt: string;
}

// ----------------------------------------------------
// Tier 2: Advanced AI Study Materials & RAG Types
// ----------------------------------------------------
export type DocumentProcessingStatus = 'uploading' | 'processing' | 'ready' | 'failed';

export type SummaryType =
  | 'quick'
  | 'detailed'
  | 'exam_notes'
  | 'important_points'
  | 'one_page_sheet';

export interface DocumentChunk {
  chunkId: string;
  documentId: string;
  documentName: string;
  chunkIndex: number;
  content: string;
  embedding?: number[];
  pageOrSection?: string;
}

export interface KeyConceptItem {
  concept: string;
  definition: string;
  formulaOrExample?: string;
  examRelevance?: string;
}

export interface DocumentImportantQuestion {
  question: string;
  answer: string;
  highYieldTag?: string;
}

export interface DocumentFlashcard {
  id: string;
  front: string;
  back: string;
  category?: string;
}

export interface StudyDocument {
  id: string;
  userId: string;
  name: string;
  subject: string;
  fileType: 'pdf' | 'docx' | 'txt' | 'notes';
  fileSize: string;
  uploadDate: string;
  status: DocumentProcessingStatus;
  errorMessage?: string;
  extractedTextLength: number;
  chunkCount: number;
  rawText?: string;
  chunks?: DocumentChunk[];
  summaries?: Partial<Record<SummaryType, string>>;
  keyConcepts?: KeyConceptItem[];
  importantQuestions?: DocumentImportantQuestion[];
  flashcards?: DocumentFlashcard[];
  mcqs?: QuizQuestion[];
  explanation?: string;
}

export interface RAGRetrievedChunk {
  documentId: string;
  documentName: string;
  chunkIndex: number;
  content: string;
  pageOrSection?: string;
  similarity: number;
}

export interface RAGQueryResult {
  answer: string;
  sourceUsed: boolean;
  retrievedChunks: RAGRetrievedChunk[];
}

export interface SimilarDoubtItem {
  questionId: string;
  title: string;
  subjectName?: string;
  similarityScore: number;
  matchedConcept?: string;
}

// ----------------------------------------------------
// Tier 3: Next-Generation Student Experience Types
// ----------------------------------------------------
export type SupportedLanguage = 'English' | 'Telugu' | 'Hindi';

export type VoiceAssistantStatus = 'idle' | 'listening' | 'processing' | 'speaking' | 'paused';

export type FlashcardMasteryStatus = 'new' | 'learning' | 'difficult' | 'mastered';

export interface SmartFlashcardItem {
  id: string;
  documentId?: string;
  front: string;
  back: string;
  category?: string;
  status: FlashcardMasteryStatus;
  mistakeCount: number;
  timesReviewed: number;
  lastReviewedAt?: string;
  nextReviewDue: string;
}

export interface AdaptiveRecommendation {
  id: string;
  title: string;
  reason: string;
  isPersonalized: boolean;
  category: 'weak_topic' | 'quiz' | 'flashcards' | 'notes' | 'doubt' | 'study' | 'goal' | 'practice';
  actionLabel: string;
  targetPage: string;
  targetParams?: Record<string, any>;
  estimatedMinutes: number;
  difficulty?: 'Easy' | 'Medium' | 'Hard';
  priority: 'high' | 'medium' | 'low';
}

export interface DailyFeedTask {
  id: string;
  title: string;
  category: 'study' | 'flashcard' | 'quiz' | 'practice';
  durationMinutes: number;
  completed: boolean;
  subject?: string;
  targetPage?: string;
}

export interface DailyLearningFeed {
  date: string;
  greeting: string;
  tasks: DailyFeedTask[];
  summaryMessage?: string;
}

export interface AILearningGoal {
  id: string;
  userId: string;
  title: string;
  subject: string;
  targetDate: string;
  progressPercentage: number;
  tasks: Array<{
    id: string;
    title: string;
    completed: boolean;
    estimatedMinutes: number;
  }>;
  suggestedNextStep: string;
  createdAt: string;
}

export interface StudySession {
  id: string;
  userId: string;
  subject: string;
  topic: string;
  goal: string;
  durationMinutes: number;
  completedAt: string;
  reflection?: string;
  focusRating?: number;
}

export interface StudentGamificationData {
  userId: string;
  xp: number;
  level: number;
  streak: number;
  badges: string[];
  doubtsAskedCount: number;
  answersGivenCount: number;
  helpfulAnswersCount: number;
  quizzesCompletedCount: number;
  flashcardsReviewedCount: number;
  totalStudyMinutes: number;
}

export interface LeaderboardEntry {
  userId: string;
  displayName: string;
  isAnonymous: boolean;
  xp: number;
  level: number;
  streak: number;
  helpfulAnswers: number;
  acceptedAnswers: number;
  quizzesCompleted: number;
  rank: number;
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  defaultLanguage: SupportedLanguage;
  voiceEnabled: boolean;
  autoSpeechRate: number;
  speechPitch: number;
  notifications: {
    studyReminders: boolean;
    communityAnswers: boolean;
    quizReminders: boolean;
    revisionReminders: boolean;
    aiRecommendations: boolean;
  };
  privacy: {
    anonymousByDefault: boolean;
    showOnLeaderboard: boolean;
    showStreakPublicly: boolean;
  };
}

