import React, { useState, useEffect, useRef } from 'react';
import {
  FileText,
  Upload,
  Sparkles,
  Bot,
  Send,
  BookOpen,
  HelpCircle,
  FileCheck,
  Brain,
  Layers,
  ChevronRight,
  Trash2,
  Copy,
  Check,
  RefreshCw,
  Search,
  ExternalLink,
  Flame,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  Plus,
  Compass,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import {
  StudyDocument,
  DocumentChunk,
  SummaryType,
  KeyConceptItem,
  DocumentImportantQuestion,
  DocumentFlashcard,
  QuizQuestion,
  RAGQueryResult,
} from '../types';
import {
  getLocalDocuments,
  subscribeToStudyDocuments,
  processAndSaveDocument,
  deleteStudyDocument,
  queryDocumentRAG,
  analyzeStudyDocument,
} from '../services/materialService';
import { useAuth } from '../context/AuthContext';

export const StudyMaterialsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [documents, setDocuments] = useState<StudyDocument[]>([]);
  const [selectedDocId, setSelectedDocId] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'rag_chat' | 'analyzer'>('rag_chat');

  // Analyzer tab states
  const [analyzerSubTab, setAnalyzerSubTab] = useState<
    'summaries' | 'explain' | 'mcqs' | 'questions' | 'flashcards' | 'key_concepts'
  >('summaries');
  const [summarySubtype, setSummarySubtype] = useState<SummaryType>('quick');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResultText, setAnalysisResultText] = useState<string>('');
  const [mcqs, setMcqs] = useState<QuizQuestion[]>([]);
  const [selectedOptionIndices, setSelectedOptionIndices] = useState<Record<string, number>>({});
  const [importantQuestions, setImportantQuestions] = useState<DocumentImportantQuestion[]>([]);
  const [flashcards, setFlashcards] = useState<DocumentFlashcard[]>([]);
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [cardFlipped, setCardFlipped] = useState(false);
  const [keyConcepts, setKeyConcepts] = useState<KeyConceptItem[]>([]);

  // RAG Chat states
  const [chatMessages, setChatMessages] = useState<
    Array<{
      id: string;
      role: 'user' | 'assistant';
      content: string;
      sourceUsed?: boolean;
      retrievedChunks?: any[];
      timestamp: string;
    }>
  >([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Upload Modal states
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadFileType, setUploadFileType] = useState<'pdf' | 'docx' | 'txt' | 'notes'>('pdf');
  const [uploadSubject, setUploadSubject] = useState('Data Structures & Algorithms');
  const [uploadDocName, setUploadDocName] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [notesText, setNotesText] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [copiedSummary, setCopiedSummary] = useState(false);

  // Subscribe to documents
  useEffect(() => {
    const unsub = subscribeToStudyDocuments(currentUser?.uid || 'guest_student', docs => {
      setDocuments(docs);
      if (docs.length > 0 && !selectedDocId) {
        setSelectedDocId(docs[0].id);
      }
    });
    return () => unsub();
  }, [currentUser?.uid, selectedDocId]);

  const selectedDoc = documents.find(d => d.id === selectedDocId) || documents[0];

  // Auto-scroll chat
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, chatLoading]);

  // Load existing analysis if available when switching doc or subtab
  useEffect(() => {
    if (!selectedDoc) return;

    if (analyzerSubTab === 'summaries') {
      const cached = selectedDoc.summaries?.[summarySubtype];
      setAnalysisResultText(cached || '');
    } else if (analyzerSubTab === 'explain') {
      setAnalysisResultText(selectedDoc.explanation || '');
    } else if (analyzerSubTab === 'mcqs') {
      setMcqs(selectedDoc.mcqs || []);
    } else if (analyzerSubTab === 'questions') {
      setImportantQuestions(selectedDoc.importantQuestions || []);
    } else if (analyzerSubTab === 'flashcards') {
      setFlashcards(selectedDoc.flashcards || []);
      setActiveCardIndex(0);
      setCardFlipped(false);
    } else if (analyzerSubTab === 'key_concepts') {
      setKeyConcepts(selectedDoc.keyConcepts || []);
    }
  }, [selectedDocId, analyzerSubTab, summarySubtype]);

  // Handle File upload
  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadDocName.trim()) {
      setUploadError('Please provide a document title.');
      return;
    }

    if (uploadFileType !== 'notes' && !uploadFile) {
      setUploadError('Please select a file to upload.');
      return;
    }

    if (uploadFileType === 'notes' && !notesText.trim()) {
      setUploadError('Please paste or write notes text.');
      return;
    }

    setUploading(true);
    setUploadError(null);

    try {
      let fileData: string | undefined = undefined;
      let rawText: string | undefined = undefined;

      if (uploadFileType === 'notes') {
        rawText = notesText.trim();
      } else if (uploadFile) {
        // Read file as Base64
        fileData = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(uploadFile);
        });
      }

      const newDoc = await processAndSaveDocument({
        userId: currentUser?.uid || 'guest_student',
        name: uploadDocName.trim(),
        subject: uploadSubject,
        fileType: uploadFileType,
        fileData,
        rawText,
        fileSizeFormatted: uploadFile
          ? `${(uploadFile.size / 1024).toFixed(1)} KB`
          : `${Math.round((rawText?.length || 0) / 1024)} KB`,
      });

      setSelectedDocId(newDoc.id);
      setIsUploadOpen(false);
      setUploadDocName('');
      setUploadFile(null);
      setNotesText('');
    } catch (err: any) {
      setUploadError(err?.message || 'Failed to process document. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  // Handle RAG Chat Query
  const handleSendChat = async (presetText?: string) => {
    const question = presetText || chatInput;
    if (!question.trim() || chatLoading || !selectedDoc) return;

    const userMessage = {
      id: 'rag_' + Date.now() + '_user',
      role: 'user' as const,
      content: question.trim(),
      timestamp: new Date().toISOString(),
    };

    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setChatLoading(true);

    try {
      const history = chatMessages.slice(-4).map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        content: m.content,
      }));

      const res = await queryDocumentRAG({
        question: question.trim(),
        documentName: selectedDoc.name,
        chunks: selectedDoc.chunks || [],
        conversationHistory: history,
      });

      const aiMessage = {
        id: 'rag_' + Date.now() + '_ai',
        role: 'assistant' as const,
        content: res.answer,
        sourceUsed: res.sourceUsed,
        retrievedChunks: res.retrievedChunks,
        timestamp: new Date().toISOString(),
      };

      setChatMessages(prev => [...prev, aiMessage]);
    } catch (err: any) {
      const errorMsg = {
        id: 'rag_' + Date.now() + '_err',
        role: 'assistant' as const,
        content: `⚠️ ${err?.message || 'Could not query study material. Please try again.'}`,
        timestamp: new Date().toISOString(),
      };
      setChatMessages(prev => [...prev, errorMsg]);
    } finally {
      setChatLoading(false);
    }
  };

  // Trigger Study Material Analysis
  const handleRunAnalysis = async (
    type: 'summarize' | 'explain' | 'mcqs' | 'questions' | 'flashcards' | 'key_concepts',
    subtype?: SummaryType
  ) => {
    if (!selectedDoc || analyzing) return;
    setAnalyzing(true);

    try {
      const data = await analyzeStudyDocument({
        documentId: selectedDoc.id,
        documentName: selectedDoc.name,
        text: selectedDoc.rawText || '',
        analysisType: type,
        summarySubtype: subtype || summarySubtype,
        userId: currentUser?.uid,
      });

      if (type === 'summarize' || type === 'explain') {
        setAnalysisResultText(data.result || '');
      } else if (type === 'mcqs') {
        setMcqs(data.mcqs || []);
      } else if (type === 'questions') {
        setImportantQuestions(data.questions || []);
      } else if (type === 'flashcards') {
        setFlashcards(data.flashcards || []);
        setActiveCardIndex(0);
        setCardFlipped(false);
      } else if (type === 'key_concepts') {
        setKeyConcepts(data.keyConcepts || []);
      }
    } catch (err: any) {
      alert(err?.message || 'Analysis failed. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleDeleteDoc = async (e: React.MouseEvent, docId: string) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to remove this study material?')) return;
    await deleteStudyDocument(docId, currentUser?.uid);
    if (selectedDocId === docId) {
      const remaining = documents.filter(d => d.id !== docId);
      setSelectedDocId(remaining[0]?.id || '');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-linear-to-r from-indigo-900 via-indigo-800 to-purple-900 text-white rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-radial from-purple-500/20 to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-indigo-200 border border-white/15">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Tier 2 • RAG-Based Vector Knowledge Base</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              AI Study Assistant & Document Analyzer
            </h1>
            <p className="text-xs sm:text-sm text-indigo-100/90 leading-relaxed">
              Upload textbook chapters, lecture notes, or syllabus guides. Ask questions with exact citations, generate instant multi-format summaries, practice MCQs, and flashcards for exam mastery.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setIsUploadOpen(true)}
              className="inline-flex items-center gap-2 bg-white text-indigo-900 hover:bg-indigo-50 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer active:scale-95"
            >
              <Upload className="w-4 h-4 text-indigo-600" />
              <span>Upload Material</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Document Sidebar + Working Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Document Selector Sidebar (4 Cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                <span>Your Materials ({documents.length})</span>
              </h3>
              <button
                onClick={() => setIsUploadOpen(true)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>

            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
              {documents.map(doc => {
                const isSelected = doc.id === selectedDoc?.id;
                return (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDocId(doc.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer relative group ${
                      isSelected
                        ? 'bg-indigo-50/80 border-indigo-300 ring-1 ring-indigo-400'
                        : 'bg-white hover:bg-slate-50 border-slate-200/80'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span
                            className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                              doc.fileType === 'pdf'
                                ? 'bg-rose-100 text-rose-700'
                                : doc.fileType === 'docx'
                                ? 'bg-blue-100 text-blue-700'
                                : 'bg-emerald-100 text-emerald-700'
                            }`}
                          >
                            {doc.fileType}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium truncate">
                            {doc.subject}
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-slate-800 line-clamp-1 group-hover:text-indigo-600 transition-colors">
                          {doc.name}
                        </h4>
                        <div className="flex items-center gap-3 mt-1 text-[10px] text-slate-400">
                          <span>{doc.fileSize}</span>
                          <span>•</span>
                          <span>{doc.chunkCount || 0} chunks</span>
                          <span>•</span>
                          <span className="text-emerald-600 font-medium flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5" /> Ready
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={e => handleDeleteDoc(e, doc.id)}
                        className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-600 rounded transition-opacity"
                        title="Delete material"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {documents.length === 0 && (
                <div className="text-center py-8 text-xs text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                  <FileText className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                  <p>No study materials uploaded yet.</p>
                  <button
                    onClick={() => setIsUploadOpen(true)}
                    className="mt-2 text-indigo-600 font-bold hover:underline"
                  >
                    Upload your first document
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Document Quick Metadata Box */}
          {selectedDoc && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs text-xs space-y-2.5">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-600" />
                <span>Active Knowledge Base</span>
              </h4>
              <p className="text-slate-600 font-medium line-clamp-2">{selectedDoc.name}</p>
              <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-100">
                <div className="bg-slate-50 p-2 rounded-lg">
                  <span className="text-slate-400 block">Extracted Characters</span>
                  <span className="font-bold text-slate-800">
                    {selectedDoc.extractedTextLength ? `${selectedDoc.extractedTextLength.toLocaleString()} chars` : 'Full Text'}
                  </span>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg">
                  <span className="text-slate-400 block">Vector Chunks</span>
                  <span className="font-bold text-indigo-600">
                    {selectedDoc.chunks?.length || 0} Indexed
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Main Working Panel (8 Cols) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Main Top Navigation Tabs */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-1.5 shadow-2xs flex items-center gap-1">
            <button
              onClick={() => setActiveTab('rag_chat')}
              className={`flex-1 py-2 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'rag_chat'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>💬 Ask My Material (RAG Chat)</span>
            </button>

            <button
              onClick={() => setActiveTab('analyzer')}
              className={`flex-1 py-2 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === 'analyzer'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>⚡ Study Material Analyzer</span>
            </button>
          </div>

          {/* TAB 1: RAG CHAT */}
          {activeTab === 'rag_chat' && (
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col h-[650px] overflow-hidden">
              {/* Chat Header */}
              <div className="p-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>Grounded Chat:</span>
                    <span className="text-indigo-600 font-semibold line-clamp-1">
                      {selectedDoc ? selectedDoc.name : 'Select a document'}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Answers strictly grounded in your text with vector-matched excerpts & citations.
                  </p>
                </div>

                <button
                  onClick={() => setChatMessages([])}
                  className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1 p-1.5 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer"
                  title="Clear chat"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Clear</span>
                </button>
              </div>

              {/* Chat Message Stream */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {chatMessages.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-2xs">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <div className="max-w-md space-y-1">
                      <h4 className="text-sm font-bold text-slate-800">
                        Ask any academic doubt from this document
                      </h4>
                      <p className="text-xs text-slate-500">
                        Our vector retrieval engine will search the material chunks, provide the exact source excerpt, and explain the concept clearly.
                      </p>
                    </div>

                    {/* Pre-built suggestions */}
                    <div className="w-full max-w-lg grid grid-cols-1 sm:grid-cols-2 gap-2 text-left pt-2">
                      {[
                        'What are the core definitions and concepts here?',
                        'Explain the key algorithm or formula mentioned',
                        'What are common exam traps or pitfalls in this topic?',
                        'Summarize the primary takeaways from this material',
                      ].map((promptText, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendChat(promptText)}
                          className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/50 text-[11px] font-medium text-slate-700 transition-colors text-left flex items-start gap-1.5 cursor-pointer"
                        >
                          <ChevronRight className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                          <span>{promptText}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {chatMessages.map(msg => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${
                      msg.role === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {msg.role === 'assistant' && (
                      <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-2xs mt-0.5">
                        <Bot className="w-4 h-4" />
                      </div>
                    )}

                    <div
                      className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                        msg.role === 'user'
                          ? 'bg-indigo-600 text-white rounded-tr-xs'
                          : 'bg-slate-50 border border-slate-200/90 text-slate-800 rounded-tl-xs shadow-2xs space-y-3'
                      }`}
                    >
                      {/* Markdown Answer */}
                      <div className="markdown-body">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>

                      {/* Source Citations & Excerpts Box */}
                      {msg.role === 'assistant' && msg.retrievedChunks && msg.retrievedChunks.length > 0 && (
                        <div className="pt-3 border-t border-slate-200/80 space-y-2">
                          <span className="text-[11px] font-bold text-slate-600 flex items-center gap-1.5">
                            <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                            <span>Retrieved Source Material Citations ({msg.retrievedChunks.length}):</span>
                          </span>

                          <div className="space-y-1.5">
                            {msg.retrievedChunks.map((chunk: any, cIdx: number) => (
                              <div
                                key={cIdx}
                                className="bg-white p-2.5 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1"
                              >
                                <div className="flex items-center justify-between text-[10px] text-slate-400 font-semibold">
                                  <span className="text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">
                                    {chunk.pageOrSection || `Section ${cIdx + 1}`}
                                  </span>
                                  {chunk.similarity && (
                                    <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                                      {Math.round(chunk.similarity * 100)}% Match
                                    </span>
                                  )}
                                </div>
                                <p className="italic text-slate-700 line-clamp-2">&ldquo;{chunk.content}&rdquo;</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}

                {chatLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                      <Bot className="w-4 h-4" />
                    </div>
                    <div className="bg-slate-50 border border-slate-200 rounded-2xl rounded-tl-xs p-3.5 flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce" />
                      <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce [animation-delay:0.2s]" />
                      <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce [animation-delay:0.4s]" />
                      <span className="text-xs text-slate-500 font-medium ml-1">
                        Searching vector chunks & generating grounded answer...
                      </span>
                    </div>
                  </div>
                )}
                <div ref={chatBottomRef} />
              </div>

              {/* Chat Input Bar */}
              <form
                onSubmit={e => {
                  e.preventDefault();
                  handleSendChat();
                }}
                className="p-3 border-t border-slate-200 bg-white flex items-center gap-2"
              >
                <input
                  type="text"
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  placeholder={`Ask questions about "${selectedDoc?.name || 'your material'}"...`}
                  className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                />
                <button
                  type="submit"
                  disabled={!chatInput.trim() || chatLoading}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer disabled:cursor-not-allowed"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Ask</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 2: STUDY MATERIAL ANALYZER */}
          {activeTab === 'analyzer' && (
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-5 space-y-5">
              {/* Sub Navigation Bar */}
              <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 pb-3">
                {[
                  { id: 'summaries', label: '📑 Multi-Format Summaries' },
                  { id: 'explain', label: '💡 Step-by-Step Breakdown' },
                  { id: 'mcqs', label: '🎯 Practice MCQs' },
                  { id: 'questions', label: '❓ Exam Questions' },
                  { id: 'flashcards', label: '📇 Active Recall Flashcards' },
                  { id: 'key_concepts', label: '📐 Formulas & Key Concepts' },
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setAnalyzerSubTab(tab.id as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                      analyzerSubTab === tab.id
                        ? 'bg-indigo-100 text-indigo-800'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* SUBTAB 1: SUMMARIES */}
              {analyzerSubTab === 'summaries' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    {/* Summary Subtypes */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      {[
                        { id: 'quick', label: 'Quick Summary' },
                        { id: 'detailed', label: 'Detailed Summary' },
                        { id: 'exam_notes', label: 'Exam Revision Notes' },
                        { id: 'important_points', label: 'Key Important Points' },
                        { id: 'one_page_sheet', label: 'One-Page Cheat Sheet' },
                      ].map(type => (
                        <button
                          key={type.id}
                          onClick={() => {
                            setSummarySubtype(type.id as SummaryType);
                            const cached = selectedDoc?.summaries?.[type.id as SummaryType];
                            setAnalysisResultText(cached || '');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer border ${
                            summarySubtype === type.id
                              ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {type.label}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={() => handleRunAnalysis('summarize', summarySubtype)}
                      disabled={analyzing}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{analyzing ? 'Generating...' : 'Generate Summary'}</span>
                    </button>
                  </div>

                  {/* Summary Display Box */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 min-h-[250px] relative">
                    {analyzing ? (
                      <div className="h-48 flex flex-col items-center justify-center gap-2 text-slate-500">
                        <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin" />
                        <p className="text-xs font-medium">Generating {summarySubtype.replace('_', ' ')}...</p>
                      </div>
                    ) : analysisResultText ? (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                          <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                            {summarySubtype.replace('_', ' ')} for &ldquo;{selectedDoc?.name}&rdquo;
                          </span>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(analysisResultText);
                              setCopiedSummary(true);
                              setTimeout(() => setCopiedSummary(false), 2000);
                            }}
                            className="text-xs text-indigo-600 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
                          >
                            {copiedSummary ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedSummary ? 'Copied' : 'Copy'}</span>
                          </button>
                        </div>
                        <div className="markdown-body text-xs sm:text-sm leading-relaxed text-slate-800">
                          <ReactMarkdown>{analysisResultText}</ReactMarkdown>
                        </div>
                      </div>
                    ) : (
                      <div className="h-48 flex flex-col items-center justify-center text-center text-slate-400 space-y-2">
                        <FileText className="w-8 h-8 text-slate-300" />
                        <p className="text-xs">No {summarySubtype.replace('_', ' ')} generated yet.</p>
                        <button
                          onClick={() => handleRunAnalysis('summarize', summarySubtype)}
                          className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer"
                        >
                          Click here to generate instant summary
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SUBTAB 2: EXPLAIN FOR BEGINNERS */}
              {analyzerSubTab === 'explain' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      Explains the uploaded document using intuitive analogies, everyday language, and step-by-step reasoning.
                    </p>
                    <button
                      onClick={() => handleRunAnalysis('explain')}
                      disabled={analyzing}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{analyzing ? 'Explaining...' : 'Explain Document'}</span>
                    </button>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 min-h-[250px]">
                    {analyzing ? (
                      <div className="h-48 flex flex-col items-center justify-center gap-2 text-slate-500">
                        <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin" />
                        <p className="text-xs font-medium">Deconstructing topics step-by-step...</p>
                      </div>
                    ) : analysisResultText ? (
                      <div className="markdown-body text-xs sm:text-sm leading-relaxed text-slate-800">
                        <ReactMarkdown>{analysisResultText}</ReactMarkdown>
                      </div>
                    ) : (
                      <div className="h-48 flex flex-col items-center justify-center text-center text-slate-400 space-y-2">
                        <BookOpen className="w-8 h-8 text-slate-300" />
                        <p className="text-xs">Click below to generate a step-by-step beginner-friendly breakdown.</p>
                        <button
                          onClick={() => handleRunAnalysis('explain')}
                          className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer"
                        >
                          Generate Explanation
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SUBTAB 3: PRACTICE MCQS */}
              {analyzerSubTab === 'mcqs' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      6 exam-style practice questions strictly extracted from this document with instant feedback.
                    </p>
                    <button
                      onClick={() => handleRunAnalysis('mcqs')}
                      disabled={analyzing}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Brain className="w-3.5 h-3.5" />
                      <span>{analyzing ? 'Generating...' : 'Generate Practice MCQs'}</span>
                    </button>
                  </div>

                  {analyzing ? (
                    <div className="h-48 flex flex-col items-center justify-center gap-2 text-slate-500">
                      <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin" />
                      <p className="text-xs font-medium">Drafting test questions from text...</p>
                    </div>
                  ) : mcqs.length > 0 ? (
                    <div className="space-y-4">
                      {mcqs.map((q, qIndex) => {
                        const selectedIdx = selectedOptionIndices[q.id];
                        const hasAnswered = selectedIdx !== undefined;
                        const isCorrect = selectedIdx === q.correctIndex;

                        return (
                          <div
                            key={q.id || qIndex}
                            className="p-4 rounded-xl border border-slate-200 bg-white space-y-3 shadow-2xs"
                          >
                            <h4 className="text-xs sm:text-sm font-bold text-slate-900 flex items-start gap-2">
                              <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-xs flex items-center justify-center shrink-0">
                                {qIndex + 1}
                              </span>
                              <span>{q.question}</span>
                            </h4>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                              {q.options.map((opt, oIdx) => {
                                let optClasses = 'border-slate-200 hover:bg-slate-50 text-slate-700';
                                if (hasAnswered) {
                                  if (oIdx === q.correctIndex) {
                                    optClasses = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold';
                                  } else if (selectedIdx === oIdx) {
                                    optClasses = 'border-rose-500 bg-rose-50 text-rose-900 font-bold';
                                  } else {
                                    optClasses = 'border-slate-100 text-slate-400 opacity-60';
                                  }
                                }

                                return (
                                  <button
                                    key={oIdx}
                                    onClick={() => {
                                      if (!hasAnswered) {
                                        setSelectedOptionIndices(prev => ({ ...prev, [q.id]: oIdx }));
                                      }
                                    }}
                                    disabled={hasAnswered}
                                    className={`p-2.5 rounded-xl border text-xs text-left transition-all cursor-pointer ${optClasses}`}
                                  >
                                    <span className="font-bold mr-1.5">{String.fromCharCode(65 + oIdx)}.</span>
                                    <span>{opt}</span>
                                  </button>
                                );
                              })}
                            </div>

                            {hasAnswered && (
                              <div
                                className={`p-3 rounded-xl text-xs ${
                                  isCorrect ? 'bg-emerald-50 text-emerald-900' : 'bg-rose-50 text-rose-900'
                                }`}
                              >
                                <span className="font-bold block mb-0.5">
                                  {isCorrect ? '✅ Correct Answer!' : '❌ Incorrect.'}
                                </span>
                                <p>{q.explanation}</p>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="h-48 flex flex-col items-center justify-center text-center text-slate-400 space-y-2 border-2 border-dashed border-slate-200 rounded-xl">
                      <Brain className="w-8 h-8 text-slate-300" />
                      <p className="text-xs">No practice test generated for this document yet.</p>
                      <button
                        onClick={() => handleRunAnalysis('mcqs')}
                        className="text-xs font-bold text-indigo-600 hover:underline"
                      >
                        Generate 6 Practice MCQs
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* SUBTAB 4: IMPORTANT EXAM QUESTIONS */}
              {analyzerSubTab === 'questions' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      High-probability exam questions with verified model answers directly mapped from this syllabus.
                    </p>
                    <button
                      onClick={() => handleRunAnalysis('questions')}
                      disabled={analyzing}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{analyzing ? 'Predicting...' : 'Extract Exam Questions'}</span>
                    </button>
                  </div>

                  {analyzing ? (
                    <div className="h-48 flex flex-col items-center justify-center gap-2 text-slate-500">
                      <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin" />
                      <p className="text-xs font-medium">Analyzing document for high-yield questions...</p>
                    </div>
                  ) : importantQuestions.length > 0 ? (
                    <div className="space-y-3">
                      {importantQuestions.map((q, idx) => (
                        <div
                          key={idx}
                          className="p-4 rounded-xl border border-slate-200 bg-white space-y-2 shadow-2xs"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                              {q.highYieldTag || 'High Probability'}
                            </span>
                            <span className="text-[11px] text-slate-400 font-medium">Question {idx + 1}</span>
                          </div>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900">{q.question}</h4>
                          <div className="pt-2 border-t border-slate-100 text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg">
                            <span className="font-bold text-indigo-700 block mb-1">Model Answer:</span>
                            <p>{q.answer}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="h-48 flex flex-col items-center justify-center text-center text-slate-400 space-y-2 border-2 border-dashed border-slate-200 rounded-xl">
                      <HelpCircle className="w-8 h-8 text-slate-300" />
                      <p className="text-xs">No exam questions extracted yet.</p>
                      <button
                        onClick={() => handleRunAnalysis('questions')}
                        className="text-xs font-bold text-indigo-600 hover:underline"
                      >
                        Extract 5 High-Yield Questions
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* SUBTAB 5: FLASHCARDS */}
              {analyzerSubTab === 'flashcards' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      Active recall digital flashcards to rapidly memorize core formulas, terminology, and theorems.
                    </p>
                    <button
                      onClick={() => handleRunAnalysis('flashcards')}
                      disabled={analyzing}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{analyzing ? 'Creating...' : 'Create Flashcards'}</span>
                    </button>
                  </div>

                  {analyzing ? (
                    <div className="h-48 flex flex-col items-center justify-center gap-2 text-slate-500">
                      <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin" />
                      <p className="text-xs font-medium">Extracting flashcard prompts...</p>
                    </div>
                  ) : flashcards.length > 0 ? (
                    <div className="max-w-md mx-auto space-y-4 text-center">
                      <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                        <span>
                          Card {activeCardIndex + 1} of {flashcards.length}
                        </span>
                        <span className="text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                          {flashcards[activeCardIndex]?.category}
                        </span>
                      </div>

                      {/* Interactive Flashcard */}
                      <div
                        onClick={() => setCardFlipped(!cardFlipped)}
                        className={`min-h-[220px] p-6 rounded-2xl border transition-all cursor-pointer flex flex-col items-center justify-center shadow-md select-none ${
                          cardFlipped
                            ? 'bg-indigo-900 text-white border-indigo-700'
                            : 'bg-white text-slate-800 border-slate-200 hover:border-indigo-300'
                        }`}
                      >
                        <span className="text-[10px] uppercase font-bold tracking-widest opacity-60 mb-2">
                          {cardFlipped ? '💡 ANSWER / DEFINITION (Click to flip)' : '❓ QUESTION (Click to flip)'}
                        </span>
                        <p className="text-sm sm:text-base font-bold leading-relaxed">
                          {cardFlipped
                            ? flashcards[activeCardIndex]?.back
                            : flashcards[activeCardIndex]?.front}
                        </p>
                      </div>

                      {/* Controls */}
                      <div className="flex items-center justify-center gap-3">
                        <button
                          onClick={() => {
                            setActiveCardIndex(prev => Math.max(0, prev - 1));
                            setCardFlipped(false);
                          }}
                          disabled={activeCardIndex === 0}
                          className="px-4 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 disabled:opacity-40 text-xs font-bold cursor-pointer"
                        >
                          Previous
                        </button>
                        <button
                          onClick={() => setCardFlipped(!cardFlipped)}
                          className="px-4 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 hover:bg-indigo-100 text-xs font-bold cursor-pointer"
                        >
                          Flip Card
                        </button>
                        <button
                          onClick={() => {
                            setActiveCardIndex(prev => Math.min(flashcards.length - 1, prev + 1));
                            setCardFlipped(false);
                          }}
                          disabled={activeCardIndex === flashcards.length - 1}
                          className="px-4 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 disabled:opacity-40 text-xs font-bold cursor-pointer"
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="h-48 flex flex-col items-center justify-center text-center text-slate-400 space-y-2 border-2 border-dashed border-slate-200 rounded-xl">
                      <Layers className="w-8 h-8 text-slate-300" />
                      <p className="text-xs">No active recall flashcards created yet.</p>
                      <button
                        onClick={() => handleRunAnalysis('flashcards')}
                        className="text-xs font-bold text-indigo-600 hover:underline"
                      >
                        Create 8 Digital Flashcards
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* SUBTAB 6: FORMULAS & KEY CONCEPTS */}
              {analyzerSubTab === 'key_concepts' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      Condensed reference table of key concepts, formulas, equations, and exam relevance.
                    </p>
                    <button
                      onClick={() => handleRunAnalysis('key_concepts')}
                      disabled={analyzing}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{analyzing ? 'Extracting...' : 'Extract Key Concepts'}</span>
                    </button>
                  </div>

                  {analyzing ? (
                    <div className="h-48 flex flex-col items-center justify-center gap-2 text-slate-500">
                      <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin" />
                      <p className="text-xs font-medium">Extracting formulas and concepts...</p>
                    </div>
                  ) : keyConcepts.length > 0 ? (
                    <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-2xs">
                      <table className="w-full text-left text-xs text-slate-700">
                        <thead className="bg-slate-50 text-[11px] font-bold text-slate-600 uppercase border-b border-slate-200">
                          <tr>
                            <th className="p-3">Concept / Term</th>
                            <th className="p-3">Core Definition</th>
                            <th className="p-3">Formula / Syntax</th>
                            <th className="p-3">Exam Weightage</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {keyConcepts.map((item, idx) => (
                            <tr key={idx} className="hover:bg-slate-50/70">
                              <td className="p-3 font-bold text-indigo-950 whitespace-nowrap">{item.concept}</td>
                              <td className="p-3 leading-relaxed">{item.definition}</td>
                              <td className="p-3 font-mono text-[11px] text-purple-700 bg-slate-50/50">
                                {item.formulaOrExample || '—'}
                              </td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-medium text-[10px]">
                                  {item.examRelevance || 'High Yield'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="h-48 flex flex-col items-center justify-center text-center text-slate-400 space-y-2 border-2 border-dashed border-slate-200 rounded-xl">
                      <BookOpen className="w-8 h-8 text-slate-300" />
                      <p className="text-xs">No formula sheet extracted yet.</p>
                      <button
                        onClick={() => handleRunAnalysis('key_concepts')}
                        className="text-xs font-bold text-indigo-600 hover:underline"
                      >
                        Extract Formulas & Key Concepts Table
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* UPLOAD MATERIAL MODAL */}
      {isUploadOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 sm:p-7 border border-slate-200 relative my-6"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={() => setIsUploadOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              ✕
            </button>

            <div className="flex items-center gap-3 mb-5">
              <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                <Upload className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Upload Study Material</h3>
                <p className="text-xs text-slate-500">
                  Chunked and embedded for RAG retrieval and instant AI analysis.
                </p>
              </div>
            </div>

            {uploadError && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{uploadError}</span>
              </div>
            )}

            <form onSubmit={handleFileUpload} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Document Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Operating Systems Chapter 4 - Memory Management"
                  value={uploadDocName}
                  onChange={e => setUploadDocName(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Subject / Course
                  </label>
                  <input
                    type="text"
                    value={uploadSubject}
                    onChange={e => setUploadSubject(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Format Type
                  </label>
                  <select
                    value={uploadFileType}
                    onChange={e => setUploadFileType(e.target.value as any)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden cursor-pointer"
                  >
                    <option value="pdf">PDF Document (.pdf)</option>
                    <option value="docx">Word Document (.docx)</option>
                    <option value="txt">Text File (.txt)</option>
                    <option value="notes">Paste Lecture Notes</option>
                  </select>
                </div>
              </div>

              {uploadFileType === 'notes' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Paste Lecture Notes / Content <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    rows={6}
                    required
                    placeholder="Paste textbook excerpts, professor notes, formulas or questions here..."
                    value={notesText}
                    onChange={e => setNotesText(e.target.value)}
                    className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden leading-relaxed"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Choose File <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="file"
                    accept={
                      uploadFileType === 'pdf'
                        ? '.pdf'
                        : uploadFileType === 'docx'
                        ? '.docx,.doc'
                        : '.txt'
                    }
                    onChange={e => {
                      if (e.target.files && e.target.files[0]) {
                        setUploadFile(e.target.files[0]);
                        if (!uploadDocName) {
                          setUploadDocName(e.target.files[0].name.replace(/\.[^/.]+$/, ''));
                        }
                      }
                    }}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                  />
                </div>
              )}

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsUploadOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploading}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-2"
                >
                  {uploading && <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
                  <span>{uploading ? 'Processing Chunks...' : 'Process Document'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
