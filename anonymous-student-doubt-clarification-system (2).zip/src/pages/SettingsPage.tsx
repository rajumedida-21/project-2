import React, { useState } from 'react';
import {
  Settings,
  Languages,
  Volume2,
  Bell,
  Shield,
  User,
  Smartphone,
  Check,
  Moon,
  Sun,
  Monitor,
  Sparkles,
  Wifi,
  HardDrive,
  Download,
} from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { useTheme } from '../context/ThemeContext';
import { usePWAInstall } from '../utils/usePWAInstall';
import { useOnlineStatus } from '../utils/useOnlineStatus';
import { useTextToSpeech } from '../utils/useTextToSpeech';

export const SettingsPage: React.FC = () => {
  const {
    settings,
    profile,
    updateSettings,
    updateNotificationSettings,
    updatePrivacySettings,
    updateProfile,
  } = useSettings();

  const { theme, setTheme } = useTheme();
  const { isInstallable, install } = usePWAInstall();
  const { isOnline } = useOnlineStatus();
  const { speak, isPlaying } = useTextToSpeech();

  const [savedFeedback, setSavedFeedback] = useState(false);

  const handleSaveNotification = () => {
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 2000);
  };

  const handleTestVoice = () => {
    const sampleText =
      settings.defaultLanguage === 'Telugu'
        ? 'నమస్కారం! నేను మీ AI అకడమిక్ ట్యూటర్‌ని. మీ సందేహాలను నివృత్తి చేయడానికి సిద్ధంగా ఉన్నాను.'
        : settings.defaultLanguage === 'Hindi'
        ? 'नमस्ते! मैं आपका AI शैक्षणिक ट्यूटर हूँ। आपकी पढ़ाई में मदद करने के लिए तैयार हूँ।'
        : 'Hello! I am your AI Academic Tutor, ready to assist your learning journey.';

    speak(
      sampleText,
      'test_voice',
      settings.defaultLanguage,
      settings.autoSpeechRate,
      settings.speechPitch
    );
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-slate-700 to-indigo-700 text-white flex items-center justify-center shadow-xs">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Student Platform Settings</h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Customize your multilingual AI tutor, voice speed, privacy preferences, and notifications.
            </p>
          </div>
        </div>

        {savedFeedback && (
          <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl flex items-center gap-1">
            <Check className="w-3.5 h-3.5" /> Preferences Saved
          </span>
        )}
      </div>

      {/* Grid of Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 1. Theme & Appearance */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Sun className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Theme & Display</h3>
              <p className="text-[11px] text-slate-500">Choose your visual reading comfort.</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setTheme('light');
                updateSettings({ theme: 'light' });
              }}
              className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-xs font-semibold transition-all ${
                theme === 'light'
                  ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 shadow-2xs'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-500" />
              <span>Light</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setTheme('dark');
                updateSettings({ theme: 'dark' });
              }}
              className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-xs font-semibold transition-all ${
                theme === 'dark'
                  ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 shadow-2xs'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Moon className="w-4 h-4 text-indigo-500" />
              <span>Dark</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setTheme('system');
                updateSettings({ theme: 'system' });
              }}
              className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-xs font-semibold transition-all ${
                theme === 'system'
                  ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 shadow-2xs'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Monitor className="w-4 h-4 text-slate-500" />
              <span>System</span>
            </button>
          </div>
        </div>

        {/* 2. Language & Multilingual AI */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Languages className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Default AI Tutor Language</h3>
              <p className="text-[11px] text-slate-500">
                AI explains concepts in this language while preserving code & math.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1">
            <button
              type="button"
              onClick={() => updateSettings({ defaultLanguage: 'English' })}
              className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-semibold transition-all ${
                settings.defaultLanguage === 'English'
                  ? 'border-purple-600 bg-purple-50/50 text-purple-800 shadow-2xs'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span className="font-bold">English</span>
              <span className="text-[10px] text-slate-500">Standard</span>
            </button>

            <button
              type="button"
              onClick={() => updateSettings({ defaultLanguage: 'Telugu' })}
              className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-semibold transition-all ${
                settings.defaultLanguage === 'Telugu'
                  ? 'border-purple-600 bg-purple-50/50 text-purple-800 shadow-2xs'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span className="font-bold">తెలుగు</span>
              <span className="text-[10px] text-slate-500">Telugu</span>
            </button>

            <button
              type="button"
              onClick={() => updateSettings({ defaultLanguage: 'Hindi' })}
              className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs font-semibold transition-all ${
                settings.defaultLanguage === 'Hindi'
                  ? 'border-purple-600 bg-purple-50/50 text-purple-800 shadow-2xs'
                  : 'border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span className="font-bold">हिन्दी</span>
              <span className="text-[10px] text-slate-500">Hindi</span>
            </button>
          </div>
        </div>

        {/* 3. Voice AI & Text to Speech Controls */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Voice AI & Read-Aloud</h3>
                <p className="text-[11px] text-slate-500">Configure speech synthesis options.</p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleTestVoice}
              disabled={isPlaying}
              className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              {isPlaying ? 'Speaking...' : 'Test Voice'}
            </button>
          </div>

          <div className="space-y-3 pt-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-medium text-slate-700">Speech Rate ({settings.autoSpeechRate || 1.0}x)</span>
              <input
                type="range"
                min="0.75"
                max="1.5"
                step="0.05"
                value={settings.autoSpeechRate || 1.0}
                onChange={e => updateSettings({ autoSpeechRate: parseFloat(e.target.value) })}
                className="w-32 accent-indigo-600 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="font-medium text-slate-700">Pitch ({settings.speechPitch || 1.0}x)</span>
              <input
                type="range"
                min="0.8"
                max="1.2"
                step="0.05"
                value={settings.speechPitch || 1.0}
                onChange={e => updateSettings({ speechPitch: parseFloat(e.target.value) })}
                className="w-32 accent-indigo-600 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* 4. Privacy & Anonymity Settings */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Privacy & Anonymity Controls</h3>
              <p className="text-[11px] text-slate-500">
                You are always in control of your academic identity.
              </p>
            </div>
          </div>

          <div className="space-y-2.5 text-xs pt-1">
            <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 cursor-pointer">
              <div>
                <span className="font-semibold text-slate-800 block">Post Doubts Anonymously</span>
                <span className="text-[11px] text-slate-500">Hide your user ID on community questions</span>
              </div>
              <input
                type="checkbox"
                checked={settings.privacy.anonymousByDefault}
                onChange={e => updatePrivacySettings({ anonymousByDefault: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded-md focus:ring-indigo-500"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 cursor-pointer">
              <div>
                <span className="font-semibold text-slate-800 block">Show on Responsible Leaderboard</span>
                <span className="text-[11px] text-slate-500">Participate in peer learning rankings</span>
              </div>
              <input
                type="checkbox"
                checked={settings.privacy.showOnLeaderboard}
                onChange={e => updatePrivacySettings({ showOnLeaderboard: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded-md focus:ring-indigo-500"
              />
            </label>
          </div>
        </div>

        {/* 5. Notification Toggles */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Smart Notifications</h3>
              <p className="text-[11px] text-slate-500">Choose which study nudges to receive.</p>
            </div>
          </div>

          <div className="space-y-2 text-xs pt-1">
            <label className="flex items-center justify-between p-2 rounded-xl border border-slate-100 bg-slate-50/50 cursor-pointer">
              <span className="text-slate-800 font-medium">Spaced Revision Flashcard Reminders</span>
              <input
                type="checkbox"
                checked={settings.notifications.revisionReminders}
                onChange={e => updateNotificationSettings({ revisionReminders: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded-md"
              />
            </label>
            <label className="flex items-center justify-between p-2 rounded-xl border border-slate-100 bg-slate-50/50 cursor-pointer">
              <span className="text-slate-800 font-medium">Peer Answer Updates on My Doubts</span>
              <input
                type="checkbox"
                checked={settings.notifications.communityAnswers}
                onChange={e => updateNotificationSettings({ communityAnswers: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded-md"
              />
            </label>
            <label className="flex items-center justify-between p-2 rounded-xl border border-slate-100 bg-slate-50/50 cursor-pointer">
              <span className="text-slate-800 font-medium">Daily AI Study Schedule Recommendations</span>
              <input
                type="checkbox"
                checked={settings.notifications.aiRecommendations}
                onChange={e => updateNotificationSettings({ aiRecommendations: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded-md"
              />
            </label>
          </div>
        </div>

        {/* 6. PWA & Offline Status */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Progressive Web App (PWA) & Offline</h3>
              <p className="text-[11px] text-slate-500">
                Install as a standalone app on your desktop or phone.
              </p>
            </div>
          </div>

          <div className="space-y-3 text-xs pt-1">
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2">
                <Wifi className={`w-4 h-4 ${isOnline ? 'text-emerald-500' : 'text-amber-500'}`} />
                <span className="font-semibold text-slate-800">
                  Connection Status: {isOnline ? 'Online & Synchronized' : 'Offline Mode (Local Cache Active)'}
                </span>
              </div>
            </div>

            {isInstallable ? (
              <button
                type="button"
                onClick={install}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Install Academic Doubt App on Device</span>
              </button>
            ) : (
              <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-center">
                ✓ PWA Service Worker Registered & Assets Cached
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
