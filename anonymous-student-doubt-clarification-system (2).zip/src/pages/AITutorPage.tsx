import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  User,
  Send,
  Sparkles,
  Trash2,
  Copy,
  Check,
  HelpCircle,
  Lightbulb,
  Code,
  ArrowRight,
  BookOpen,
  Camera,
  X,
  Eye,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Pause,
  Play,
  Square,
  Globe,
  Languages,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { AIChatMessage, SupportedLanguage } from '../types';
import {
  askAIDoubtAssistant,
  saveAIChatMessage,
  subscribeToAIChatMessages,
  clearAIChatMessages,
} from '../services/aiService';
import { useAuth } from '../context/AuthContext';
import { useSpeechRecognition } from '../utils/useSpeechRecognition';
import { useTextToSpeech } from '../utils/useTextToSpeech';
import { recordActivityEvent } from '../services/gamificationService';
import { useSettings } from '../context/SettingsContext';

const QUICK_PROMPTS = [
  'Explain recursion simply with a stack diagram analogy',
  'Why does binary search require a sorted array?',
  'Explain DBMS Normalization from 1NF to 3NF with examples',
  'What is dynamic programming vs divide and conquer?',
  'Give me a practice problem on linked lists with a hint',
  'Explain time complexity and Big-O notation intuitively',
];

interface AITutorPageProps {
  onNavigateToQuiz?: () => void;
  onNavigateToAdvisor?: () => void;
  initialPrompt?: string;
}

export const AITutorPage: React.FC<AITutorPageProps> = ({
  onNavigateToQuiz,
  onNavigateToAdvisor,
  initialPrompt,
}) => {
  const { currentUser } = useAuth();
  const { settings } = useSettings();
  const [messages, setMessages] = useState<AIChatMessage[]>([]);
  const [inputPrompt, setInputPrompt] = useState(initialPrompt || '');

  useEffect(() => {
    if (initialPrompt) {
      setInputPrompt(initialPrompt);
    }
  }, [initialPrompt]);
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeSubject, setActiveSubject] = useState('Computer Science');
  const [selectedLanguage, setSelectedLanguage] = useState<SupportedLanguage>(
    settings.defaultLanguage || 'English'
  );
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [imageFileName, setImageFileName] = useState<string | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [showImageModeBanner, setShowImageModeBanner] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Speech Recognition (Voice Input)
  const {
    isSupported: isSpeechSupported,
    status: speechStatus,
    transcript,
    interimTranscript,
    errorMessage: speechError,
    startListening,
    stopListening,
    resetTranscript,
  } = useSpeechRecognition(selectedLanguage);

  // Text to Speech (Voice Output)
  const {
    isSupported: isTtsSupported,
    isPlaying: isTtsPlaying,
    isPaused: isTtsPaused,
    currentTextId: ttsMessageId,
    speak,
    pause: pauseTts,
    resume: resumeTts,
    stop: stopTts,
  } = useTextToSpeech();

  // Update input text when speech transcript updates
  useEffect(() => {
    if (transcript) {
      setInputPrompt(transcript);
    }
  }, [transcript]);

  useEffect(() => {
    const unsub = subscribeToAIChatMessages(currentUser?.uid || 'guest_student', msgs => {
      setMessages(msgs);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading, speechStatus]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) {
        alert('Image must be under 5MB');
        return;
      }
      setImageFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveAttachedImage = () => {
    setAttachedImage(null);
    setImageFileName(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSendMessage = async (
    textToSend?: string,
    actionType: 'normal' | 'simpler' | 'example' | 'hint' | 'solution' | 'practice_question' = 'normal'
  ) => {
    if (speechStatus === 'listening') {
      stopListening();
    }

    const finalMsg = textToSend || inputPrompt;
    if ((!finalMsg.trim() && !attachedImage) || loading) return;

    const currentImage = attachedImage;

    const userMsg: AIChatMessage = {
      id: 'msg_' + Date.now() + '_user',
      role: 'user',
      content: finalMsg.trim() || (currentImage ? 'Please analyze this doubt image step-by-step.' : ''),
      timestamp: new Date().toISOString(),
      actionType,
      imageUrl: currentImage || undefined,
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInputPrompt('');
    resetTranscript();
    setAttachedImage(null);
    setImageFileName(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    setLoading(true);

    const userId = currentUser?.uid || 'guest_student';
    saveAIChatMessage(userId, userMsg);

    // Gamification XP
    recordActivityEvent({ type: 'doubt_asked' });
    if (selectedLanguage !== 'English') {
      recordActivityEvent({ type: 'multilingual' });
    }

    try {
      const history = updatedMessages.slice(-6).map(m => ({
        role: (m.role === 'user' ? 'user' : 'model') as 'user' | 'model',
        content: m.content,
      }));

      const reply = await askAIDoubtAssistant({
        message: userMsg.content,
        conversationHistory: history,
        actionType,
        subject: activeSubject,
        image: currentImage || undefined,
        language: selectedLanguage,
      });

      const aiMsg: AIChatMessage = {
        id: 'msg_' + Date.now() + '_ai',
        role: 'assistant',
        content: reply,
        timestamp: new Date().toISOString(),
        actionType,
      };

      setMessages(prev => [...prev, aiMsg]);
      saveAIChatMessage(userId, aiMsg);

      // Auto read if voice output is enabled
      if (settings.voiceEnabled && isTtsSupported && messages.length === 0) {
        speak(reply, aiMsg.id, selectedLanguage, settings.autoSpeechRate || 1.0, settings.speechPitch || 1.0);
      }
    } catch (err: any) {
      const errorMsg: AIChatMessage = {
        id: 'msg_' + Date.now() + '_err',
        role: 'assistant',
        content: `⚠️ **AI Tutor Notice:** ${err?.message || 'I could not process your query at this moment. Please check your network or try again.'}`,
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickAction = (
    actionType: 'simpler' | 'example' | 'hint' | 'solution' | 'practice_question'
  ) => {
    let prompt = '';
    switch (actionType) {
      case 'simpler':
        prompt = selectedLanguage === 'Telugu'
          ? 'దయచేసి దీనిని ఒక సాధారణ ఉదాహరణతో మరింత సులభంగా వివరించండి.'
          : selectedLanguage === 'Hindi'
          ? 'कृपया इसे एक सरल उदाहरण के साथ और आसानी से समझाइए।'
          : 'Could you please explain that in much simpler terms with an everyday analogy?';
        break;
      case 'example':
        prompt = selectedLanguage === 'Telugu'
          ? 'దీనికి ఒక ఆచరణాత్మక ఉదాహరణ లేదా కోడ్ నమూనా ఇవ్వండి.'
          : selectedLanguage === 'Hindi'
          ? 'कृपया इसका एक व्यावहारिक कोड या गणितीय उदाहरण दीजिए।'
          : 'Can you give me a practical, step-by-step example or code walkthrough of this?';
        break;
      case 'hint':
        prompt = selectedLanguage === 'Telugu'
          ? 'నేను స్వయంగా ఆలోచించి పరిష్కరించడానికి ఒక క్లూ లేదా సూచన ఇవ్వండి.'
          : selectedLanguage === 'Hindi'
          ? 'मुझे इसे स्वयं हल करने के लिए एक संकेत (hint) दीजिए।'
          : 'Can you give me a guiding hint to help me think about how to solve this myself?';
        break;
      case 'solution':
        prompt = selectedLanguage === 'Telugu'
          ? 'దయచేసి పూర్తి దశలవారీ పరిష్కారాన్ని చూపించండి.'
          : selectedLanguage === 'Hindi'
          ? 'कृपया पूरा चरण-दर-चरण समाधान दिखाइए।'
          : 'Please show the full step-by-step solution with verification.';
        break;
      case 'practice_question':
        prompt = selectedLanguage === 'Telugu'
          ? 'నా అవగాహనను పరీక్షించడానికి ఈ అంశంపై ఒక అభ్యాస ప్రశ్న ఇవ్వండి.'
          : selectedLanguage === 'Hindi'
          ? 'मेरी समझ को परखने के लिए इस अवधारणा पर एक अभ्यास प्रश्न दीजिए।'
          : 'Give me a short practice question on this concept to test my understanding.';
        break;
    }
    handleSendMessage(prompt, actionType);
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearHistory = async () => {
    if (confirm('Clear all conversation history with the AI Tutor?')) {
      stopTts();
      await clearAIChatMessages(currentUser?.uid || 'guest_student');
      setMessages([]);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 h-[calc(100vh-5rem)] flex flex-col gap-4">
      {/* Top Header Bar with Language & Voice Status */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center shadow-xs">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-slate-900">AI Academic Doubt Assistant</h1>
              <span className="inline-flex items-center gap-1 bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                <Sparkles className="w-2.5 h-2.5" />
                Tier 3 Next-Gen
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Multimodal Vision, Voice Assistant & Multilingual support (English, తెలుగు, हिन्दी).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Multilingual Selector */}
          <div className="flex items-center gap-1.5 bg-slate-100/90 border border-slate-200 rounded-lg p-1">
            <Languages className="w-3.5 h-3.5 text-slate-500 ml-1" />
            <button
              type="button"
              onClick={() => setSelectedLanguage('English')}
              className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${
                selectedLanguage === 'English'
                  ? 'bg-white text-indigo-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setSelectedLanguage('Telugu')}
              className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${
                selectedLanguage === 'Telugu'
                  ? 'bg-white text-indigo-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Telugu (తెలుగు)"
            >
              తెలుగు
            </button>
            <button
              type="button"
              onClick={() => setSelectedLanguage('Hindi')}
              className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${
                selectedLanguage === 'Hindi'
                  ? 'bg-white text-indigo-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Hindi (हिन्दी)"
            >
              हिन्दी
            </button>
          </div>

          <select
            value={activeSubject}
            onChange={e => setActiveSubject(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 font-medium focus:ring-1 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="Computer Science">Computer Science & DSA</option>
            <option value="Mathematics">Engineering Mathematics</option>
            <option value="DBMS">Database Systems</option>
            <option value="Operating Systems">Operating Systems</option>
            <option value="Computer Networks">Computer Networks</option>
            <option value="Machine Learning">AI & Machine Learning</option>
            <option value="General Engineering">General Engineering</option>
          </select>

          {messages.length > 0 && (
            <button
              onClick={handleClearHistory}
              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition-colors"
              title="Clear conversation"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Speech Recognition Error Notice if any */}
      {speechError && (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-xs text-rose-800 flex items-center justify-between shrink-0">
          <span>{speechError}</span>
          <button
            onClick={() => resetTranscript()}
            className="text-rose-600 font-bold hover:underline ml-2"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Voice Listening Active Ribbon */}
      {speechStatus === 'listening' && (
        <div className="bg-indigo-600 text-white rounded-2xl p-3 px-4 flex items-center justify-between shadow-md shrink-0 animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-rose-400 animate-ping" />
            <div className="text-xs sm:text-sm font-medium">
              Listening in <span className="font-bold underline">{selectedLanguage}</span>... Speak your doubt clearly.
            </div>
          </div>
          <button
            type="button"
            onClick={stopListening}
            className="px-3 py-1 bg-white text-indigo-700 rounded-lg font-bold text-xs hover:bg-indigo-50 cursor-pointer"
          >
            Done Speaking
          </button>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto bg-slate-50/50 rounded-2xl border border-slate-200/80 p-4 sm:p-6 space-y-6">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-xl mx-auto py-8 space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center shadow-inner">
              <Bot className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-lg font-bold text-slate-900">
                {selectedLanguage === 'Telugu'
                  ? 'ఈ రోజు మీరు ఏ అకడమిక్ కాన్సెప్ట్‌ను నేర్చుకోవాలనుకుంటున్నారు?'
                  : selectedLanguage === 'Hindi'
                  ? 'आज आप कौन सी शैक्षणिक अवधारणा सीखना चाहते हैं?'
                  : 'What academic concept would you like to master today?'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                {selectedLanguage === 'Telugu'
                  ? 'వాయిస్ లేదా టెక్స్ట్ ద్వారా ఏవైనా సందేహాలు అడగండి. తెలుగులో స్టెప్ బై స్టెప్ వివరణ పొందండి.'
                  : selectedLanguage === 'Hindi'
                  ? 'बोलकर या लिखकर कोई भी प्रश्न पूछें। हिन्दी में सटीक और सरल चरण-दर-चरण समाधान प्राप्त करें।'
                  : 'Ask via voice or text in English, Telugu, or Hindi. I break down concepts step-by-step with voice read-aloud.'}
              </p>
            </div>

            {/* Quick Starter Cards */}
            <div className="w-full text-left space-y-2 pt-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Suggested Academic Doubts
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {QUICK_PROMPTS.map((prompt, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSendMessage(prompt)}
                    className="p-3 bg-white hover:bg-indigo-50/60 rounded-xl border border-slate-200 hover:border-indigo-300 text-xs text-slate-700 text-left transition-all flex items-start justify-between gap-2 group cursor-pointer shadow-2xs"
                  >
                    <span>{prompt}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-indigo-600 shrink-0 mt-0.5" />
                  </button>
                ))}
              </div>
            </div>

            {/* Shortcut hints to Quiz and Advisor */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-4 text-xs text-slate-500">
              {onNavigateToQuiz && (
                <button
                  type="button"
                  onClick={onNavigateToQuiz}
                  className="inline-flex items-center gap-1.5 text-indigo-600 hover:underline font-semibold"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Generate an AI Quiz instead</span>
                </button>
              )}
              {onNavigateToAdvisor && (
                <button
                  type="button"
                  onClick={onNavigateToAdvisor}
                  className="inline-flex items-center gap-1.5 text-indigo-600 hover:underline font-semibold"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Create a Personalized Study Plan</span>
                </button>
              )}
            </div>
          </div>
        ) : (
          messages.map(msg => (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-3xl ${
                msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-2xs ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gradient-to-tr from-purple-600 to-indigo-600 text-white'
                }`}
              >
                {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div className="space-y-2 max-w-2xl">
                <div
                  className={`rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-indigo-600 text-white rounded-tr-xs shadow-xs'
                      : 'bg-white text-slate-900 border border-slate-200/90 rounded-tl-xs shadow-2xs'
                  }`}
                >
                  {msg.role === 'user' ? (
                    <div>
                      {msg.imageUrl && (
                        <div className="mb-2 rounded-xl overflow-hidden max-w-xs border border-white/20 bg-slate-900/60 p-1">
                          <img
                            src={msg.imageUrl}
                            alt="User doubt attachment"
                            className="max-h-48 w-auto rounded-lg object-contain cursor-pointer hover:opacity-90 transition-opacity"
                            onClick={() => setLightboxImage(msg.imageUrl || null)}
                          />
                          <span className="text-[10px] text-white/80 block mt-1 px-1 flex items-center gap-1">
                            <Eye className="w-3 h-3" /> Click to enlarge
                          </span>
                        </div>
                      )}
                      <div className="whitespace-pre-wrap">{msg.content}</div>
                    </div>
                  ) : (
                    <div className="prose prose-xs sm:prose-sm max-w-none dark:prose-invert">
                      <div className="markdown-body">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    </div>
                  )}
                </div>

                {/* AI Response Voice Read-Aloud & Quick Follow-ups */}
                {msg.role === 'assistant' && (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
                      <div className="flex items-center gap-2">
                        <span>AI Tutor</span>
                        {isTtsSupported && (
                          <div className="flex items-center gap-1">
                            {ttsMessageId === msg.id && isTtsPlaying ? (
                              <div className="flex items-center gap-1 bg-indigo-50 border border-indigo-200 text-indigo-700 px-2 py-0.5 rounded-full">
                                <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-ping" />
                                <span className="font-semibold">Speaking</span>
                                <button
                                  type="button"
                                  onClick={isTtsPaused ? resumeTts : pauseTts}
                                  className="p-1 hover:text-indigo-900"
                                  title={isTtsPaused ? 'Resume' : 'Pause'}
                                >
                                  {isTtsPaused ? <Play className="w-2.5 h-2.5" /> : <Pause className="w-2.5 h-2.5" />}
                                </button>
                                <button
                                  type="button"
                                  onClick={stopTts}
                                  className="p-1 hover:text-indigo-900"
                                  title="Stop"
                                >
                                  <Square className="w-2.5 h-2.5 fill-current" />
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => speak(msg.content, msg.id, selectedLanguage, settings.autoSpeechRate, settings.speechPitch)}
                                className="inline-flex items-center gap-1 text-slate-500 hover:text-indigo-600 bg-slate-100 hover:bg-indigo-50 px-2 py-0.5 rounded-full transition-colors cursor-pointer"
                                title="Listen to AI Voice Explanation"
                              >
                                <Volume2 className="w-3 h-3 text-indigo-500" />
                                <span>Read Aloud</span>
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => handleCopyMessage(msg.id, msg.content)}
                        className="inline-flex items-center gap-1 hover:text-slate-700 cursor-pointer"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span className="text-emerald-600 font-medium">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Quick follow-up teaching buttons */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleQuickAction('simpler')}
                        className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-[11px] text-slate-700 font-medium transition-colors cursor-pointer shadow-2xs flex items-center gap-1"
                      >
                        <Lightbulb className="w-3 h-3 text-amber-500" />
                        <span>{selectedLanguage === 'Telugu' ? 'మరింత సులభంగా' : selectedLanguage === 'Hindi' ? 'और आसान' : 'Explain simpler'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleQuickAction('example')}
                        className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-[11px] text-slate-700 font-medium transition-colors cursor-pointer shadow-2xs flex items-center gap-1"
                      >
                        <Code className="w-3 h-3 text-indigo-500" />
                        <span>{selectedLanguage === 'Telugu' ? 'ఉదాహరణ' : selectedLanguage === 'Hindi' ? 'उदाहरण' : 'Give example'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleQuickAction('hint')}
                        className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-[11px] text-slate-700 font-medium transition-colors cursor-pointer shadow-2xs flex items-center gap-1"
                      >
                        <HelpCircle className="w-3 h-3 text-purple-500" />
                        <span>{selectedLanguage === 'Telugu' ? 'సూచన (Hint)' : selectedLanguage === 'Hindi' ? 'संकेत (Hint)' : 'Give hint'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleQuickAction('solution')}
                        className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-[11px] text-slate-700 font-medium transition-colors cursor-pointer shadow-2xs flex items-center gap-1"
                      >
                        <Check className="w-3 h-3 text-emerald-500" />
                        <span>{selectedLanguage === 'Telugu' ? 'పూర్తి సమాధానం' : selectedLanguage === 'Hindi' ? 'पूरा समाधान' : 'Show solution'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleQuickAction('practice_question')}
                        className="px-2.5 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-[11px] text-slate-700 font-medium transition-colors cursor-pointer shadow-2xs flex items-center gap-1"
                      >
                        <Sparkles className="w-3 h-3 text-indigo-600" />
                        <span>{selectedLanguage === 'Telugu' ? 'ప్రాక్టీస్ ప్రశ్న' : selectedLanguage === 'Hindi' ? 'अभ्यास प्रश्न' : 'Practice question'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))
        )}

        {loading && (
          <div className="flex gap-3 max-w-xl mr-auto">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white rounded-2xl rounded-tl-xs p-4 border border-slate-200 shadow-2xs flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce" />
              <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce [animation-delay:0.2s]" />
              <div className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce [animation-delay:0.4s]" />
              <span className="text-xs text-slate-500 ml-1 font-medium">
                {selectedLanguage === 'Telugu'
                  ? 'AI ట్యూటర్ సమాధానాన్ని ఆలోచించి రూపొందిస్తోంది...'
                  : selectedLanguage === 'Hindi'
                  ? 'AI ट्यूटर उत्तर तैयार कर रहा है...'
                  : 'AI Tutor is thinking and structuring explanation...'}
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Attached Image Preview Chip */}
      {attachedImage && (
        <div className="bg-white rounded-xl p-2 border border-indigo-200 shadow-2xs flex items-center gap-3 shrink-0">
          <img
            src={attachedImage}
            alt="Preview"
            className="w-10 h-10 rounded-lg object-cover bg-slate-900 border border-slate-200"
          />
          <div className="flex-1 min-w-0">
            <span className="text-xs font-semibold text-slate-800 block truncate">
              {imageFileName || 'Attached doubt image'}
            </span>
            <span className="text-[10px] text-indigo-600 font-medium flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" /> Multimodal Vision Ready
            </span>
          </div>
          <button
            type="button"
            onClick={handleRemoveAttachedImage}
            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition-colors"
            title="Remove image"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Message & Voice Input Box */}
      <form
        onSubmit={e => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="bg-white rounded-2xl p-2 border border-slate-200/90 shadow-xs flex items-center gap-2 shrink-0 focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 transition-all"
      >
        <input
          type="file"
          ref={fileInputRef}
          accept="image/*"
          onChange={handleImageSelect}
          className="hidden"
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-colors cursor-pointer"
          title="Upload photo of equation, textbook, code, or circuit diagram"
        >
          <Camera className="w-4 h-4" />
        </button>

        {/* Voice Input Microphone Button */}
        {isSpeechSupported && (
          <button
            type="button"
            onClick={speechStatus === 'listening' ? stopListening : startListening}
            className={`p-2 rounded-xl transition-all cursor-pointer ${
              speechStatus === 'listening'
                ? 'bg-rose-500 text-white shadow-md animate-pulse'
                : 'text-slate-500 hover:text-indigo-600 hover:bg-indigo-50'
            }`}
            title={
              speechStatus === 'listening'
                ? 'Stop Voice Recording'
                : `Ask by Voice in ${selectedLanguage}`
            }
          >
            {speechStatus === 'listening' ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
        )}

        <textarea
          value={inputPrompt}
          onChange={e => setInputPrompt(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSendMessage();
            }
          }}
          rows={1}
          placeholder={
            attachedImage
              ? "Add instructions for this image (e.g. 'Explain step 2', 'Find bug')..."
              : speechStatus === 'listening'
              ? `Listening in ${selectedLanguage}...`
              : selectedLanguage === 'Telugu'
              ? 'మీ అకడమిక్ సందేహాన్ని ఇక్కడ టైప్ చేయండి లేదా మాట్లాడండి...'
              : selectedLanguage === 'Hindi'
              ? 'अपना शैक्षणिक प्रश्न यहाँ लिखें या बोलें...'
              : "Ask an academic doubt or click mic to speak... (e.g., 'Explain QuickSort', 'Solve this equation')"
          }
          className="flex-1 px-3 py-2 text-xs sm:text-sm bg-transparent border-none focus:outline-none resize-none text-slate-800 placeholder-slate-400 max-h-32"
        />

        <button
          type="submit"
          disabled={(!inputPrompt.trim() && !attachedImage) || loading}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl font-semibold text-xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed shadow-xs"
        >
          <Send className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Ask AI</span>
        </button>
      </form>

      {/* Lightbox Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] bg-transparent" onClick={e => e.stopPropagation()}>
            <button
              type="button"
              onClick={() => setLightboxImage(null)}
              className="absolute -top-10 right-0 text-white/80 hover:text-white p-1"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={lightboxImage}
              alt="Enlarged doubt"
              className="max-h-[85vh] max-w-full rounded-2xl object-contain shadow-2xl border border-white/10"
            />
          </div>
        </div>
      )}
    </div>
  );
};
