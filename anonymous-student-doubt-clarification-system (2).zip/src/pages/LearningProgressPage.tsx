import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Brain,
  Sparkles,
  Award,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  Calendar,
  ArrowRight,
  Flame,
  BarChart3,
  Lightbulb,
} from 'lucide-react';
import { QuizResult, Question, StudyTask, LearningAnalysis } from '../types';
import { subscribeToUserQuizResults, computeTopicBreakdown } from '../services/quizService';
import { subscribeToStudyTasks, calculateRealStreak } from '../services/studyService';
import { getQuestionsByAuthor } from '../services/questionService';
import { generateAILearningAnalysis } from '../services/aiService';
import { useAuth } from '../context/AuthContext';

interface LearningProgressPageProps {
  onNavigateToQuiz?: () => void;
  onNavigateToTutor?: () => void;
}

export const LearningProgressPage: React.FC<LearningProgressPageProps> = ({
  onNavigateToQuiz,
  onNavigateToTutor,
}) => {
  const { currentUser } = useAuth();
  const [quizzes, setQuizzes] = useState<QuizResult[]>([]);
  const [tasks, setTasks] = useState<StudyTask[]>([]);
  const [doubts, setDoubts] = useState<Question[]>([]);
  const [analysis, setAnalysis] = useState<LearningAnalysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  useEffect(() => {
    const userId = currentUser?.uid || 'guest_student';

    const unsubQuizzes = subscribeToUserQuizResults(userId, res => setQuizzes(res));
    const unsubTasks = subscribeToStudyTasks(userId, tList => setTasks(tList));

    getQuestionsByAuthor(userId).then(qs => setDoubts(qs));

    return () => {
      unsubQuizzes();
      unsubTasks();
    };
  }, [currentUser?.uid]);

  const topicBreakdown = computeTopicBreakdown(quizzes);
  const weakTopics = topicBreakdown.filter(t => t.status === 'weak');
  const strongTopics = topicBreakdown.filter(t => t.status === 'strong');

  const quizDates = quizzes.map(q => q.createdAt);
  const doubtDates = doubts.map(d => d.createdAt);
  const streakStats = calculateRealStreak(tasks, quizDates, doubtDates);

  const averageQuizScore = quizzes.length > 0
    ? Math.round(quizzes.reduce((acc, q) => acc + q.scorePercentage, 0) / quizzes.length)
    : 0;

  const handleRunAIAnalysis = async () => {
    setAnalyzing(true);
    setAnalysisError(null);

    try {
      const result = await generateAILearningAnalysis({
        quizzesTaken: quizzes.length,
        averageScore: averageQuizScore,
        quizHistory: quizzes.map(q => ({
          subject: q.subject,
          topic: q.topic,
          score: q.scorePercentage,
        })),
        doubtsAsked: doubts.map(d => ({
          title: d.title,
          subject: d.subjectName || d.subjectId,
        })),
        completedTasks: tasks.filter(t => t.completed).map(t => ({
          title: t.title,
          subject: t.subject,
        })),
        streakDays: streakStats.currentStreak,
      });

      setAnalysis({
        overview: result.overview || 'Consistent study momentum detected across recent sessions.',
        strengthAreas: result.strengthAreas || ['Fundamental Concepts'],
        improvementAreas: result.improvementAreas || ['Advanced Edge Cases'],
        recommendedTopic: result.recommendedTopic || 'Review previous quiz topics',
        actionPlan: result.actionPlan || 'Dedicate 45 minutes of targeted revision today.',
        updatedAt: new Date().toISOString(),
      });
    } catch (err: any) {
      setAnalysisError(err?.message || 'Could not generate learning analysis.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="relative z-10 max-w-xl space-y-2">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs px-3 py-1 rounded-full">
            <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
            <span>Real-Time Academic Performance Analytics</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            AI Learning & Weak Topic Analysis
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Diagnose strengths, discover knowledge gaps, and receive tailored next-step study suggestions driven by your actual learning data.
          </p>
        </div>

        <button
          type="button"
          onClick={handleRunAIAnalysis}
          disabled={analyzing}
          className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer shrink-0"
        >
          <Sparkles className={`w-4 h-4 ${analyzing ? 'animate-spin' : ''}`} />
          <span>{analyzing ? 'Analyzing Data...' : 'Run AI Learning Diagnosis'}</span>
        </button>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Average Quiz Score
          </span>
          <span className="text-2xl font-black text-indigo-600 mt-1 block">
            {quizzes.length > 0 ? `${averageQuizScore}%` : '—'}
          </span>
          <span className="text-[10px] text-slate-400">{quizzes.length} quizzes taken</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Study Streak
          </span>
          <div className="flex items-center gap-1.5 mt-1">
            <Flame className="w-5 h-5 text-amber-500 fill-amber-500" />
            <span className="text-2xl font-black text-slate-900">
              {streakStats.currentStreak} Days
            </span>
          </div>
          <span className="text-[10px] text-slate-400">{streakStats.activeDaysCount} active days</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Weak Topics Flagged
          </span>
          <span className="text-2xl font-black text-rose-600 mt-1 block">
            {weakTopics.length}
          </span>
          <span className="text-[10px] text-slate-400">&lt;60% accuracy</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Strong Concepts
          </span>
          <span className="text-2xl font-black text-emerald-600 mt-1 block">
            {strongTopics.length}
          </span>
          <span className="text-[10px] text-slate-400">≥80% accuracy</span>
        </div>
      </div>

      {/* AI Grounded Insights Card */}
      {analysis && (
        <div className="bg-linear-to-b from-indigo-50/50 via-white to-white rounded-2xl p-6 sm:p-8 border border-indigo-100 shadow-2xs space-y-6">
          <div className="flex items-center gap-2 border-b border-indigo-100 pb-3">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            <h2 className="text-sm font-bold text-indigo-950">AI Pedagogical Diagnosis</h2>
          </div>

          <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
            {analysis.overview}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Strengths */}
            <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-200 text-xs space-y-2">
              <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Verified Strengths
              </span>
              <ul className="space-y-1 text-emerald-800">
                {analysis.strengthAreas.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span>•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Improvement Areas */}
            <div className="p-4 bg-rose-50/60 rounded-xl border border-rose-200 text-xs space-y-2">
              <span className="font-bold text-rose-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                Focus Required
              </span>
              <ul className="space-y-1 text-rose-800">
                {analysis.improvementAreas.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span>•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Recommended Next Topic */}
            <div className="p-4 bg-indigo-50/60 rounded-xl border border-indigo-200 text-xs space-y-2 flex flex-col justify-between">
              <div>
                <span className="font-bold text-indigo-950 flex items-center gap-1.5 mb-1">
                  <Lightbulb className="w-4 h-4 text-amber-500" />
                  Recommended Next Step
                </span>
                <span className="font-extrabold text-indigo-700 block text-sm">
                  {analysis.recommendedTopic}
                </span>
                <p className="text-slate-600 mt-1">{analysis.actionPlan}</p>
              </div>

              {onNavigateToQuiz && (
                <button
                  type="button"
                  onClick={onNavigateToQuiz}
                  className="mt-3 inline-flex items-center gap-1 text-indigo-700 font-bold hover:underline"
                >
                  <span>Practice this topic in Quiz</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Weak & Strong Topics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Weak Topics */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500" />
              <span>Topics Needing Targeted Review ({weakTopics.length})</span>
            </h3>
            <span className="text-[11px] text-slate-400">Score &lt; 60%</span>
          </div>

          {weakTopics.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-500">
              No weak topics identified yet! Great conceptual grasp so far.
            </div>
          ) : (
            <div className="space-y-2">
              {weakTopics.map((t, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-rose-50/40 rounded-xl border border-rose-200 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-slate-900 block">{t.topic}</span>
                    <span className="text-[11px] text-slate-500">{t.subject}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md">
                      {t.averageScore}% avg
                    </span>
                    {onNavigateToTutor && (
                      <button
                        type="button"
                        onClick={onNavigateToTutor}
                        className="text-[11px] text-indigo-600 hover:underline font-semibold"
                      >
                        Ask Tutor
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Strong Topics */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Mastered Concepts ({strongTopics.length})</span>
            </h3>
            <span className="text-[11px] text-slate-400">Score ≥ 80%</span>
          </div>

          {strongTopics.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-500">
              Take more quizzes to demonstrate mastery in specific topics.
            </div>
          ) : (
            <div className="space-y-2">
              {strongTopics.map((t, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-emerald-50/40 rounded-xl border border-emerald-200 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-slate-900 block">{t.topic}</span>
                    <span className="text-[11px] text-slate-500">{t.subject}</span>
                  </div>

                  <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                    {t.averageScore}% avg
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
