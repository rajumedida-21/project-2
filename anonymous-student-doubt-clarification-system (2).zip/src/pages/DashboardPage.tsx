import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Flame,
  Clock,
  Target,
  Brain,
  HelpCircle,
  MessageSquare,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  BookOpen,
  ArrowRight,
  TrendingUp,
  Award,
  Layers,
  ListTodo,
  Compass,
  FileText,
  Timer,
  RotateCw,
} from 'lucide-react';
import { Question, Answer, QuizResult, StudyPlan, StudyTask, UserAchievement } from '../types';
import { useAuth } from '../context/AuthContext';
import { getQuestionsByUser } from '../services/questionService';
import { getAnswersByUser } from '../services/answerService';
import { subscribeToUserQuizResults, computeTopicBreakdown } from '../services/quizService';
import { subscribeToStudyTasks, subscribeToUserStudyPlans, calculateRealStreak } from '../services/studyService';
import { subscribeToAchievements } from '../services/achievementService';
import { getFlashcardStats } from '../services/revisionService';
import { formatRelativeTime } from '../utils/dateUtils';
import { DailyLearningFeed } from '../components/DailyLearningFeed';
import { AdaptiveRecommendations } from '../components/AdaptiveRecommendations';
import { AIGoalsManager } from '../components/AIGoalsManager';
import { AILearningReportModal } from '../components/AILearningReportModal';
import { StudyFocusModal } from '../components/StudyFocusModal';

interface DashboardPageProps {
  onNavigateToAdvisor: () => void;
  onNavigateToQuiz: () => void;
  onNavigateToPlanner: () => void;
  onNavigateToTutor: (initialPrompt?: string) => void;
  onNavigateToProgress: () => void;
  onNavigateToRevision?: () => void;
  onNavigateToLeaderboard?: () => void;
  onOpenQuestion: (questionId: string) => void;
  onOpenAskModal: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onNavigateToAdvisor,
  onNavigateToQuiz,
  onNavigateToPlanner,
  onNavigateToTutor,
  onNavigateToProgress,
  onNavigateToRevision,
  onNavigateToLeaderboard,
  onOpenQuestion,
  onOpenAskModal,
}) => {
  const { currentUser, openAuthModal } = useAuth();

  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [quizzes, setQuizzes] = useState<QuizResult[]>([]);
  const [tasks, setTasks] = useState<StudyTask[]>([]);
  const [plans, setPlans] = useState<StudyPlan[]>([]);
  const [achievements, setAchievements] = useState<UserAchievement[]>([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isFocusModalOpen, setIsFocusModalOpen] = useState(false);
  const [focusTopic, setFocusTopic] = useState('Core Concept Mastery');
  const [focusSubject, setFocusSubject] = useState('Computer Science');
  const [focusMinutes, setFocusMinutes] = useState(25);

  const flashcardStats = getFlashcardStats();

  useEffect(() => {
    if (!currentUser?.uid) {
      setLoading(false);
      return;
    }

    const userId = currentUser.uid;
    setLoading(true);

    Promise.all([
      getQuestionsByUser(userId),
      getAnswersByUser(userId),
    ]).then(([qList, aList]) => {
      setQuestions(qList);
      setAnswers(aList);
      setLoading(false);
    });

    const unsubQuizzes = subscribeToUserQuizResults(userId, res => setQuizzes(res));
    const unsubTasks = subscribeToStudyTasks(userId, tList => setTasks(tList));
    const unsubPlans = subscribeToUserStudyPlans(userId, pList => setPlans(pList));
    const unsubAch = subscribeToAchievements(userId, achList => setAchievements(achList));

    return () => {
      unsubQuizzes();
      unsubTasks();
      unsubPlans();
      unsubAch();
    };
  }, [currentUser?.uid]);

  const quizDates = quizzes.map(q => q.createdAt);
  const doubtDates = questions.map(d => d.createdAt);
  const streakStats = calculateRealStreak(tasks, quizDates, doubtDates);

  const completedTasks = tasks.filter(t => t.completed);
  const totalMinutesStudied = completedTasks.reduce((acc, t) => acc + (t.durationMinutes || 0), 0);
  const hoursStudied = (totalMinutesStudied / 60).toFixed(1);

  const avgQuizScore = quizzes.length > 0
    ? Math.round(quizzes.reduce((acc, q) => acc + q.scorePercentage, 0) / quizzes.length)
    : 0;

  const topicBreakdown = computeTopicBreakdown(quizzes);
  const weakTopics = topicBreakdown.filter(t => t.status === 'weak');
  const strongTopics = topicBreakdown.filter(t => t.status === 'strong');

  const activePlan = plans[0] || null;

  const recentActivities = [
    ...questions.map(q => ({
      id: q.questionId,
      type: 'doubt',
      title: `Asked Doubt: "${q.title}"`,
      sub: q.subjectName,
      date: q.createdAt,
    })),
    ...quizzes.map(q => ({
      id: q.resultId,
      type: 'quiz',
      title: `Completed Quiz: ${q.topic} (${q.scorePercentage}%)`,
      sub: q.subject,
      date: q.createdAt,
    })),
    ...completedTasks.map(t => ({
      id: t.taskId,
      type: 'task',
      title: `Finished Task: ${t.title}`,
      sub: t.subject,
      date: t.date,
    })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 6);

  const handleStartFocusSprint = (topic: string, subject: string, minutes: number) => {
    setFocusTopic(topic);
    setFocusSubject(subject);
    setFocusMinutes(minutes);
    setIsFocusModalOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Tier 3: Personalized Daily Learning Feed */}
      <DailyLearningFeed
        onStartFocusSession={handleStartFocusSprint}
        onNavigateToFlashcards={onNavigateToRevision}
        onNavigateToQuiz={onNavigateToQuiz}
        onNavigateToTutor={() => onNavigateToTutor()}
      />

      {/* Command Center Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center font-bold">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900">Academic Tools & AI Reports</h2>
            <p className="text-xs text-slate-500">
              Run focused Pomodoro study sessions, generate full analytical reports, or review memory cards.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={() => setIsReportModalOpen(true)}
            className="px-3.5 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl text-xs font-bold border border-purple-200 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileText className="w-4 h-4 text-purple-600" />
            <span>AI Learning Report</span>
          </button>

          <button
            type="button"
            onClick={() => handleStartFocusSprint('Core Subject Deep Focus', 'Computer Science', 25)}
            className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold border border-indigo-200 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Timer className="w-4 h-4 text-indigo-600" />
            <span>Study Sprint</span>
          </button>

          {onNavigateToRevision && (
            <button
              type="button"
              onClick={onNavigateToRevision}
              className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-bold border border-amber-200 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCw className="w-4 h-4 text-amber-600" />
              <span>Flashcards ({flashcardStats.dueCount} Due)</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenAskModal}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Ask a Doubt</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Streak */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Current Streak
          </span>
          <div className="flex items-center gap-1.5 mt-1">
            <Flame className="w-5 h-5 text-amber-500 fill-amber-500" />
            <span className="text-2xl font-black text-slate-900">{streakStats.currentStreak}d</span>
          </div>
        </div>

        {/* Study Time */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Completed Study
          </span>
          <div className="flex items-center gap-1.5 mt-1">
            <Clock className="w-5 h-5 text-indigo-600" />
            <span className="text-2xl font-black text-slate-900">{hoursStudied}h</span>
          </div>
        </div>

        {/* Quiz Avg */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Quiz Average
          </span>
          <div className="flex items-center gap-1.5 mt-1">
            <Brain className="w-5 h-5 text-purple-600" />
            <span className="text-2xl font-black text-slate-900">
              {quizzes.length > 0 ? `${avgQuizScore}%` : '—'}
            </span>
          </div>
        </div>

        {/* Spaced Flashcards */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Flashcards Mastered
          </span>
          <div className="flex items-center gap-1.5 mt-1">
            <RotateCw className="w-5 h-5 text-emerald-600" />
            <span className="text-2xl font-black text-slate-900">
              {flashcardStats.masteryPercentage}%
            </span>
          </div>
        </div>

        {/* Doubts Asked */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Doubts Asked
          </span>
          <div className="flex items-center gap-1.5 mt-1">
            <HelpCircle className="w-5 h-5 text-blue-600" />
            <span className="text-2xl font-black text-slate-900">{questions.length}</span>
          </div>
        </div>

        {/* Answers Given */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Answers Given
          </span>
          <div className="flex items-center gap-1.5 mt-1">
            <MessageSquare className="w-5 h-5 text-emerald-600" />
            <span className="text-2xl font-black text-slate-900">{answers.length}</span>
          </div>
        </div>
      </div>

      {/* Tier 3: Adaptive Recommendations */}
      <AdaptiveRecommendations
        onNavigateToFlashcards={onNavigateToRevision}
        onNavigateToTutor={prompt => onNavigateToTutor(prompt)}
        onStartFocusSession={handleStartFocusSprint}
        onNavigateToQuiz={onNavigateToQuiz}
      />

      {/* Tier 3: AI Goal Deconstruction & Mastery */}
      <AIGoalsManager
        onStartFocusSession={handleStartFocusSprint}
        onAskTutor={topic => onNavigateToTutor(`Help me master this milestone: ${topic}`)}
      />

      {/* Main Grid: Active Plan & Learning Diagnosis */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 cols: Active Study Plan & Fast Actions */}
        <div className="lg:col-span-7 space-y-6">
          {/* Active Study Plan Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center">
                  <Target className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-slate-900">Current Active Study Plan</h2>
                  <span className="text-[11px] text-slate-400">
                    {activePlan ? `Target Exam: ${activePlan.examDate}` : 'No active roadmap'}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={onNavigateToAdvisor}
                className="text-xs text-indigo-600 hover:underline font-semibold"
              >
                {activePlan ? 'Update Plan →' : 'Create Plan →'}
              </button>
            </div>

            {activePlan ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-700">
                    {activePlan.subjects.join(', ')}
                  </span>
                  <span className="text-slate-500">{activePlan.hoursPerDay} hrs/day</span>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <span>Tasks Completed</span>
                    <span>
                      {completedTasks.length} / {tasks.length || 1}
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-indigo-600 h-full transition-all duration-300"
                      style={{
                        width: `${tasks.length > 0 ? (completedTasks.length / tasks.length) * 100 : 25}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600 border border-slate-100 flex items-start gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                  <p className="line-clamp-2">
                    {activePlan.dailyGoal || activePlan.planContent.slice(0, 160) + '...'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 space-y-2">
                <p className="text-xs text-slate-500">
                  You haven&apos;t generated a study plan yet. Get day-by-day exam schedules from our AI Advisor.
                </p>
                <button
                  type="button"
                  onClick={onNavigateToAdvisor}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold shadow-xs"
                >
                  Generate First Study Plan
                </button>
              </div>
            )}
          </div>

          {/* Unified Recent Activity Feed */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900">Recent Academic Activity</h3>
              <span className="text-[11px] text-slate-400">Live synchronized log</span>
            </div>

            {recentActivities.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400">
                No recent activity recorded yet. Take a quiz or post a doubt to see your timeline.
              </div>
            ) : (
              <div className="space-y-2.5">
                {recentActivities.map(act => (
                  <div
                    key={act.id}
                    className="p-3 bg-slate-50/70 hover:bg-slate-100/60 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs transition-colors"
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <div className="w-6 h-6 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center shrink-0">
                        {act.type === 'doubt' ? (
                          <HelpCircle className="w-3.5 h-3.5" />
                        ) : act.type === 'quiz' ? (
                          <Brain className="w-3.5 h-3.5" />
                        ) : (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        )}
                      </div>
                      <span className="font-semibold text-slate-800 truncate">{act.title}</span>
                    </div>

                    <span className="text-[10px] text-slate-400 shrink-0 ml-2">
                      {formatRelativeTime(act.date)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right 5 cols: Weak Topics & Recommended Next Step */}
        <div className="lg:col-span-5 space-y-6">
          {/* Weak Topics Section */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <h3 className="text-sm font-bold text-slate-900">Weak Topics Identified</h3>
              </div>
              <button
                type="button"
                onClick={onNavigateToProgress}
                className="text-[11px] text-indigo-600 hover:underline font-semibold"
              >
                Full Analysis →
              </button>
            </div>

            {weakTopics.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-500 space-y-1">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <p className="font-semibold text-slate-700">No weak topics found!</p>
                <p className="text-[11px]">Keep testing yourself with AI quizzes to discover edge cases.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {weakTopics.slice(0, 4).map((topic, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-rose-50/50 border border-rose-200/80 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 block">{topic.topic}</span>
                      <span className="text-[10px] text-slate-500">{topic.subject}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md">
                        {topic.averageScore}%
                      </span>
                      <button
                        type="button"
                        onClick={onNavigateToQuiz}
                        className="text-[11px] text-indigo-600 hover:underline font-semibold"
                      >
                        Retest
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recommended Next Step Box */}
          <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-2xl p-6 shadow-md space-y-3">
            <div className="flex items-center gap-2 text-indigo-300 text-xs font-bold">
              <Sparkles className="w-4 h-4" />
              <span>AI Learning Recommendation</span>
            </div>

            <h4 className="text-base font-bold">
              {weakTopics.length > 0
                ? `Focus on: ${weakTopics[0].topic}`
                : activePlan?.topics
                ? `Next Up: ${activePlan.topics.split(',')[0]}`
                : 'Solve a Quick Quiz on Data Structures'}
            </h4>

            <p className="text-xs text-slate-300 leading-relaxed">
              {weakTopics.length > 0
                ? `Your quiz score on ${weakTopics[0].topic} was ${weakTopics[0].averageScore}%. Reviewing this today will strengthen your foundation.`
                : 'Consistent daily testing prevents forgetting and builds long-term recall.'}
            </p>

            <button
              type="button"
              onClick={() => {
                if (weakTopics.length > 0) {
                  onNavigateToTutor(`Can you help me master the concept of ${weakTopics[0].topic}?`);
                } else {
                  onNavigateToQuiz();
                }
              }}
              className="w-full py-2.5 bg-white hover:bg-slate-100 text-slate-900 rounded-xl font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
            >
              <span>{weakTopics.length > 0 ? 'Ask AI Tutor for Explanation' : 'Start Practice Quiz'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* AI Learning Report Modal */}
      <AILearningReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        quizHistory={quizzes}
        doubtsAsked={questions.map(q => q.title)}
      />

      {/* Deep Study Sprint Focus Modal */}
      <StudyFocusModal
        isOpen={isFocusModalOpen}
        onClose={() => setIsFocusModalOpen(false)}
        initialTopic={focusTopic}
        initialSubject={focusSubject}
        initialMinutes={focusMinutes}
      />
    </div>
  );
};
