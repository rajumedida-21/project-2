import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Flame,
  Award,
  Star,
  Shield,
  Zap,
  Users,
  CheckCircle2,
  HelpCircle,
  BookOpen,
  Brain,
  Lock,
} from 'lucide-react';
import {
  getGamificationData,
  getLeaderboard,
  getLevelTitle,
  getXPForNextLevel,
  ALL_BADGES,
} from '../services/gamificationService';
import { useSettings } from '../context/SettingsContext';
import { LeaderboardEntry } from '../types';

export const LeaderboardPage: React.FC = () => {
  const [gamification, setGamification] = useState(getGamificationData());
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const { settings, updatePrivacySettings } = useSettings();

  useEffect(() => {
    setGamification(getGamificationData());
    setLeaderboard(getLeaderboard());
  }, []);

  const level = gamification.level;
  const levelTitle = getLevelTitle(level);
  const currentXP = gamification.xp;
  const xpInfo = getXPForNextLevel(level);
  const xpNeeded = xpInfo.nextLevelXP - currentXP;
  const levelProgress = Math.min(
    100,
    Math.max(
      0,
      Math.round(
        ((currentXP - xpInfo.currentLevelXP) / (xpInfo.nextLevelXP - xpInfo.currentLevelXP)) * 100
      )
    )
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center shadow-xs">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Academic Gamification & Leaderboard</h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Celebrate your learning consistency, earn XP through active study, and unlock scholar badges.
            </p>
          </div>
        </div>

        {/* Privacy toggle */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-xl text-xs">
          <Shield className="w-4 h-4 text-indigo-600" />
          <span className="font-semibold text-slate-700">Show on Leaderboard:</span>
          <button
            type="button"
            onClick={() =>
              updatePrivacySettings({ showOnLeaderboard: !settings.privacy.showOnLeaderboard })
            }
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
              settings.privacy.showOnLeaderboard
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-200 text-slate-600'
            }`}
          >
            {settings.privacy.showOnLeaderboard ? 'Visible (Anonymous)' : 'Hidden'}
          </button>
        </div>
      </div>

      {/* Student Level & Stats Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Level card */}
        <div className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-md md:col-span-2 flex flex-col justify-between space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider">
                Scholar Standing
              </span>
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                Level {level} • {levelTitle}
              </h2>
            </div>
            <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex flex-col items-center justify-center shadow-inner">
              <span className="text-xs text-indigo-300 font-bold">LVL</span>
              <span className="text-xl font-extrabold text-white">{level}</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-indigo-200">
              <span className="font-semibold">{currentXP} Total XP</span>
              <span>{Math.max(0, xpNeeded)} XP to Level {level + 1}</span>
            </div>
            <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden p-0.5 border border-white/15">
              <div
                className="bg-gradient-to-r from-amber-400 to-indigo-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${levelProgress}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10 text-center">
            <div>
              <span className="text-[10px] text-indigo-300 block">Streak</span>
              <span className="text-base font-bold text-amber-400 flex items-center justify-center gap-1">
                <Flame className="w-4 h-4 fill-current" /> {gamification.streak} Days
              </span>
            </div>
            <div>
              <span className="text-[10px] text-indigo-300 block">Doubts & Answers</span>
              <span className="text-base font-bold text-white">
                {gamification.doubtsAskedCount + gamification.answersGivenCount}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-indigo-300 block">Quizzes Done</span>
              <span className="text-base font-bold text-white">
                {gamification.quizzesCompletedCount}
              </span>
            </div>
          </div>
        </div>

        {/* How to earn XP box */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs space-y-3 flex flex-col justify-between">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-500 fill-current" />
              Ways to Earn Scholar XP
            </h3>
            <p className="text-[11px] text-slate-500">
              Engage actively in the academic community:
            </p>
          </div>

          <div className="space-y-2 text-xs text-slate-700">
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100">
              <span>Ask Academic Doubt</span>
              <span className="font-bold text-indigo-600">+15 XP</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100">
              <span>Provide Peer Answer</span>
              <span className="font-bold text-indigo-600">+25 XP</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100">
              <span>Answer Marked Helpful</span>
              <span className="font-bold text-emerald-600">+50 XP</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100">
              <span>Complete Concept Quiz</span>
              <span className="font-bold text-purple-600">+30 XP</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100">
              <span>Spaced Recall Flashcard</span>
              <span className="font-bold text-amber-600">+5 XP</span>
            </div>
          </div>
        </div>
      </div>

      {/* Badges Collection Grid */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Academic Achievements & Badges</h3>
              <p className="text-xs text-slate-500">
                Unlocked {gamification.badges.length} of {ALL_BADGES.length} milestone badges.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {ALL_BADGES.map(badge => {
            const isUnlocked = gamification.badges.includes(badge.id);
            return (
              <div
                key={badge.id}
                className={`p-4 rounded-2xl border transition-all flex items-start gap-3.5 ${
                  isUnlocked
                    ? 'bg-gradient-to-br from-amber-50/40 via-white to-indigo-50/30 border-amber-200/80 shadow-2xs'
                    : 'bg-slate-50/70 border-slate-200 opacity-60'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 shadow-2xs ${
                    isUnlocked ? 'bg-white border border-amber-200' : 'bg-slate-200 text-slate-400'
                  }`}
                >
                  {isUnlocked ? badge.icon : <Lock className="w-5 h-5 text-slate-400" />}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold text-slate-900">{badge.name}</h4>
                    {isUnlocked && (
                      <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-md">
                        Unlocked
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-snug">{badge.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Community Leaderboard Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Responsible Peer Scholar Leaderboard</h3>
              <p className="text-xs text-slate-500">
                Encouraging peer-to-peer inquiry and conceptual clarity. All names are anonymized by default.
              </p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-y border-slate-200">
              <tr>
                <th className="py-3 px-4">Rank</th>
                <th className="py-3 px-4">Scholar</th>
                <th className="py-3 px-4">Level</th>
                <th className="py-3 px-4">Total XP</th>
                <th className="py-3 px-4">Streak</th>
                <th className="py-3 px-4">Helpful Answers</th>
                <th className="py-3 px-4">Quizzes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {leaderboard.map(entry => {
                const isUser = entry.userId === 'local_student';
                return (
                  <tr
                    key={entry.userId}
                    className={`transition-colors ${
                      isUser
                        ? 'bg-indigo-50/70 font-bold text-indigo-950 border-l-4 border-l-indigo-600'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    <td className="py-3.5 px-4 font-bold">
                      {entry.rank === 1 ? (
                        <span className="text-base">🥇 #1</span>
                      ) : entry.rank === 2 ? (
                        <span className="text-base">🥈 #2</span>
                      ) : entry.rank === 3 ? (
                        <span className="text-base">🥉 #3</span>
                      ) : (
                        `#${entry.rank}`
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                          {entry.displayName.slice(0, 1)}
                        </div>
                        <div>
                          <span>{entry.displayName}</span>
                          {isUser && (
                            <span className="text-[10px] text-indigo-600 bg-white px-1.5 py-0.2 rounded-md ml-1.5 border border-indigo-200">
                              You
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded-md text-[11px] font-semibold">
                        Lvl {entry.level}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-indigo-700">
                      {entry.xp} XP
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="text-amber-600 flex items-center gap-1 font-semibold">
                        <Flame className="w-3.5 h-3.5 fill-current" /> {entry.streak}d
                      </span>
                    </td>
                    <td className="py-3.5 px-4">{entry.helpfulAnswers}</td>
                    <td className="py-3.5 px-4">{entry.quizzesCompleted}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
