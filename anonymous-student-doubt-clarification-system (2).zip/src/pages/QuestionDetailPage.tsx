import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  User,
  Shield,
  ThumbsUp,
  MessageSquare,
  CheckCircle2,
  Flag,
  Trash2,
  Send,
  Image as ImageIcon,
  Share2,
  Clock,
  Eye,
  Award,
  AlertCircle,
  Maximize2,
  X,
} from 'lucide-react';
import { Question, Answer } from '../types';
import {
  getQuestionById,
  getQuestions,
  incrementQuestionViews,
  deleteQuestion,
  subscribeToQuestion,
} from '../services/questionService';
import {
  getAnswersForQuestion,
  createAnswer,
  acceptAnswer,
  deleteAnswer,
  subscribeToAnswers,
} from '../services/answerService';
import { toggleQuestionVote, toggleAnswerVote, getUserVotedAnswerIds, getUserVotedQuestionIds } from '../services/voteService';
import { useAuth } from '../context/AuthContext';
import { formatRelativeTime } from '../utils/dateUtils';
import { MentorBadge } from '../components/MentorBadge';
import { processImageUpload } from '../utils/storageHelper';
import { AIDoubtCardAnswer } from '../components/AIDoubtCardAnswer';
import { SimilarDoubtsWidget } from '../components/SimilarDoubtsWidget';

interface QuestionDetailPageProps {
  questionId: string;
  onBack: () => void;
  onOpenReport: (contentType: 'question' | 'answer', contentId: string, snippet?: string) => void;
}

export const QuestionDetailPage: React.FC<QuestionDetailPageProps> = ({
  questionId,
  onBack,
  onOpenReport,
}) => {
  const { currentUser, openAuthModal } = useAuth();
  const [question, setQuestion] = useState<Question | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [loading, setLoading] = useState(true);
  const [answerText, setAnswerText] = useState('');
  const [answerImageFile, setAnswerImageFile] = useState<File | null>(null);
  const [answerImagePreview, setAnswerImagePreview] = useState<string | null>(null);
  const [submittingAnswer, setSubmittingAnswer] = useState(false);
  const [answerError, setAnswerError] = useState<string | null>(null);

  // Voting state
  const [questionUpvotes, setQuestionUpvotes] = useState(0);
  const [hasVotedQuestion, setHasVotedQuestion] = useState(false);
  const [votedAnswerIds, setVotedAnswerIds] = useState<Set<string>>(new Set());

  // Image lightbox
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [allQuestions, setAllQuestions] = useState<Question[]>([]);

  useEffect(() => {
    getQuestions().then(res => {
      if (Array.isArray(res)) setAllQuestions(res);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    incrementQuestionViews(questionId).catch(() => {});

    const unsubQuestion = subscribeToQuestion(
      questionId,
      qData => {
        if (isMounted) {
          setQuestion(qData);
          if (qData) {
            setQuestionUpvotes(qData.upvotes || 0);
          }
          setLoading(false);
        }
      },
      () => {
        if (isMounted) setLoading(false);
      }
    );

    const unsubAnswers = subscribeToAnswers(
      questionId,
      aList => {
        if (isMounted) {
          setAnswers(aList);
        }
      }
    );

    if (currentUser?.uid) {
      Promise.all([
        getUserVotedQuestionIds(currentUser.uid),
        getUserVotedAnswerIds(currentUser.uid),
      ])
        .then(([qVotes, aVotes]) => {
          if (isMounted) {
            setHasVotedQuestion(qVotes.has(questionId));
            setVotedAnswerIds(aVotes);
          }
        })
        .catch(() => {});
    }

    return () => {
      isMounted = false;
      unsubQuestion();
      unsubAnswers();
    };
  }, [questionId, currentUser?.uid]);

  const handleVoteQuestion = async () => {
    if (!currentUser) {
      openAuthModal('login');
      return;
    }
    if (!question) return;

    const nextState = !hasVotedQuestion;
    setHasVotedQuestion(nextState);
    setQuestionUpvotes(prev => prev + (nextState ? 1 : -1));

    try {
      const res = await toggleQuestionVote(
        question.questionId,
        currentUser.uid,
        question.authorId,
        question.title
      );
      setHasVotedQuestion(res.hasVoted);
    } catch {
      setHasVotedQuestion(!nextState);
      setQuestionUpvotes(prev => prev + (nextState ? -1 : 1));
    }
  };

  const handleVoteAnswer = async (ans: Answer) => {
    if (!currentUser) {
      openAuthModal('login');
      return;
    }
    const currentlyVoted = votedAnswerIds.has(ans.answerId);

    // Optimistic
    setVotedAnswerIds(prev => {
      const copy = new Set(prev);
      if (currentlyVoted) copy.delete(ans.answerId);
      else copy.add(ans.answerId);
      return copy;
    });
    setAnswers(prev =>
      prev.map(a =>
        a.answerId === ans.answerId
          ? { ...a, upvotes: (a.upvotes || 0) + (currentlyVoted ? -1 : 1) }
          : a
      )
    );

    try {
      const res = await toggleAnswerVote(
        ans.answerId,
        questionId,
        currentUser.uid,
        ans.authorId
      );
      setVotedAnswerIds(prev => {
        const copy = new Set(prev);
        if (res.hasVoted) copy.add(ans.answerId);
        else copy.delete(ans.answerId);
        return copy;
      });
    } catch (err) {
      console.error('Answer vote failed:', err);
    }
  };

  const handleAcceptAnswer = async (answerId: string) => {
    if (!currentUser || !question) return;
    if (question.authorId !== currentUser.uid && currentUser.role !== 'admin') {
      alert('Only the question author can accept an answer as verified.');
      return;
    }

    try {
      await acceptAnswer(questionId, answerId, currentUser.uid);
      setQuestion(prev => (prev ? { ...prev, acceptedAnswerId: answerId, status: 'resolved' } : null));
      setAnswers(prev =>
        prev.map(a => ({
          ...a,
          isAccepted: a.answerId === answerId,
        }))
      );
    } catch (err) {
      console.error('Accept answer failed:', err);
    }
  };

  const handleDeleteQuestion = async () => {
    if (!question) return;
    if (!confirm('Are you sure you want to delete this doubt? This cannot be undone.')) return;

    try {
      await deleteQuestion(question.questionId);
      onBack();
    } catch (err) {
      alert('Failed to delete question.');
    }
  };

  const handleDeleteAnswer = async (ansId: string) => {
    if (!confirm('Are you sure you want to delete your answer?')) return;
    try {
      await deleteAnswer(ansId, questionId);
      setAnswers(prev => prev.filter(a => a.answerId !== ansId));
      setQuestion(prev => (prev ? { ...prev, answerCount: Math.max(0, (prev.answerCount || 1) - 1) } : null));
    } catch (err) {
      alert('Failed to delete answer.');
    }
  };

  const handleAnswerImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAnswerImageFile(file);
      setAnswerImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSubmitAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      openAuthModal('login');
      return;
    }
    if (answerText.trim().length < 5) {
      setAnswerError('Please write a helpful explanation (at least 5 characters).');
      return;
    }

    setSubmittingAnswer(true);
    setAnswerError(null);

    try {
      let finalImg = '';
      if (answerImageFile) {
        finalImg = await processImageUpload(answerImageFile);
      }

      const isMentor = Boolean(currentUser.isVerifiedMentor || currentUser.role === 'mentor');

      const newAns = await createAnswer({
        questionId,
        content: answerText.trim(),
        imageUrl: finalImg,
        authorId: currentUser.uid,
        isAnonymous: !isMentor, // Mentors can proudly display their verified badge! Students are protected anonymously.
        isMentor,
        mentorSpecialization: currentUser.subjectSpecialization,
        mentorName: isMentor ? currentUser.name : undefined,
        questionAuthorId: question?.authorId,
        questionTitle: question?.title,
      });

      setAnswers(prev => [...prev, newAns]);
      setQuestion(prev => (prev ? { ...prev, answerCount: (prev.answerCount || 0) + 1 } : null));
      setAnswerText('');
      setAnswerImageFile(null);
      if (answerImagePreview) URL.revokeObjectURL(answerImagePreview);
      setAnswerImagePreview(null);
    } catch (err: unknown) {
      setAnswerError(err instanceof Error ? err.message : 'Could not submit answer. Please try again.');
    } finally {
      setSubmittingAnswer(false);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-10 space-y-6">
        <div className="h-8 bg-slate-200 rounded-lg w-1/4 animate-pulse" />
        <div className="h-44 bg-white rounded-2xl border border-slate-200 animate-pulse" />
      </div>
    );
  }

  if (!question) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto" />
        <h2 className="text-xl font-bold text-slate-800">Doubt Not Found</h2>
        <p className="text-xs text-slate-500">This question may have been deleted or moved by moderators.</p>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold cursor-pointer"
        >
          Back to All Doubts
        </button>
      </div>
    );
  }

  const isAuthor = currentUser?.uid === question.authorId;
  const isAdmin = currentUser?.role === 'admin';
  const isResolved = Boolean(question.acceptedAnswerId || question.status === 'resolved');

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Back button & Breadcrumb */}
      <div className="flex items-center justify-between">
        <button
          id="back-to-doubts-btn"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Doubts</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-medium text-slate-600 transition-colors cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{copiedLink ? 'Link Copied!' : 'Share'}</span>
          </button>

          {(isAuthor || isAdmin) && (
            <button
              id="delete-question-top-btn"
              onClick={handleDeleteQuestion}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-xs font-medium text-rose-700 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Doubt</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Question Card */}
      <article
        id={`question-detail-${question.questionId}`}
        className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-2xs space-y-5"
      >
        {/* Header meta */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 shadow-2xs">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-slate-900">
                  {question.isAnonymous ? 'Anonymous Student' : 'Anonymous Student'}
                </span>
                <span title="Anonymous Student Identity Protected" className="text-indigo-600">
                  <Shield className="w-3.5 h-3.5" />
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {formatRelativeTime(question.createdAt)}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" />
                  {question.views || 0} views
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isResolved && (
              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold px-2.5 py-1 rounded-full">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Solved</span>
              </span>
            )}
            <span className="text-xs font-semibold bg-indigo-50 text-indigo-700 px-3 py-1 rounded-lg border border-indigo-200/60">
              {question.subjectName || question.subjectId}
            </span>
          </div>
        </div>

        {/* Question Title */}
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
          {question.title}
        </h1>

        {/* Question Description */}
        <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap font-sans">
          {question.description}
        </div>

        {/* Attached Image if any */}
        {question.imageUrl && (
          <div className="pt-2">
            <span className="text-xs font-semibold text-slate-500 mb-2 block">Attached Diagram / Screenshot:</span>
            <div
              className="relative inline-block border border-slate-200 rounded-xl overflow-hidden cursor-pointer group bg-slate-900"
              onClick={() => setLightboxImage(question.imageUrl || null)}
            >
              <img
                src={question.imageUrl}
                alt="Question Diagram"
                className="max-h-96 max-w-full rounded-xl object-contain hover:opacity-90 transition-opacity"
              />
              <div className="absolute bottom-2 right-2 p-1.5 bg-black/60 text-white rounded-md flex items-center gap-1 text-[10px]">
                <Maximize2 className="w-3 h-3" />
                <span>Click to zoom</span>
              </div>
            </div>
          </div>
        )}

        {/* Card Footer actions: Upvote & Report */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              id="detail-upvote-question-btn"
              onClick={handleVoteQuestion}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                hasVotedQuestion
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ThumbsUp className={`w-3.5 h-3.5 ${hasVotedQuestion ? 'fill-white' : ''}`} />
              <span>Helpful ({questionUpvotes})</span>
            </button>

            <span className="text-xs text-slate-500 flex items-center gap-1">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>{answers.length} Answers</span>
            </span>
          </div>

          <button
            id="report-doubt-btn"
            onClick={() => onOpenReport('question', question.questionId, question.title)}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-rose-600 transition-colors p-1"
            title="Report inappropriate content"
          >
            <Flag className="w-3.5 h-3.5" />
            <span>Report</span>
          </button>
        </div>
      </article>

      {/* AI Assistant Answer Card */}
      <AIDoubtCardAnswer
        questionId={question.questionId}
        questionTitle={question.title}
        questionDescription={question.description}
        subjectName={question.subjectName}
        existingAIExplanation={question.aiExplanation}
        imageUrl={question.imageUrl}
      />

      {/* Concept Similarity & Similar Doubts Asked by Others */}
      <SimilarDoubtsWidget
        currentQuestionId={question.questionId}
        title={question.title}
        description={question.description}
        subjectId={question.subjectId}
        allQuestions={allQuestions}
        onOpenQuestion={(qId) => {
          window.location.hash = `question/${qId}`;
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Answers Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-indigo-600" />
            <span>{answers.length} {answers.length === 1 ? 'Answer' : 'Answers'}</span>
          </h2>
          <span className="text-xs text-slate-400">
            Sorted by Accepted & Verified Mentors
          </span>
        </div>

        {/* Answers List */}
        {answers.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center space-y-2">
            <MessageSquare className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="text-sm font-bold text-slate-700">No answers yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Know the answer or have a helpful explanation? Help your fellow college student by posting below!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {answers.map(ans => {
              const isAccepted = ans.isAccepted || question.acceptedAnswerId === ans.answerId;
              const isAnswerAuthor = currentUser?.uid === ans.authorId;
              const hasVotedThisAns = votedAnswerIds.has(ans.answerId);

              return (
                <article
                  key={ans.answerId}
                  id={`answer-item-${ans.answerId}`}
                  className={`bg-white rounded-2xl p-6 border transition-all space-y-4 ${
                    isAccepted
                      ? 'border-emerald-400/90 ring-2 ring-emerald-100 bg-emerald-50/10'
                      : 'border-slate-200/90 hover:border-slate-300'
                  }`}
                >
                  {/* Answer Header */}
                  <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs ${
                          ans.isMentor
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {ans.isMentor ? (
                          <Award className="w-4 h-4 text-emerald-700" />
                        ) : (
                          <User className="w-4 h-4 text-slate-500" />
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            {ans.isMentor
                              ? ans.mentorName || 'Verified Mentor'
                              : 'Anonymous Student'}
                          </span>
                          {ans.isMentor ? (
                            <MentorBadge
                              specialization={ans.mentorSpecialization}
                              size="sm"
                              showSpecialization={false}
                            />
                          ) : (
                            <span title="Anonymous Identity Protected" className="text-indigo-600">
                              <Shield className="w-3 h-3" />
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400 block">
                          Answered {formatRelativeTime(ans.createdAt)}
                        </span>
                      </div>
                    </div>

                    {/* Accepted Badge */}
                    {isAccepted && (
                      <span
                        id="accepted-answer-badge"
                        className="inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-800 border border-emerald-300/80 px-3 py-1 rounded-full text-xs font-bold shadow-2xs"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Accepted Answer</span>
                      </span>
                    )}
                  </div>

                  {/* Answer Content */}
                  <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap font-sans">
                    {ans.answerText}
                  </div>

                  {/* Answer Image if any */}
                  {ans.imageUrl && (
                    <div className="pt-2">
                      <div
                        className="relative inline-block border border-slate-200 rounded-xl overflow-hidden cursor-pointer group bg-slate-900"
                        onClick={() => setLightboxImage(ans.imageUrl || null)}
                      >
                        <img
                          src={ans.imageUrl}
                          alt="Answer diagram"
                          className="max-h-72 max-w-full rounded-xl object-contain hover:opacity-90 transition-opacity"
                        />
                      </div>
                    </div>
                  )}

                  {/* Answer Actions */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <button
                        type="button"
                        id={`upvote-answer-btn-${ans.answerId}`}
                        onClick={() => handleVoteAnswer(ans)}
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-lg font-semibold transition-colors cursor-pointer ${
                          hasVotedThisAns
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        <ThumbsUp className={`w-3 h-3 ${hasVotedThisAns ? 'fill-white' : ''}`} />
                        <span>{ans.upvotes || 0}</span>
                      </button>

                      {/* Accept Answer Button (Author or Admin only) */}
                      {(isAuthor || isAdmin) && !isAccepted && (
                        <button
                          type="button"
                          id={`accept-answer-btn-${ans.answerId}`}
                          onClick={() => handleAcceptAnswer(ans.answerId)}
                          className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg font-semibold transition-colors cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Accept as Solution</span>
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {(isAnswerAuthor || isAdmin) && (
                        <button
                          type="button"
                          id={`delete-answer-btn-${ans.answerId}`}
                          onClick={() => handleDeleteAnswer(ans.answerId)}
                          className="text-slate-400 hover:text-rose-600 p-1"
                          title="Delete your answer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onOpenReport('answer', ans.answerId, ans.answerText)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                        title="Report this answer"
                      >
                        <Flag className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Post an Answer Form */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-2xs space-y-4 mt-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">Your Answer</h3>
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              {currentUser?.isVerifiedMentor || currentUser?.role === 'mentor' ? (
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <Award className="w-3.5 h-3.5" /> Posting as Verified Mentor
                </span>
              ) : (
                <span className="text-indigo-700 font-medium flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5" /> Posting anonymously
                </span>
              )}
            </div>
          </div>

          {answerError && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl">
              {answerError}
            </div>
          )}

          <form onSubmit={handleSubmitAnswer} className="space-y-3">
            <textarea
              id="answer-content-input"
              rows={5}
              placeholder="Write a clear, structured explanation. Explain the concepts, logic, or step-by-step math/code..."
              value={answerText}
              onChange={e => setAnswerText(e.target.value)}
              className="w-full text-xs p-3.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden leading-relaxed font-sans"
            />

            {/* Answer Image Preview */}
            {answerImagePreview && (
              <div className="relative inline-block border border-slate-200 rounded-xl overflow-hidden">
                <img
                  src={answerImagePreview}
                  alt="Answer diagram preview"
                  className="max-h-36 rounded-lg object-contain bg-slate-900"
                />
                <button
                  type="button"
                  onClick={() => {
                    setAnswerImageFile(null);
                    if (answerImagePreview) URL.revokeObjectURL(answerImagePreview);
                    setAnswerImagePreview(null);
                  }}
                  className="absolute top-1.5 right-1.5 p-1 bg-rose-600 text-white rounded-md"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}

            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <label
                htmlFor="answer-image-upload"
                className="inline-flex items-center gap-1.5 text-xs text-slate-600 hover:text-indigo-600 cursor-pointer p-1 rounded hover:bg-slate-50"
              >
                <ImageIcon className="w-4 h-4 text-slate-500" />
                <span>Attach Diagram (Optional)</span>
                <input
                  id="answer-image-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleAnswerImageChange}
                  className="hidden"
                />
              </label>

              <button
                type="submit"
                id="submit-answer-btn"
                disabled={submittingAnswer}
                className="inline-flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                {submittingAnswer ? (
                  <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : (
                  <Send className="w-3.5 h-3.5" />
                )}
                <span>Post Answer</span>
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Lightbox Modal */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <button
            onClick={() => setLightboxImage(null)}
            className="absolute top-4 right-4 text-white hover:text-slate-300 p-2 bg-black/50 rounded-full"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={lightboxImage}
            alt="Enlarged Diagram"
            className="max-h-[90vh] max-w-[95vw] object-contain rounded-lg"
          />
        </div>
      )}
    </div>
  );
};
