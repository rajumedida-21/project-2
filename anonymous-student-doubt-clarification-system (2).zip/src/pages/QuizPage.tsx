import React, { useState, useEffect } from 'react';
import {
  Brain,
  Sparkles,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Award,
  AlertTriangle,
  History,
  TrendingUp,
} from 'lucide-react';
import { QuizQuestion, QuizResult } from '../types';
import { generateAIQuiz } from '../services/aiService';
import {
  saveQuizResult,
  subscribeToUserQuizResults,
} from '../services/quizService';
import { useAuth } from '../context/AuthContext';

const SUBJECT_OPTIONS = [
  'Data Structures & Algorithms',
  'Database Management Systems',
  'Operating Systems',
  'Computer Networks',
  'Object Oriented Programming',
  'System Design',
  'Web Development',
  'Machine Learning',
];

interface QuizPageProps {
  onNavigateToProgress?: () => void;
}

export const QuizPage: React.FC<QuizPageProps> = ({ onNavigateToProgress }) => {
  const { currentUser } = useAuth();

  // Generator Setup State
  const [subject, setSubject] = useState(SUBJECT_OPTIONS[0]);
  const [topic, setTopic] = useState('Binary Search Trees');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [questionCount, setQuestionCount] = useState(5);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);

  // Active Quiz Playing State
  const [activeQuiz, setActiveQuiz] = useState<QuizQuestion[] | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [timerRunning, setTimerRunning] = useState(false);

  // Quiz Results / Review State
  const [completedResult, setCompletedResult] = useState<QuizResult | null>(null);

  // Past results
  const [pastResults, setPastResults] = useState<QuizResult[]>([]);

  useEffect(() => {
    const unsub = subscribeToUserQuizResults(currentUser?.uid || 'guest_student', res => {
      setPastResults(res);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  // Timer tick
  useEffect(() => {
    let interval: any;
    if (timerRunning) {
      interval = setInterval(() => setSecondsElapsed(s => s + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [timerRunning]);

  const handleStartQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    setGenError(null);
    setActiveQuiz(null);
    setCompletedResult(null);

    try {
      const data = await generateAIQuiz({
        subject,
        topic,
        difficulty,
        questionCount,
      });

      if (!data?.questions || !Array.isArray(data.questions) || data.questions.length === 0) {
        throw new Error('AI was unable to format questions. Please try again.');
      }

      setActiveQuiz(data.questions);
      setCurrentIdx(0);
      setUserAnswers({});
      setSecondsElapsed(0);
      setTimerRunning(true);
    } catch (err: any) {
      setGenError(err?.message || 'Could not generate quiz. Please retry.');
    } finally {
      setGenerating(false);
    }
  };

  const handleSelectOption = (questionId: string, optionIdx: number) => {
    setUserAnswers(prev => ({
      ...prev,
      [questionId]: optionIdx,
    }));
  };

  const handleSubmitQuiz = async () => {
    if (!activeQuiz) return;
    setTimerRunning(false);

    let correct = 0;
    activeQuiz.forEach(q => {
      if (userAnswers[q.id] === q.correctIndex) {
        correct++;
      }
    });

    const total = activeQuiz.length;
    const scorePercentage = Math.round((correct / total) * 100);

    const result: QuizResult = {
      resultId: 'quiz_' + Date.now(),
      userId: currentUser?.uid || 'guest_student',
      subject,
      topic,
      difficulty,
      totalQuestions: total,
      correctCount: correct,
      scorePercentage,
      questions: activeQuiz,
      userAnswers,
      createdAt: new Date().toISOString(),
    };

    await saveQuizResult(result);
    setCompletedResult(result);
    setActiveQuiz(null);
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins}:${remainder < 10 ? '0' : ''}${remainder}`;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden border border-slate-800 shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs px-3 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI Academic Assessment Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            AI Concept Mastery & Quiz Generator
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Generate customized, multiple-choice quizzes for any computer science or academic topic. Receive instant grades, explanations for wrong options, and detect weak areas.
          </p>
        </div>
      </div>

      {/* VIEW 1: Active Quiz Playing Screen */}
      {activeQuiz && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-6">
          {/* Quiz Top bar: Progress & Timer */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-lg border border-indigo-200">
                Question {currentIdx + 1} of {activeQuiz.length}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {subject} • {topic}
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-slate-100 px-3 py-1 rounded-lg">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>{formatTime(secondsElapsed)}</span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-full transition-all duration-300"
              style={{ width: `${((currentIdx + 1) / activeQuiz.length) * 100}%` }}
            />
          </div>

          {/* Question Text */}
          {activeQuiz[currentIdx] && (
            <div className="space-y-4">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                {activeQuiz[currentIdx].question}
              </h2>

              {/* Options */}
              <div className="space-y-2.5">
                {activeQuiz[currentIdx].options.map((opt, optIdx) => {
                  const isSelected = userAnswers[activeQuiz[currentIdx].id] === optIdx;
                  return (
                    <button
                      key={optIdx}
                      type="button"
                      onClick={() => handleSelectOption(activeQuiz[currentIdx].id, optIdx)}
                      className={`w-full text-left p-4 rounded-xl border text-xs sm:text-sm font-medium transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-50 border-indigo-500 text-indigo-950 ring-2 ring-indigo-200 shadow-2xs'
                          : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                            isSelected
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span>{opt}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Navigation & Submit Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setCurrentIdx(prev => Math.max(prev - 1, 0))}
              disabled={currentIdx === 0}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            {currentIdx < activeQuiz.length - 1 ? (
              <button
                type="button"
                onClick={() => setCurrentIdx(prev => prev + 1)}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>Next</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmitQuiz}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Submit Quiz & Review Answers</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: Completed Quiz Results & Explanations */}
      {completedResult && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-6">
          {/* Score Header */}
          <div className="p-6 rounded-2xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <span className="text-xs font-semibold text-indigo-300 uppercase tracking-wider">
                Quiz Evaluation Complete
              </span>
              <h2 className="text-2xl font-black">
                {completedResult.scorePercentage >= 80
                  ? 'Outstanding Mastery! 🎉'
                  : completedResult.scorePercentage >= 60
                  ? 'Good Effort! Keep Reinforcing 👍'
                  : 'Needs Review & Practice 📚'}
              </h2>
              <p className="text-xs text-slate-300">
                Subject: {completedResult.subject} • Topic: {completedResult.topic}
              </p>
            </div>

            <div className="text-center bg-white/10 px-6 py-4 rounded-2xl border border-white/10 shrink-0">
              <span className="text-3xl font-black text-emerald-400 block">
                {completedResult.scorePercentage}%
              </span>
              <span className="text-xs text-slate-300">
                {completedResult.correctCount} / {completedResult.totalQuestions} Correct
              </span>
            </div>
          </div>

          {/* Weak Topic Alert if < 70% */}
          {completedResult.scorePercentage < 70 && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3 text-xs text-amber-900">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-sm mb-0.5">
                  Weak Topic Identified: {completedResult.topic}
                </span>
                <p>
                  Your accuracy on this topic was {completedResult.scorePercentage}%. We recommend reviewing the detailed explanations below, chatting with the AI Tutor, and taking a follow-up test.
                </p>
              </div>
            </div>
          )}

          {/* Detailed Question Review */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-indigo-600" />
              <span>Question-by-Question Breakdown & Explanations</span>
            </h3>

            {completedResult.questions.map((q, idx) => {
              const selectedOpt = completedResult.userAnswers[q.id];
              const isCorrect = selectedOpt === q.correctIndex;

              return (
                <div
                  key={q.id || idx}
                  className={`p-5 rounded-2xl border transition-all space-y-3 ${
                    isCorrect
                      ? 'bg-emerald-50/20 border-emerald-200'
                      : 'bg-rose-50/20 border-rose-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <span className="text-xs font-bold text-slate-500">
                      Q{idx + 1}.
                    </span>
                    <h4 className="text-xs sm:text-sm font-bold text-slate-900 flex-1">
                      {q.question}
                    </h4>
                    <span
                      className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                        isCorrect
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {isCorrect ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                          Correct
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3 text-rose-700" />
                          Incorrect
                        </>
                      )}
                    </span>
                  </div>

                  {/* Options List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {q.options.map((opt, optIdx) => {
                      const isOptionCorrect = optIdx === q.correctIndex;
                      const isOptionSelected = optIdx === selectedOpt;

                      return (
                        <div
                          key={optIdx}
                          className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                            isOptionCorrect
                              ? 'bg-emerald-100/70 border-emerald-300 text-emerald-950 font-semibold'
                              : isOptionSelected && !isCorrect
                              ? 'bg-rose-100/70 border-rose-300 text-rose-950 font-semibold line-through'
                              : 'bg-white border-slate-200 text-slate-600'
                          }`}
                        >
                          <span className="font-bold text-[10px]">
                            {String.fromCharCode(65 + optIdx)}.
                          </span>
                          <span>{opt}</span>
                          {isOptionCorrect && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 ml-auto shrink-0" />
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Conceptual Explanation */}
                  <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 space-y-1">
                    <span className="font-bold text-indigo-700 flex items-center gap-1 text-[11px]">
                      <Sparkles className="w-3 h-3" />
                      Academic Explanation:
                    </span>
                    <p className="leading-relaxed">{q.explanation}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                setCompletedResult(null);
                setActiveQuiz(null);
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Create Another Quiz</span>
            </button>

            {onNavigateToProgress && (
              <button
                type="button"
                onClick={onNavigateToProgress}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer shadow-xs"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>View Learning Analysis →</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: Quiz Generator Form (When not taking a quiz) */}
      {!activeQuiz && !completedResult && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <Brain className="w-4 h-4 text-indigo-600" />
              <h2 className="text-sm font-bold text-slate-900">Configure Academic Quiz</h2>
            </div>

            <form onSubmit={handleStartQuiz} className="space-y-4">
              {/* Subject */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Select Subject:
                </label>
                <select
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {SUBJECT_OPTIONS.map(s => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              {/* Topic */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Topic / Subtopic:
                </label>
                <input
                  type="text"
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                  placeholder="e.g. Binary Search Trees, Graph BFS/DFS, Normalization"
                  required
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Difficulty & Count */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Difficulty Level:
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['Easy', 'Medium', 'Hard'] as const).map(diff => (
                      <button
                        key={diff}
                        type="button"
                        onClick={() => setDifficulty(diff)}
                        className={`py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                          difficulty === diff
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {diff}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Question Count:
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[5, 10, 15].map(cnt => (
                      <button
                        key={cnt}
                        type="button"
                        onClick={() => setQuestionCount(cnt)}
                        className={`py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                          questionCount === cnt
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {cnt} Qs
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {genError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
                  {genError}
                </div>
              )}

              <button
                type="submit"
                disabled={generating}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-transform active:scale-98 cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Sparkles className={`w-4 h-4 ${generating ? 'animate-spin' : ''}`} />
                <span>{generating ? 'Generating academic quiz...' : 'Generate & Start Quiz'}</span>
              </button>
            </form>
          </div>

          {/* Past Quiz History */}
          <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <History className="w-4 h-4 text-slate-500" />
              <h3 className="text-sm font-bold text-slate-900">
                Your Quiz Performance History ({pastResults.length})
              </h3>
            </div>

            {pastResults.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500 space-y-1">
                <p className="font-semibold">No quizzes taken yet.</p>
                <p>Generate your first quiz to track accuracy and identify weak topics.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {pastResults.map(res => (
                  <div
                    key={res.resultId}
                    className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-800 block">{res.topic}</span>
                      <span className="text-[11px] text-slate-400">
                        {res.subject} • {res.difficulty}
                      </span>
                    </div>

                    <div className="text-right">
                      <span
                        className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                          res.scorePercentage >= 70
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {res.scorePercentage}%
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {res.correctCount}/{res.totalQuestions}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
