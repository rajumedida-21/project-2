import React, { useState, useEffect } from 'react';
import {
  Brain,
  RotateCw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Plus,
  Trash2,
  Sparkles,
  Bot,
  Filter,
  Check,
  ChevronRight,
  Flame,
  Award,
  BookOpen,
} from 'lucide-react';
import {
  SmartFlashcardItem,
  FlashcardMasteryStatus,
} from '../types';
import {
  getAllFlashcards,
  getDueFlashcards,
  getFlashcardStats,
  recordCardReview,
  addFlashcard,
  deleteFlashcard,
  ReviewGrade,
} from '../services/revisionService';
import { recordActivityEvent } from '../services/gamificationService';

interface SmartRevisionPageProps {
  onNavigateToTutor?: (initialPrompt?: string) => void;
}

export const SmartRevisionPage: React.FC<SmartRevisionPageProps> = ({
  onNavigateToTutor,
}) => {
  const [cards, setCards] = useState<SmartFlashcardItem[]>([]);
  const [stats, setStats] = useState(getFlashcardStats());
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'due' | 'difficult' | 'learning' | 'mastered'>('due');

  // Interactive study mode state
  const [activeStudyIndex, setActiveStudyIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [studyMode, setStudyMode] = useState<'deck' | 'list'>('deck');

  // Add Card Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newFront, setNewFront] = useState('');
  const [newBack, setNewBack] = useState('');
  const [newCategory, setNewCategory] = useState('Computer Science');

  const refreshData = () => {
    setCards(getAllFlashcards());
    setStats(getFlashcardStats());
  };

  useEffect(() => {
    refreshData();
  }, []);

  const getFilteredCards = (): SmartFlashcardItem[] => {
    const dueCards = getDueFlashcards();
    switch (selectedFilter) {
      case 'due':
        return dueCards;
      case 'difficult':
        return cards.filter(c => c.status === 'difficult');
      case 'learning':
        return cards.filter(c => c.status === 'learning');
      case 'mastered':
        return cards.filter(c => c.status === 'mastered');
      default:
        return cards;
    }
  };

  const currentStudyList = getFilteredCards();
  const currentCard = currentStudyList[activeStudyIndex] || null;

  const handleGrade = (grade: ReviewGrade) => {
    if (!currentCard) return;

    recordCardReview(currentCard.id, grade);
    recordActivityEvent({ type: 'flashcard_reviewed' });
    refreshData();
    setIsFlipped(false);

    if (activeStudyIndex < currentStudyList.length - 1) {
      setActiveStudyIndex(prev => prev + 1);
    } else {
      setActiveStudyIndex(0);
    }
  };

  const handleCreateCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFront.trim() || !newBack.trim()) return;

    addFlashcard({
      front: newFront.trim(),
      back: newBack.trim(),
      category: newCategory,
      status: 'new',
    });

    setNewFront('');
    setNewBack('');
    setIsAddModalOpen(false);
    refreshData();
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this flashcard?')) {
      deleteFlashcard(id);
      refreshData();
      if (activeStudyIndex >= currentStudyList.length - 1) {
        setActiveStudyIndex(Math.max(0, currentStudyList.length - 2));
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Spaced Revision & Smart Flashcards</h1>
              <p className="text-xs sm:text-sm text-slate-500">
                Active recall memory engine based on the SM-2 algorithm to prevent knowledge decay.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setStudyMode('deck')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                studyMode === 'deck' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
              }`}
            >
              Interactive Deck
            </button>
            <button
              onClick={() => setStudyMode('list')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                studyMode === 'list' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
              }`}
            >
              Card Library
            </button>
          </div>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Flashcard</span>
          </button>
        </div>
      </div>

      {/* Spaced Repetition Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Due for Review</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{stats.dueCount}</div>
          <span className="text-[11px] text-amber-600 font-medium">Ready for active recall</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Mastered</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-emerald-600">{stats.mastered}</div>
          <span className="text-[11px] text-slate-500">{stats.masteryPercentage}% long-term retention</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Needs Work</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-bold text-rose-600">{stats.difficult}</div>
          <span className="text-[11px] text-rose-600 font-medium">Frequent mistakes</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Learning</span>
            <BookOpen className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold text-indigo-600">{stats.learning}</div>
          <span className="text-[11px] text-slate-500">In progression</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Total Deck Size</span>
            <Brain className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{stats.total}</div>
          <span className="text-[11px] text-slate-500">{stats.newCards} unstudied</span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => { setSelectedFilter('due'); setActiveStudyIndex(0); setIsFlipped(false); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            selectedFilter === 'due'
              ? 'bg-amber-600 text-white shadow-2xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          ⏰ Due Today ({stats.dueCount})
        </button>
        <button
          onClick={() => { setSelectedFilter('difficult'); setActiveStudyIndex(0); setIsFlipped(false); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            selectedFilter === 'difficult'
              ? 'bg-rose-600 text-white shadow-2xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          ⚠️ High Mistake ({stats.difficult})
        </button>
        <button
          onClick={() => { setSelectedFilter('learning'); setActiveStudyIndex(0); setIsFlipped(false); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            selectedFilter === 'learning'
              ? 'bg-indigo-600 text-white shadow-2xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          📚 In Progress ({stats.learning})
        </button>
        <button
          onClick={() => { setSelectedFilter('mastered'); setActiveStudyIndex(0); setIsFlipped(false); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            selectedFilter === 'mastered'
              ? 'bg-emerald-600 text-white shadow-2xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          🌟 Mastered ({stats.mastered})
        </button>
        <button
          onClick={() => { setSelectedFilter('all'); setActiveStudyIndex(0); setIsFlipped(false); }}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
            selectedFilter === 'all'
              ? 'bg-slate-900 text-white shadow-2xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          All Cards ({stats.total})
        </button>
      </div>

      {/* Main View: Interactive Deck vs List */}
      {studyMode === 'deck' ? (
        currentCard ? (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Progress counter */}
            <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>
                Card {activeStudyIndex + 1} of {currentStudyList.length}
              </span>
              <span className="bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full font-semibold">
                {currentCard.category}
              </span>
            </div>

            {/* Flashcard Box with Flip */}
            <div
              onClick={() => setIsFlipped(!isFlipped)}
              className="bg-white rounded-3xl border-2 border-slate-200 hover:border-indigo-300 min-h-[320px] sm:min-h-[360px] p-8 sm:p-10 flex flex-col justify-between shadow-md cursor-pointer transition-all duration-300 relative select-none"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  {isFlipped ? '💡 Explanation & Key Concept' : '❓ Question / Prompt'}
                </span>
                <span
                  className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                    currentCard.status === 'mastered'
                      ? 'bg-emerald-50 text-emerald-700'
                      : currentCard.status === 'difficult'
                      ? 'bg-rose-50 text-rose-700'
                      : 'bg-indigo-50 text-indigo-700'
                  }`}
                >
                  {currentCard.status.toUpperCase()}
                </span>
              </div>

              <div className="my-auto text-center py-6">
                {isFlipped ? (
                  <p className="text-base sm:text-lg text-slate-800 font-medium leading-relaxed">
                    {currentCard.back}
                  </p>
                ) : (
                  <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
                    {currentCard.front}
                  </h3>
                )}
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 pt-4 border-t border-slate-100">
                <span className="flex items-center gap-1">
                  <RotateCw className="w-3.5 h-3.5" /> Click anywhere to flip
                </span>
                {onNavigateToTutor && (
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      onNavigateToTutor(`Can you explain this flashcard in detail: "${currentCard.front}"`);
                    }}
                    className="inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-800 font-semibold"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    <span>Explain with AI Tutor</span>
                  </button>
                )}
              </div>
            </div>

            {/* Response Rating Bar */}
            {isFlipped ? (
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-500 block text-center">
                  How well did you recall this concept?
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => handleGrade('again')}
                    className="p-3 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 text-xs font-bold transition-colors cursor-pointer flex flex-col items-center gap-1"
                  >
                    <span>🔴 Again</span>
                    <span className="text-[10px] font-normal text-rose-600">Review in 4h</span>
                  </button>
                  <button
                    onClick={() => handleGrade('hard')}
                    className="p-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 text-xs font-bold transition-colors cursor-pointer flex flex-col items-center gap-1"
                  >
                    <span>🟡 Hard</span>
                    <span className="text-[10px] font-normal text-amber-600">Review in 12h</span>
                  </button>
                  <button
                    onClick={() => handleGrade('good')}
                    className="p-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-800 text-xs font-bold transition-colors cursor-pointer flex flex-col items-center gap-1"
                  >
                    <span>🟢 Good</span>
                    <span className="text-[10px] font-normal text-indigo-600">Review in 1-3d</span>
                  </button>
                  <button
                    onClick={() => handleGrade('easy')}
                    className="p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs font-bold transition-colors cursor-pointer flex flex-col items-center gap-1"
                  >
                    <span>🌟 Easy</span>
                    <span className="text-[10px] font-normal text-emerald-600">Review in 7d</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <button
                  onClick={() => setIsFlipped(true)}
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  Show Answer & Explanation
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-lg mx-auto space-y-4 shadow-2xs">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">All caught up for this filter!</h3>
            <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
              No pending flashcards matching "{selectedFilter}". Great job maintaining your spaced repetition schedule!
            </p>
            <button
              onClick={() => { setSelectedFilter('all'); setActiveStudyIndex(0); }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs transition-colors"
            >
              Browse All Flashcards
            </button>
          </div>
        )
      ) : (
        /* Library List Mode */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {currentStudyList.map(card => (
            <div
              key={card.id}
              className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs flex flex-col justify-between space-y-4 hover:border-indigo-300 transition-colors"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                    {card.category}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      card.status === 'mastered'
                        ? 'bg-emerald-50 text-emerald-700'
                        : card.status === 'difficult'
                        ? 'bg-rose-50 text-rose-700'
                        : 'bg-indigo-50 text-indigo-700'
                    }`}
                  >
                    {card.status.toUpperCase()}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 line-clamp-2">{card.front}</h4>
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">{card.back}</p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100 text-xs text-slate-500">
                <span>Reviews: {card.timesReviewed}</span>
                <button
                  type="button"
                  onClick={e => handleDelete(card.id, e)}
                  className="p-1 hover:text-rose-600 transition-colors"
                  title="Delete card"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Flashcard Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-6 space-y-4 shadow-xl">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Plus className="w-4 h-4 text-indigo-600" />
              Create Spaced Revision Flashcard
            </h2>

            <form onSubmit={handleCreateCard} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Subject / Category
                </label>
                <input
                  type="text"
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  placeholder="e.g. Operating Systems, Calculus"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Front (Prompt or Question)
                </label>
                <textarea
                  value={newFront}
                  onChange={e => setNewFront(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none resize-none"
                  placeholder="e.g. What is the difference between mutex and semaphore?"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Back (Explanation, Formula, or Code Concept)
                </label>
                <textarea
                  value={newBack}
                  onChange={e => setNewBack(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none resize-none"
                  placeholder="e.g. Mutex is a locking mechanism for 1 thread at a time. Semaphore is a signaling mechanism..."
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs"
                >
                  Save Flashcard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
