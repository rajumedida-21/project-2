import React from 'react';
import { Subject } from '../types';
import { BookOpen, Layers, ArrowRight, Code, Database, Cpu, Brain, Network } from 'lucide-react';

interface SubjectsPageProps {
  subjects: Subject[];
  onSelectSubjectAndNavigate: (subjectId: string) => void;
  onOpenAskModal: () => void;
}

export const SubjectsPage: React.FC<SubjectsPageProps> = ({
  subjects,
  onSelectSubjectAndNavigate,
  onOpenAskModal,
}) => {
  const getSubjectIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes('data structure') || lower.includes('algorithm')) return <Code className="w-5 h-5 text-indigo-600" />;
    if (lower.includes('dbms') || lower.includes('database')) return <Database className="w-5 h-5 text-emerald-600" />;
    if (lower.includes('operating') || lower.includes('system')) return <Cpu className="w-5 h-5 text-amber-600" />;
    if (lower.includes('ai') || lower.includes('machine') || lower.includes('intelligence')) return <Brain className="w-5 h-5 text-purple-600" />;
    if (lower.includes('network')) return <Network className="w-5 h-5 text-blue-600" />;
    return <BookOpen className="w-5 h-5 text-slate-600" />;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-xs px-3 py-1 rounded-full mb-2">
            <Layers className="w-3.5 h-3.5" />
            <span>Academic Curriculum Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">Academic Subjects & Topics</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl leading-relaxed">
            Browse through core computer science and engineering disciplines. Filter questions by subject or post a doubt directly into a category.
          </p>
        </div>

        <button
          onClick={onOpenAskModal}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer transition-colors self-start"
        >
          Ask Doubt in Any Subject
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map(s => (
          <div
            key={s.subjectId}
            onClick={() => onSelectSubjectAndNavigate(s.subjectId)}
            className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs hover:shadow-md hover:border-indigo-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl group-hover:scale-105 transition-transform">
                  {getSubjectIcon(s.name)}
                </div>
                <span className="text-[11px] font-mono text-slate-400">
                  {s.subjectId}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors mb-1">
                {s.name}
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                {s.description || 'Core concepts, practical assignments, and academic doubts.'}
              </p>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-indigo-600 group-hover:text-indigo-700">
              <span>Explore Doubts</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
