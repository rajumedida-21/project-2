import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  CheckCircle2,
  Circle,
  Plus,
  Trash2,
  Clock,
  Flame,
  Filter,
  Check,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { StudyTask } from '../types';
import {
  createStudyTask,
  subscribeToStudyTasks,
  toggleStudyTaskCompletion,
  deleteStudyTask,
} from '../services/studyService';
import { useAuth } from '../context/AuthContext';

export const StudyPlannerPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [tasks, setTasks] = useState<StudyTask[]>([]);
  const [filter, setFilter] = useState<'all' | 'today' | 'upcoming' | 'completed'>('today');

  // New task form state
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('Data Structures & Algorithms');
  const [topic, setTopic] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [priority, setPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const unsub = subscribeToStudyTasks(currentUser?.uid || 'guest_student', tList => {
      setTasks(tList);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setSubmitting(true);

    const newTask: StudyTask = {
      taskId: 'task_' + Date.now(),
      userId: currentUser?.uid || 'guest_student',
      title: title.trim(),
      subject,
      topic: topic.trim() || 'General Study',
      date,
      durationMinutes,
      priority,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    await createStudyTask(newTask);
    setTitle('');
    setTopic('');
    setShowAddModal(false);
    setSubmitting(false);
  };

  const handleToggle = async (taskId: string, currentCompleted: boolean) => {
    await toggleStudyTaskCompletion(taskId, !currentCompleted);
  };

  const handleDelete = async (taskId: string) => {
    if (confirm('Delete this task?')) {
      await deleteStudyTask(taskId);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];

  const todayTasks = tasks.filter(t => t.date === todayStr);
  const upcomingTasks = tasks.filter(t => t.date > todayStr && !t.completed);
  const completedTasks = tasks.filter(t => t.completed);

  const displayedTasks = tasks.filter(t => {
    if (filter === 'today') return t.date === todayStr;
    if (filter === 'upcoming') return t.date > todayStr && !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  });

  const totalMinutesStudied = completedTasks.reduce((acc, t) => acc + (t.durationMinutes || 0), 0);
  const hoursStudied = (totalMinutesStudied / 60).toFixed(1);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="relative z-10 max-w-xl space-y-2">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs px-3 py-1 rounded-full">
            <CalendarIcon className="w-3.5 h-3.5 text-indigo-400" />
            <span>Real-Time Academic Task Manager</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            Academic Study Planner
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Organize study blocks, track milestones, and maintain your active daily study streak.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Study Task</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Today&apos;s Tasks
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-slate-900">{todayTasks.length}</span>
            <span className="text-xs text-slate-500 font-medium">
              ({todayTasks.filter(t => t.completed).length} done)
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Upcoming Milestones
          </span>
          <span className="text-2xl font-black text-indigo-600 mt-1 block">
            {upcomingTasks.length}
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Completed Tasks
          </span>
          <span className="text-2xl font-black text-emerald-600 mt-1 block">
            {completedTasks.length}
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Study Hours Logged
          </span>
          <span className="text-2xl font-black text-purple-600 mt-1 block">
            {hoursStudied} hrs
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        {(['today', 'upcoming', 'completed', 'all'] as const).map(tab => (
          <button
            key={tab}
            type="button"
            onClick={() => setFilter(tab)}
            className={`px-4 py-2 rounded-xl text-xs font-bold capitalize transition-colors cursor-pointer ${
              filter === tab
                ? 'bg-indigo-600 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {tab === 'today' ? "Today's Schedule" : tab}
          </button>
        ))}
      </div>

      {/* Tasks List */}
      {displayedTasks.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 border border-slate-200/90 text-center space-y-3 shadow-2xs">
          <CalendarIcon className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No tasks found in this view</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Stay organized by scheduling daily revision sessions, topic deep dives, or exam practice.
          </p>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create a Task</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {displayedTasks.map(task => (
            <div
              key={task.taskId}
              className={`bg-white rounded-2xl p-4 border transition-all flex items-center justify-between gap-4 shadow-2xs ${
                task.completed
                  ? 'border-slate-200 bg-slate-50/50 opacity-75'
                  : 'border-slate-200 hover:border-indigo-300'
              }`}
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <button
                  type="button"
                  onClick={() => handleToggle(task.taskId, task.completed)}
                  className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                    task.completed
                      ? 'bg-emerald-500 text-white'
                      : 'border-2 border-slate-300 hover:border-indigo-600 text-transparent'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                </button>

                <div className="min-w-0 flex-1">
                  <span
                    className={`text-xs sm:text-sm font-bold block truncate ${
                      task.completed ? 'line-through text-slate-400' : 'text-slate-900'
                    }`}
                  >
                    {task.title}
                  </span>
                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                    <span className="font-semibold text-indigo-600">{task.subject}</span>
                    <span>•</span>
                    <span>{task.topic}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {task.durationMinutes} min
                    </span>
                    <span>•</span>
                    <span>{task.date}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    task.priority === 'High'
                      ? 'bg-rose-100 text-rose-700'
                      : task.priority === 'Medium'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {task.priority}
                </span>

                <button
                  type="button"
                  onClick={() => handleDelete(task.taskId)}
                  className="p-1 text-slate-300 hover:text-rose-500 rounded transition-colors cursor-pointer"
                  title="Delete task"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900">Schedule Study Task</h3>

            <form onSubmit={handleCreateTask} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Task Title:
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Solve 5 LeetCode DP Problems"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Subject:
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Topic:
                </label>
                <input
                  type="text"
                  placeholder="e.g., Memoization, Tabulation"
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Date:
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Duration (Minutes):
                  </label>
                  <input
                    type="number"
                    min={15}
                    max={360}
                    step={15}
                    value={durationMinutes}
                    onChange={e => setDurationMinutes(Number(e.target.value))}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Priority:
                </label>
                <select
                  value={priority}
                  onChange={e => setPriority(e.target.value as any)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                >
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                >
                  Add Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
