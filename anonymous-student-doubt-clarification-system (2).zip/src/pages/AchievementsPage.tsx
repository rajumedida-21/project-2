import React, { useState, useEffect } from 'react';
import {
  Award,
  Flame,
  HelpCircle,
  MessageSquare,
  Brain,
  CheckCircle2,
  Calendar,
  Sparkles,
  Lock,
} from 'lucide-react';
import { UserAchievement } from '../types';
import {
  ALL_BADGES,
  subscribeToAchievements,
  evaluateStudentAchievements,
} from '../services/achievementService';
import { subscribeToStudyTasks, calculateRealStreak } from '../services/studyService';
import { subscribeToUserQuizResults } from '../services/quizService';
import { getQuestionsByAuthor } from '../services/questionService';
import { useAuth } from '../context/AuthContext';

export const AchievementsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [unlocked, setUnlocked] = useState<UserAchievement[]>([]);
  const [streakDays, setStreakDays] = useState(0);

  useEffect(() => {
    const userId = currentUser?.uid || 'guest_student';

    const unsubAch = subscribeToAchievements(userId, list => setUnlocked(list));

    const unsubQuizzes = subscribeToUserQuizResults(userId, qList => {
      getQuestionsByAuthor(userId).then(dList => {
        const unsubTasks = subscribeToStudyTasks(userId, tList => {
          const quizDates = qList.map(q => q.createdAt);
          const doubtDates = dList.map(d => d.createdAt);
          const sStats = calculateRealStreak(tList, quizDates, doubtDates);
          setStreakDays(sStats.currentStreak);

          const completedTasksCount = tList.filter(t => t.completed).length;

          // Check and unlock new badges
          evaluateStudentAchievements(userId, {
            doubtsCount: dList.length,
            answersCount: 0,
            quizzesCount: qList.length,
            completedTasksCount,
            currentStreak: sStats.currentStreak,
            totalUpvotes: dList.reduce((acc, d) => acc + (d.upvotes || 0), 0),
          });
        });
        return () => unsubTasks();
      });
    });

    return () => {
      unsubAch();
      unsubQuizzes();
    };
  }, [currentUser?.uid]);

  const unlockedMap = new Map(unlocked.map(u => [u.badgeId, u]));

  const renderBadgeIcon = (iconName: string, isUnlocked: boolean) => {
    const baseClass = `w-6 h-6 ${isUnlocked ? 'text-indigo-600' : 'text-slate-400'}`;
    switch (iconName) {
      case 'HelpCircle':
        return <HelpCircle className={baseClass} />;
      case 'MessageSquare':
        return <MessageSquare className={baseClass} />;
      case 'Brain':
        return <Brain className={baseClass} />;
      case 'Flame':
        return <Flame className={`w-6 h-6 ${isUnlocked ? 'text-amber-500 fill-amber-500' : 'text-slate-400'}`} />;
      case 'Award':
        return <Award className={baseClass} />;
      case 'CheckCircle2':
        return <CheckCircle2 className={`w-6 h-6 ${isUnlocked ? 'text-emerald-600' : 'text-slate-400'}`} />;
      case 'Calendar':
        return <Calendar className={baseClass} />;
      default:
        return <Award className={baseClass} />;
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="relative z-10 max-w-xl space-y-2">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs px-3 py-1 rounded-full">
            <Award className="w-3.5 h-3.5 text-indigo-400" />
            <span>Academic Milestones & Gamification</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            Badges & Achievements
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Track your consistency, community participation, and conceptual mastery. Every milestone is stored securely in your permanent student record.
          </p>
        </div>

        <div className="bg-white/10 px-5 py-3 rounded-2xl border border-white/10 shrink-0 text-center sm:text-right">
          <span className="text-xs text-slate-300 block">Unlocked Badges</span>
          <span className="text-2xl font-black text-amber-400">
            {unlocked.length} / {ALL_BADGES.length}
          </span>
        </div>
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {ALL_BADGES.map(badge => {
          const userAch = unlockedMap.get(badge.badgeId);
          const isUnlocked = Boolean(userAch);

          return (
            <div
              key={badge.badgeId}
              className={`rounded-2xl p-5 border transition-all flex flex-col justify-between space-y-4 shadow-2xs ${
                isUnlocked
                  ? 'bg-white border-indigo-200 hover:border-indigo-300 hover:shadow-md'
                  : 'bg-slate-50/70 border-slate-200 opacity-70'
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-2xs ${
                    isUnlocked
                      ? 'bg-indigo-50 border border-indigo-200/80'
                      : 'bg-slate-200/60 border border-slate-300/60'
                  }`}
                >
                  {isUnlocked ? renderBadgeIcon(badge.icon, true) : <Lock className="w-5 h-5 text-slate-400" />}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-bold text-slate-900">{badge.title}</h3>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {badge.description}
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="capitalize text-slate-400 font-medium">
                  {badge.category}
                </span>

                {isUnlocked ? (
                  <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    Unlocked ✓
                  </span>
                ) : (
                  <span className="text-slate-400 font-medium">Locked</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
