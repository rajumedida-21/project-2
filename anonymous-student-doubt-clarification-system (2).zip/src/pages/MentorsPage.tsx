import React, { useEffect, useState } from 'react';
import { Award, CheckCircle2, BookOpen, GraduationCap, Shield, Mail, Sparkles, UserCheck } from 'lucide-react';
import { UserProfile } from '../types';
import { getVerifiedMentors } from '../services/userService';
import { MentorBadge } from '../components/MentorBadge';
import { useAuth } from '../context/AuthContext';

export const MentorsPage: React.FC<{ onOpenAskModal: () => void }> = ({ onOpenAskModal }) => {
  const { openAuthModal, currentUser } = useAuth();
  const [mentors, setMentors] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const list = await getVerifiedMentors();
        setMentors(list);
      } catch (err) {
        console.error('Error fetching mentors:', err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-linear-to-r from-emerald-950 via-slate-900 to-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-emerald-900/40 shadow-xl relative overflow-hidden">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-1.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs px-3 py-1 rounded-full">
            <UserCheck className="w-3.5 h-3.5" />
            <span>Academic Faculty & Verified TAs</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            Verified Academic Mentors
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            College professors, graduate assistants, and experienced subject-matter mentors who verify solutions, provide in-depth technical explanations, and guide students through challenging academic concepts.
          </p>

          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={onOpenAskModal}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer transition-colors"
            >
              Ask a Doubt to Mentors
            </button>
            {!currentUser && (
              <button
                onClick={() => openAuthModal('register')}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Join as a Mentor
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mentors Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-600" />
            <span>Active Verified Mentors ({mentors.length})</span>
          </h2>
          <span className="text-xs text-slate-500">Subject specialization certified</span>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map(n => (
              <div key={n} className="h-44 bg-white rounded-2xl border border-slate-200 animate-pulse" />
            ))}
          </div>
        ) : mentors.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-3">
            <Award className="w-12 h-12 text-slate-300 mx-auto" />
            <h3 className="text-sm font-bold text-slate-700">No verified mentors listed yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Are you a faculty member or student tutor? Register with the Mentor role and an administrator will grant your verification badge.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mentors.map(m => (
              <div
                key={m.uid}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 font-extrabold text-lg flex items-center justify-center shrink-0 shadow-2xs">
                      {m.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-bold text-slate-900 truncate">{m.name}</h3>
                      <MentorBadge specialization={m.subjectSpecialization} size="sm" />
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed font-sans line-clamp-3">
                    {m.bio ||
                      `Academic mentor specializing in ${
                        m.subjectSpecialization || 'Computer Science'
                      }. Answers student queries and validates solutions.`}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Verified by College
                  </span>
                  <span className="font-medium text-emerald-700">Active Mentor</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* How to Become a Mentor Guide */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs space-y-4">
        <h3 className="text-base font-bold text-slate-900">How to Become a Verified Academic Mentor</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-600">
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1.5">
            <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs mb-1">
              1
            </span>
            <h4 className="font-bold text-slate-900">Register as Mentor</h4>
            <p>Create an account and select &ldquo;Mentor / Teacher&rdquo; with your subject specialization.</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1.5">
            <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs mb-1">
              2
            </span>
            <h4 className="font-bold text-slate-900">Admin Verification</h4>
            <p>System administrators check academic credentials and activate your verified status.</p>
          </div>
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1.5">
            <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-xs mb-1">
              3
            </span>
            <h4 className="font-bold text-slate-900">Guide Students</h4>
            <p>Your answers display the official Verified Mentor badge to provide authoritative help.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
