import React, { useEffect, useState } from 'react';
import {
  ShieldAlert,
  Users,
  HelpCircle,
  MessageSquare,
  Award,
  CheckCircle2,
  XCircle,
  Trash2,
  Search,
  PlusCircle,
  Database,
  Layers,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
  BarChart3,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Report, UserProfile, Question, Subject } from '../types';
import { getAllReports, updateReportStatus, deleteReport } from '../services/reportService';
import { getAllUsers, updateUserProfile } from '../services/userService';
import { getQuestions, deleteQuestion } from '../services/questionService';
import { deleteAnswer } from '../services/answerService';
import { getSubjects, addSubject, seedDefaultSubjects } from '../services/subjectService';
import { formatRelativeTime } from '../utils/dateUtils';
import { MentorBadge } from '../components/MentorBadge';
import { DoubtAnalytics } from '../components/DoubtAnalytics';

interface AdminDashboardPageProps {
  onOpenQuestion: (questionId: string) => void;
  initialTab?: 'reports' | 'users' | 'questions' | 'subjects' | 'analytics';
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onOpenQuestion, initialTab }) => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'reports' | 'users' | 'questions' | 'subjects' | 'analytics'>(
    initialTab || 'analytics'
  );

  const [reports, setReports] = useState<Report[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  // New subject form
  const [newSubName, setNewSubName] = useState('');
  const [newSubDesc, setNewSubDesc] = useState('');

  // Search filter
  const [searchFilter, setSearchFilter] = useState('');

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [rList, uList, qList, sList] = await Promise.all([
        getAllReports(),
        getAllUsers(),
        getQuestions({}),
        getSubjects(),
      ]);
      setReports(rList);
      setUsers(uList);
      setQuestions(qList);
      setSubjects(sList);
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser?.role === 'admin') {
      loadAllAdminData();
    }
  }, [currentUser?.role]);

  if (currentUser?.role !== 'admin') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-14 h-14 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto shadow-2xs">
          <ShieldAlert className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Admin Access Restricted</h2>
        <p className="text-xs text-slate-500 max-w-md mx-auto">
          You must be an administrator to access the moderation console and user verification dashboard.
          Firebase Security Rules also protect this collection from unauthorized access.
        </p>
      </div>
    );
  }

  const pendingReportsCount = reports.filter(r => r.status === 'pending').length;
  const verifiedMentorsCount = users.filter(u => u.isVerifiedMentor).length;

  const handleUpdateReport = async (report: Report, newStatus: Report['status']) => {
    try {
      await updateReportStatus(report.reportId, newStatus, report.reportedBy);
      setReports(prev =>
        prev.map(r => (r.reportId === report.reportId ? { ...r, status: newStatus } : r))
      );
    } catch {
      alert('Failed to update report status');
    }
  };

  const handleDeleteReportedContent = async (report: Report) => {
    if (!confirm(`Are you sure you want to delete this reported ${report.contentType}?`)) return;
    setActionLoading(true);
    try {
      if (report.contentType === 'question') {
        await deleteQuestion(report.contentId);
      } else {
        // Answer
        await deleteAnswer(report.contentId, '');
      }
      await updateReportStatus(report.reportId, 'resolved', report.reportedBy);
      setReports(prev =>
        prev.map(r => (r.reportId === report.reportId ? { ...r, status: 'resolved' } : r))
      );
      alert('Reported content deleted and report resolved.');
    } catch {
      alert('Error deleting content.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleMentor = async (user: UserProfile) => {
    const nextState = !user.isVerifiedMentor;
    try {
      await updateUserProfile(user.uid, {
        isVerifiedMentor: nextState,
        role: nextState ? 'mentor' : user.role === 'admin' ? 'admin' : 'student',
      });
      setUsers(prev =>
        prev.map(u => (u.uid === user.uid ? { ...u, isVerifiedMentor: nextState } : u))
      );
    } catch {
      alert('Failed to update mentor status');
    }
  };

  const handleAddSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubName.trim()) return;
    try {
      const added = await addSubject({
        name: newSubName.trim(),
        description: newSubDesc.trim(),
      });
      setSubjects(prev => [...prev, added]);
      setNewSubName('');
      setNewSubDesc('');
    } catch {
      alert('Failed to add subject');
    }
  };

  const handleSeedDefaults = async () => {
    try {
      await seedDefaultSubjects();
      const updated = await getSubjects();
      setSubjects(updated);
      alert('Default academic subjects initialized successfully in Firestore!');
    } catch {
      alert('Error seeding subjects');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Admin Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs px-3 py-1 rounded-full mb-2">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Master Moderation & Security Console</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight">Admin Dashboard</h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Protect academic integrity, review reported questions or answers, verify college professors & mentors, and manage engineering topics.
          </p>
        </div>

        <button
          onClick={loadAllAdminData}
          disabled={loading}
          className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs px-4 py-2.5 rounded-xl transition-colors cursor-pointer self-start"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Total Students/Users</span>
            <Users className="w-4 h-4 text-indigo-600" />
          </div>
          <span className="text-2xl font-black text-slate-900 block">{users.length}</span>
          <span className="text-[11px] text-slate-400">Registered accounts</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Pending Reports</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <span className="text-2xl font-black text-rose-600 block">{pendingReportsCount}</span>
          <span className="text-[11px] text-slate-400">Flagged content needing review</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Verified Mentors</span>
            <Award className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-2xl font-black text-emerald-600 block">{verifiedMentorsCount}</span>
          <span className="text-[11px] text-slate-400">Active verified teachers</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Total Doubts</span>
            <HelpCircle className="w-4 h-4 text-indigo-600" />
          </div>
          <span className="text-2xl font-black text-slate-900 block">{questions.length}</span>
          <span className="text-[11px] text-slate-400">Across all engineering topics</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto no-scrollbar">
        <button
          id="admin-tab-analytics"
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
            activeTab === 'analytics'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Doubt Analytics & User Mapping</span>
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
            activeTab === 'reports'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Moderation & Reports ({pendingReportsCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
            activeTab === 'users'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Users & Mentors ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('questions')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
            activeTab === 'questions'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>All Doubts ({questions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('subjects')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
            activeTab === 'subjects'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Subjects & Categories ({subjects.length})</span>
        </button>
      </div>

      {/* TAB CONTENT: Reports */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          {reports.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="text-sm font-bold text-slate-800">Community is Clean</h3>
              <p className="text-xs text-slate-500">No reports have been filed by students or teachers.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map(rep => (
                <div
                  key={rep.reportId}
                  className={`bg-white rounded-2xl p-5 border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    rep.status === 'pending'
                      ? 'border-rose-300 ring-2 ring-rose-100'
                      : 'border-slate-200 opacity-80'
                  }`}
                >
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-rose-100 text-rose-800">
                        {rep.contentType} Flagged
                      </span>
                      <span className="text-xs font-bold text-slate-900">
                        Reason: {rep.reason}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                          rep.status === 'pending'
                            ? 'bg-amber-100 text-amber-800'
                            : rep.status === 'resolved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {rep.status}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {formatRelativeTime(rep.createdAt)}
                      </span>
                    </div>

                    {rep.contentSnippet && (
                      <p className="text-xs text-slate-700 italic bg-slate-50 p-2.5 rounded-lg border border-slate-200 line-clamp-2">
                        &ldquo;{rep.contentSnippet}&rdquo;
                      </p>
                    )}

                    {rep.details && (
                      <p className="text-xs text-slate-500">
                        <strong>Student comments:</strong> {rep.details}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {rep.contentType === 'question' && (
                      <button
                        onClick={() => onOpenQuestion(rep.contentId)}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Inspect</span>
                      </button>
                    )}

                    {rep.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleUpdateReport(rep, 'dismissed')}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-medium rounded-lg transition-colors cursor-pointer"
                        >
                          Dismiss
                        </button>
                        <button
                          onClick={() => handleDeleteReportedContent(rep)}
                          disabled={actionLoading}
                          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete Content</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: Users & Mentors */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchFilter}
                onChange={e => setSearchFilter(e.target.value)}
                placeholder="Search by name, email, or role..."
                className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
            <span className="text-xs text-slate-500">
              Total {users.length} registered accounts
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">Email</th>
                  <th className="p-3.5">Role</th>
                  <th className="p-3.5">Mentor Status</th>
                  <th className="p-3.5">Specialization</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users
                  .filter(
                    u =>
                      u.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
                      u.email.toLowerCase().includes(searchFilter.toLowerCase()) ||
                      u.role.toLowerCase().includes(searchFilter.toLowerCase())
                  )
                  .map(u => (
                    <tr key={u.uid} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5 font-bold text-slate-900">{u.name}</td>
                      <td className="p-3.5 text-slate-600 font-mono text-[11px]">{u.email}</td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold capitalize bg-slate-100 text-slate-700">
                          {u.role}
                        </span>
                      </td>
                      <td className="p-3.5">
                        {u.isVerifiedMentor ? (
                          <MentorBadge specialization="" size="sm" showSpecialization={false} />
                        ) : (
                          <span className="text-slate-400 text-[11px]">Unverified</span>
                        )}
                      </td>
                      <td className="p-3.5 text-slate-600 text-[11px]">
                        {u.subjectSpecialization || '—'}
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => handleToggleMentor(u)}
                          className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                            u.isVerifiedMentor
                              ? 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
                              : 'bg-emerald-600 text-white hover:bg-emerald-700'
                          }`}
                        >
                          {u.isVerifiedMentor ? 'Revoke Mentor' : 'Verify Mentor'}
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB CONTENT: Questions Moderation */}
      {activeTab === 'questions' && (
        <div className="space-y-3">
          {questions.map(q => (
            <div
              key={q.questionId}
              className="bg-white rounded-2xl p-4 border border-slate-200 flex items-center justify-between gap-4"
            >
              <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onOpenQuestion(q.questionId)}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">
                    {q.subjectName || q.subjectId}
                  </span>
                  <span className="text-xs text-slate-400">{formatRelativeTime(q.createdAt)}</span>
                </div>
                <h4 className="text-xs font-bold text-slate-900 truncate hover:text-indigo-600">
                  {q.title}
                </h4>
                <p className="text-[11px] text-slate-500 line-clamp-1">{q.description}</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => onOpenQuestion(q.questionId)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-xs font-medium rounded-lg"
                >
                  View
                </button>
                <button
                  onClick={async () => {
                    if (confirm('Delete this doubt permanently?')) {
                      await deleteQuestion(q.questionId);
                      setQuestions(prev => prev.filter(item => item.questionId !== q.questionId));
                    }
                  }}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                  title="Delete doubt"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB CONTENT: Subjects */}
      {activeTab === 'subjects' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Add Academic Subject</h3>
            <form onSubmit={handleAddSubject} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Subject Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Cloud Computing"
                  value={newSubName}
                  onChange={e => setNewSubName(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Brief Description</label>
                <textarea
                  rows={2}
                  placeholder="Virtualization, AWS, GCP, microservices..."
                  value={newSubDesc}
                  onChange={e => setNewSubDesc(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Save Subject</span>
              </button>
            </form>

            <div className="pt-3 border-t border-slate-100">
              <button
                onClick={handleSeedDefaults}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Database className="w-3.5 h-3.5 text-indigo-600" />
                <span>Seed Default CS Subjects</span>
              </button>
              <p className="text-[10px] text-slate-400 mt-1 text-center">
                Syncs Data Structures, DBMS, OS, Networks, Java, AI, etc.
              </p>
            </div>
          </div>

          <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {subjects.map(s => (
              <div
                key={s.subjectId}
                className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-1"
              >
                <h4 className="text-xs font-bold text-slate-900">{s.name}</h4>
                <p className="text-[11px] text-slate-500 line-clamp-2">{s.description || 'No description provided'}</p>
                <span className="text-[10px] font-mono text-indigo-600 block pt-1">
                  ID: {s.subjectId}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: Doubt Analytics */}
      {activeTab === 'analytics' && (
        <DoubtAnalytics onOpenQuestion={onOpenQuestion} />
      )}
    </div>
  );
};
