import React, { useEffect, useState } from 'react';
import {
  User,
  Shield,
  HelpCircle,
  MessageSquare,
  ThumbsUp,
  CheckCircle2,
  Lock,
  Trash2,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Question, Answer } from '../types';
import { getQuestionsByUser, deleteQuestion } from '../services/questionService';
import { getAnswersByUser, deleteAnswer } from '../services/answerService';
import { formatRelativeTime } from '../utils/dateUtils';
import { MentorBadge } from '../components/MentorBadge';

interface MyActivityPageProps {
  onOpenQuestion: (questionId: string) => void;
  onOpenAskModal: () => void;
}

export const MyActivityPage: React.FC<MyActivityPageProps> = ({
  onOpenQuestion,
  onOpenAskModal,
}) => {
  const { currentUser, openAuthModal } = useAuth();
  const [activeTab, setActiveTab] = useState<'questions' | 'answers'>('questions');
  const [myQuestions, setMyQuestions] = useState<Question[]>([]);
  const [myAnswers, setMyAnswers] = useState<Answer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser?.uid) {
      setLoading(false);
      return;
    }

    let isMounted = true;
    async function loadUserContent() {
      setLoading(true);
      try {
        const [qList, aList] = await Promise.all([
          getQuestionsByUser(currentUser.uid),
          getAnswersByUser(currentUser.uid),
        ]);
        if (isMounted) {
          setMyQuestions(qList);
          setMyAnswers(aList);
        }
      } catch (err) {
        console.error('Error loading my activity:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadUserContent();
    return () => {
      isMounted = false;
    };
  }, [currentUser?.uid]);

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto shadow-2xs">
          <Lock className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Sign in to view your activity</h2>
        <p className="text-xs text-slate-500 max-w-md mx-auto">
          Keep track of questions you have asked anonymously and answers you have provided to other students.
        </p>
        <button
          onClick={() => openAuthModal('login')}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
        >
          Sign In
        </button>
      </div>
    );
  }

  const totalUpvotesOnQuestions = myQuestions.reduce((acc, q) => acc + (q.upvotes || 0), 0);
  const totalUpvotesOnAnswers = myAnswers.reduce((acc, a) => acc + (a.upvotes || 0), 0);
  const acceptedAnswersCount = myAnswers.filter(a => a.isAccepted).length;

  const handleDeleteQuestion = async (qId: string) => {
    if (!confirm('Are you sure you want to delete this doubt?')) return;
    try {
      await deleteQuestion(qId);
      setMyQuestions(prev => prev.filter(q => q.questionId !== qId));
    } catch {
      alert('Could not delete question');
    }
  };

  const handleDeleteAnswer = async (aId: string, qId: string) => {
    if (!confirm('Are you sure you want to delete this answer?')) return;
    try {
      await deleteAnswer(aId, qId);
      setMyAnswers(prev => prev.filter(a => a.answerId !== aId));
    } catch {
      alert('Could not delete answer');
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Profile Header & Anonymity Guarantee */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white font-black text-xl flex items-center justify-center shadow-md">
              {currentUser.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-slate-900">{currentUser.name}</h1>
                {currentUser.isVerifiedMentor && currentUser.role === 'mentor' && (
                  <MentorBadge specialization={currentUser.subjectSpecialization} size="sm" />
                )}
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{currentUser.email}</p>
              <span className="inline-block mt-1 text-[11px] font-medium bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-md capitalize">
                Role: {currentUser.role}
              </span>
            </div>
          </div>

          <button
            onClick={onOpenAskModal}
            className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-4 py-2 rounded-xl shadow-xs transition-colors cursor-pointer self-start sm:self-center"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Ask New Doubt</span>
          </button>
        </div>

        {/* Anonymity Shield Banner */}
        <div className="p-4 bg-indigo-50/70 border border-indigo-200/80 rounded-2xl flex items-start gap-3 text-xs text-indigo-950">
          <Shield className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-bold text-indigo-900">Your Identity is Protected</h4>
            <p className="text-slate-600 leading-relaxed">
              This dashboard is private to you. In the public feeds and question pages, your identity is masked. Other college students and professors see your posts authored by <strong>&ldquo;Anonymous Student&rdquo;</strong>.
            </p>
          </div>
        </div>

        {/* Stats Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-2xl">
            <span className="text-xl font-extrabold text-slate-900 block">{myQuestions.length}</span>
            <span className="text-xs text-slate-500">Doubts Asked</span>
          </div>
          <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-2xl">
            <span className="text-xl font-extrabold text-slate-900 block">{myAnswers.length}</span>
            <span className="text-xs text-slate-500">Answers Given</span>
          </div>
          <div className="p-3.5 bg-emerald-50 border border-emerald-200/80 rounded-2xl">
            <span className="text-xl font-extrabold text-emerald-700 block">{acceptedAnswersCount}</span>
            <span className="text-xs text-emerald-800">Accepted Solutions</span>
          </div>
          <div className="p-3.5 bg-indigo-50 border border-indigo-200/80 rounded-2xl">
            <span className="text-xl font-extrabold text-indigo-700 block">
              {totalUpvotesOnQuestions + totalUpvotesOnAnswers}
            </span>
            <span className="text-xs text-indigo-800">Total Upvotes</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('questions')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'questions'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>My Doubts ({myQuestions.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('answers')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'answers'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>My Answers ({myAnswers.length})</span>
        </button>
      </div>

      {/* Content Feed */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2].map(n => (
            <div key={n} className="bg-white rounded-2xl p-5 border border-slate-200 animate-pulse h-28" />
          ))}
        </div>
      ) : activeTab === 'questions' ? (
        myQuestions.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-2">
            <HelpCircle className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="text-sm font-bold text-slate-700">No doubts posted yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Whenever you get stuck on a topic, post your doubt anonymously to get help.
            </p>
            <button
              onClick={onOpenAskModal}
              className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold"
            >
              Ask your first doubt
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {myQuestions.map(q => (
              <div
                key={q.questionId}
                className="bg-white rounded-2xl p-5 border border-slate-200/90 hover:border-indigo-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onOpenQuestion(q.questionId)}>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-[11px] font-semibold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">
                      {q.subjectName || q.subjectId}
                    </span>
                    {q.acceptedAnswerId && (
                      <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Solved
                      </span>
                    )}
                    <span className="text-xs text-slate-400">{formatRelativeTime(q.createdAt)}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 hover:text-indigo-600 truncate mb-1">
                    {q.title}
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-3.5 h-3.5" /> {q.answerCount || 0} answers
                    </span>
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-3.5 h-3.5" /> {q.upvotes || 0} upvotes
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onOpenQuestion(q.questionId)}
                    className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <span>View</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeleteQuestion(q.questionId)}
                    className="p-2 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                    title="Delete doubt"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : myAnswers.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-2">
          <MessageSquare className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-700">No answers given yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Browse the questions feed and share your knowledge to earn upvotes and mentor badges!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {myAnswers.map(ans => (
            <div
              key={ans.answerId}
              className="bg-white rounded-2xl p-5 border border-slate-200/90 hover:border-indigo-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onOpenQuestion(ans.questionId)}>
                <div className="flex items-center gap-2 mb-1.5">
                  {ans.isAccepted && (
                    <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Accepted Solution
                    </span>
                  )}
                  <span className="text-xs text-slate-400">Answered {formatRelativeTime(ans.createdAt)}</span>
                </div>
                <p className="text-xs text-slate-700 line-clamp-2 leading-relaxed mb-2 font-sans">
                  {ans.answerText}
                </p>
                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span className="flex items-center gap-1 font-medium text-indigo-600">
                    <ThumbsUp className="w-3.5 h-3.5" /> {ans.upvotes || 0} upvotes
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => onOpenQuestion(ans.questionId)}
                  className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <span>View Doubt</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDeleteAnswer(ans.answerId, ans.questionId)}
                  className="p-2 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                  title="Delete answer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
