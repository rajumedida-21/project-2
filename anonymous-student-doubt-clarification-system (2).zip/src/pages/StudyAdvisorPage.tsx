import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Calendar,
  Clock,
  BookOpen,
  Target,
  Award,
  CheckCircle,
  RefreshCw,
  PlusCircle,
  BookmarkPlus,
  Layers,
  ChevronRight,
  AlertCircle,
  ListTodo,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { StudyPlan, StudyTask } from '../types';
import {
  generateAIStudyPlan,
  StudyPlanInputs,
  StudyPlanResponse,
} from '../services/aiService';
import {
  saveStudyPlan,
  subscribeToUserStudyPlans,
  batchAddStudyTasks,
} from '../services/studyService';
import { useAuth } from '../context/AuthContext';

const DEFAULT_SUBJECTS = [
  'Data Structures & Algorithms',
  'Database Management Systems (DBMS)',
  'Operating Systems',
  'Computer Networks',
  'Engineering Mathematics',
  'Software Engineering',
  'Web Development',
  'Machine Learning',
];

interface StudyAdvisorPageProps {
  onNavigateToPlanner?: () => void;
}

export const StudyAdvisorPage: React.FC<StudyAdvisorPageProps> = ({
  onNavigateToPlanner,
}) => {
  const { currentUser, openAuthModal } = useAuth();

  // Form Inputs
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([
    'Data Structures & Algorithms',
  ]);
  const [customSubjectInput, setCustomSubjectInput] = useState('');
  const [topics, setTopics] = useState('Binary Trees, Graphs, DP, SQL Queries');
  const [examDate, setExamDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });
  const [hoursPerDay, setHoursPerDay] = useState(3);
  const [knowledgeLevel, setKnowledgeLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [strongSubjects, setStrongSubjects] = useState('Arrays, SQL Joins');
  const [weakSubjects, setWeakSubjects] = useState('Dynamic Programming, Tree Traversals');
  const [preferredTime, setPreferredTime] = useState<'Morning' | 'Afternoon' | 'Evening' | 'Night'>('Evening');
  const [dailyGoal, setDailyGoal] = useState('Crack semester exams with top GPA');

  // AI Generation State
  const [generating, setGenerating] = useState(false);
  const [currentResult, setCurrentResult] = useState<StudyPlanResponse | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [addedTasksSuccess, setAddedTasksSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Past Plans History
  const [savedPlans, setSavedPlans] = useState<StudyPlan[]>([]);
  const [viewingSavedPlan, setViewingSavedPlan] = useState<StudyPlan | null>(null);

  useEffect(() => {
    const unsub = subscribeToUserStudyPlans(currentUser?.uid || 'guest_student', plans => {
      setSavedPlans(plans);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  const toggleSubject = (sub: string) => {
    if (selectedSubjects.includes(sub)) {
      if (selectedSubjects.length > 1) {
        setSelectedSubjects(selectedSubjects.filter(s => s !== sub));
      }
    } else {
      setSelectedSubjects([...selectedSubjects, sub]);
    }
  };

  const handleAddCustomSubject = () => {
    if (customSubjectInput.trim() && !selectedSubjects.includes(customSubjectInput.trim())) {
      setSelectedSubjects([...selectedSubjects, customSubjectInput.trim()]);
      setCustomSubjectInput('');
    }
  };

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    setError(null);
    setSavedSuccess(false);
    setAddedTasksSuccess(false);
    setViewingSavedPlan(null);

    const inputs: StudyPlanInputs = {
      subjects: selectedSubjects,
      topics,
      examDate,
      hoursPerDay,
      knowledgeLevel,
      strongSubjects,
      weakSubjects,
      preferredTime,
      dailyGoal,
    };

    try {
      const res = await generateAIStudyPlan(inputs);
      setCurrentResult(res);

      // Auto-save plan if user is logged in
      const userId = currentUser?.uid || 'guest_student';
      const planId = 'plan_' + Date.now();
      const newPlan: StudyPlan = {
        planId,
        userId,
        subjects: selectedSubjects,
        topics,
        examDate,
        hoursPerDay,
        knowledgeLevel,
        strongSubjects,
        weakSubjects,
        preferredTime,
        dailyGoal,
        planContent: res.planText,
        createdAt: new Date().toISOString(),
        status: 'active',
      };
      await saveStudyPlan(newPlan);
      setSavedSuccess(true);
    } catch (err: any) {
      setError(err?.message || 'Could not generate study plan. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  const handlePushTasksToPlanner = async () => {
    if (!currentResult?.suggestedTasks?.length) return;
    const userId = currentUser?.uid || 'guest_student';

    const tasksToAdd: StudyTask[] = currentResult.suggestedTasks.map((t, idx) => {
      const targetDate = new Date();
      targetDate.setDate(targetDate.getDate() + (t.dayOffset || idx));
      return {
        taskId: 'task_' + Date.now() + '_' + idx,
        userId,
        subject: t.subject || selectedSubjects[0] || 'Academic',
        topic: t.topic || 'Review',
        title: t.title,
        date: targetDate.toISOString().split('T')[0],
        durationMinutes: t.durationMinutes || 60,
        priority: t.priority || 'Medium',
        completed: false,
        createdAt: new Date().toISOString(),
      };
    });

    await batchAddStudyTasks(tasksToAdd);
    setAddedTasksSuccess(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden border border-slate-800 shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs px-3 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI Strategic Exam & Semester Advisor</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            Personalized Academic Study Advisor
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Generate an achievable, day-by-day study roadmap tailored to your specific strengths, weak areas, and target exam deadlines.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Student Profile Inputs */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-2xs space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Target className="w-4 h-4 text-indigo-600" />
            <h2 className="text-sm font-bold text-slate-900">Your Learning Parameters</h2>
          </div>

          <form onSubmit={handleGeneratePlan} className="space-y-4">
            {/* Target Subjects Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Target Subjects:
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {DEFAULT_SUBJECTS.map(sub => {
                  const isSelected = selectedSubjects.includes(sub);
                  return (
                    <button
                      key={sub}
                      type="button"
                      onClick={() => toggleSubject(sub)}
                      className={`text-[11px] font-medium px-2.5 py-1 rounded-lg border transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {sub}
                    </button>
                  );
                })}
              </div>

              {/* Add custom subject */}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Or type custom subject..."
                  value={customSubjectInput}
                  onChange={e => setCustomSubjectInput(e.target.value)}
                  className="flex-1 text-xs px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button
                  type="button"
                  onClick={handleAddCustomSubject}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Specific Topics */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Specific High-Yield Topics:
              </label>
              <textarea
                rows={2}
                value={topics}
                onChange={e => setTopics(e.target.value)}
                placeholder="e.g., Recursion, Linked Lists, Normalization, Process Synchronization"
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Exam Date & Daily Hours */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  Target Exam Date:
                </label>
                <input
                  type="date"
                  value={examDate}
                  onChange={e => setExamDate(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  Available Study Hours/Day:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min={1}
                    max={10}
                    step={1}
                    value={hoursPerDay}
                    onChange={e => setHoursPerDay(Number(e.target.value))}
                    className="flex-1 accent-indigo-600"
                  />
                  <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-1 rounded-lg border border-indigo-200">
                    {hoursPerDay} hrs
                  </span>
                </div>
              </div>
            </div>

            {/* Current Level & Preferred Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Current Knowledge Level:
                </label>
                <select
                  value={knowledgeLevel}
                  onChange={e => setKnowledgeLevel(e.target.value as any)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="Beginner">Beginner (Starting fresh)</option>
                  <option value="Intermediate">Intermediate (Know basics)</option>
                  <option value="Advanced">Advanced (Revision & Edge cases)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Peak Study Focus Time:
                </label>
                <select
                  value={preferredTime}
                  onChange={e => setPreferredTime(e.target.value as any)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="Morning">Morning (Fresh mind)</option>
                  <option value="Afternoon">Afternoon</option>
                  <option value="Evening">Evening</option>
                  <option value="Night">Night Owl</option>
                </select>
              </div>
            </div>

            {/* Strong & Weak Areas */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-emerald-700 mb-1">
                  Confident / Strong Areas:
                </label>
                <input
                  type="text"
                  value={strongSubjects}
                  onChange={e => setStrongSubjects(e.target.value)}
                  placeholder="e.g. Arrays, Basic OOP"
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-rose-700 mb-1">
                  Weak Areas (Needs Practice):
                </label>
                <input
                  type="text"
                  value={weakSubjects}
                  onChange={e => setWeakSubjects(e.target.value)}
                  placeholder="e.g. DP, Pointers, Graphs"
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-rose-500"
                />
              </div>
            </div>

            {/* Daily Goal */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Primary Goal / Outcome:
              </label>
              <input
                type="text"
                value={dailyGoal}
                onChange={e => setDailyGoal(e.target.value)}
                placeholder="e.g. Score 90%+ in semester, Clear technical placement round"
                className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <button
              type="submit"
              disabled={generating}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-transform active:scale-98 cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Sparkles className={`w-4 h-4 ${generating ? 'animate-spin' : ''}`} />
              <span>{generating ? 'AI is crafting your study plan...' : 'Generate Personalized Study Plan'}</span>
            </button>
          </form>

          {/* Past Plans List */}
          {savedPlans.length > 0 && (
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <span className="text-xs font-bold text-slate-600 block">
                Your Saved Plans ({savedPlans.length})
              </span>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {savedPlans.map(plan => (
                  <button
                    key={plan.planId}
                    type="button"
                    onClick={() => {
                      setViewingSavedPlan(plan);
                      setCurrentResult(null);
                    }}
                    className="w-full text-left p-2.5 rounded-xl border border-slate-200 hover:border-indigo-300 bg-slate-50 hover:bg-indigo-50/40 text-xs text-slate-700 flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <div className="truncate pr-2">
                      <span className="font-semibold block truncate">
                        {plan.subjects.join(', ')}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Exam: {plan.examDate} • {plan.hoursPerDay} hrs/day
                      </span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Output: The AI Generated Study Plan */}
        <div className="lg:col-span-7 space-y-4">
          {generating ? (
            <div className="bg-white rounded-2xl p-12 border border-slate-200/90 shadow-2xs text-center space-y-4">
              <div className="relative w-12 h-12 mx-auto">
                <div className="w-12 h-12 rounded-full border-3 border-indigo-600/30 border-t-indigo-600 animate-spin" />
                <Sparkles className="w-5 h-5 text-indigo-600 absolute inset-0 m-auto" />
              </div>
              <h3 className="text-base font-bold text-slate-800">
                Crafting Your Custom Academic Study Schedule...
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Balancing theory hours, revision blocks, and active problem solving tailored specifically for {selectedSubjects.slice(0, 2).join(' & ')}.
              </p>
            </div>
          ) : error ? (
            <div className="bg-rose-50 rounded-2xl p-6 border border-rose-200 text-rose-800 text-xs space-y-2">
              <div className="flex items-center gap-2 font-bold text-sm">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                <span>Could not generate plan</span>
              </div>
              <p>{error}</p>
            </div>
          ) : currentResult || viewingSavedPlan ? (
            <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-6">
              {/* Output Action Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      Personalized Day-by-Day Study Plan
                    </h3>
                    <span className="text-[11px] text-slate-400">
                      AI Generated Strategy • {currentResult ? 'Active Draft' : 'Saved Plan'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {currentResult?.suggestedTasks && currentResult.suggestedTasks.length > 0 && (
                    <button
                      type="button"
                      onClick={handlePushTasksToPlanner}
                      disabled={addedTasksSuccess}
                      className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl border transition-colors cursor-pointer ${
                        addedTasksSuccess
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-indigo-200'
                      }`}
                    >
                      {addedTasksSuccess ? (
                        <>
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Added to Study Planner</span>
                        </>
                      ) : (
                        <>
                          <ListTodo className="w-3.5 h-3.5" />
                          <span>Add Tasks to Planner</span>
                        </>
                      )}
                    </button>
                  )}

                  {onNavigateToPlanner && (
                    <button
                      type="button"
                      onClick={onNavigateToPlanner}
                      className="text-xs text-indigo-600 hover:underline font-semibold"
                    >
                      Open Planner →
                    </button>
                  )}
                </div>
              </div>

              {/* Study Plan Content (Markdown) */}
              <div className="prose prose-sm max-w-none text-slate-800 leading-relaxed space-y-3">
                <div className="markdown-body">
                  <ReactMarkdown>
                    {currentResult?.planText || viewingSavedPlan?.planContent || ''}
                  </ReactMarkdown>
                </div>
              </div>

              {/* Tasks to populate preview if generated */}
              {currentResult?.suggestedTasks && currentResult.suggestedTasks.length > 0 && (
                <div className="pt-6 border-t border-slate-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <ListTodo className="w-3.5 h-3.5 text-indigo-600" />
                      Suggested Actionable Tasks for your Planner:
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {currentResult.suggestedTasks.length} milestones
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {currentResult.suggestedTasks.map((t, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-800">{t.title}</span>
                          <span
                            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                              t.priority === 'High'
                                ? 'bg-rose-100 text-rose-700'
                                : t.priority === 'Medium'
                                ? 'bg-amber-100 text-amber-700'
                                : 'bg-slate-200 text-slate-700'
                            }`}
                          >
                            {t.priority}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2">
                          <span>{t.subject}</span>
                          <span>•</span>
                          <span>{t.durationMinutes} min</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 border border-slate-200/90 shadow-2xs text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">
                Ready to create your personalized study plan
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Fill out your target subjects, hours, and knowledge level on the left and click &quot;Generate Personalized Study Plan&quot;.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
