import React, { useEffect, useState } from 'react';
import {
  HelpCircle,
  TrendingUp,
  Clock,
  CheckCircle,
  Sparkles,
  Award,
  Shield,
  Search,
  BookOpen,
  Filter,
  PlusCircle,
  MessageSquare,
  Brain,
  Calendar,
  Compass,
} from 'lucide-react';
import { Question, Subject, QuestionFilter, UserProfile } from '../types';
import { getQuestions, subscribeToQuestions } from '../services/questionService';
import { getVerifiedMentors } from '../services/userService';
import { QuestionCard } from '../components/QuestionCard';
import { SubjectPills } from '../components/SubjectPills';
import { MentorBadge } from '../components/MentorBadge';
import { useAuth } from '../context/AuthContext';
import { getUserVotedQuestionIds } from '../services/voteService';

interface HomePageProps {
  subjects: Subject[];
  selectedSubjectId: string;
  onSelectSubject: (id: string) => void;
  searchQuery: string;
  onOpenQuestion: (questionId: string) => void;
  onOpenAskModal: () => void;
  onOpenReport: (question: Question) => void;
  onNavigate: (page: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  subjects,
  selectedSubjectId,
  onSelectSubject,
  searchQuery,
  onOpenQuestion,
  onOpenAskModal,
  onOpenReport,
  onNavigate,
}) => {
  const { currentUser } = useAuth();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [votedQuestionIds, setVotedQuestionIds] = useState<Set<string>>(new Set());
  const [activeFilter, setActiveFilter] = useState<QuestionFilter>('recent');
  const [loading, setLoading] = useState(true);
  const [mentors, setMentors] = useState<UserProfile[]>([]);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    const unsubscribe = subscribeToQuestions(
      {
        subjectId: selectedSubjectId,
        filter: activeFilter,
        searchQuery,
      },
      qList => {
        if (isMounted) {
          setQuestions(qList);
          setLoading(false);
        }
      },
      () => {
        if (isMounted) setLoading(false);
      }
    );

    getVerifiedMentors()
      .then(mentorList => {
        if (isMounted) setMentors(mentorList.slice(0, 4));
      })
      .catch(() => {});

    if (currentUser?.uid) {
      getUserVotedQuestionIds(currentUser.uid)
        .then(votes => {
          if (isMounted) setVotedQuestionIds(votes);
        })
        .catch(() => {});
    }

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [selectedSubjectId, activeFilter, searchQuery, currentUser?.uid]);

  const totalDoubts = questions.length;
  const resolvedCount = questions.filter(q => q.acceptedAnswerId || q.status === 'resolved').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Hero Welcome Banner */}
      <section className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden border border-slate-800 shadow-xl">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs px-3 py-1 rounded-full mb-3">
            <Shield className="w-3.5 h-3.5 text-indigo-400" />
            <span>100% Anonymous Doubts & Verified Mentor Answers</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight">
            Never hesitate to ask an academic doubt.
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm mt-2 leading-relaxed">
            Your identity is shielded as <strong>&ldquo;Anonymous Student&rdquo;</strong>. Ask complex questions on Data Structures, DBMS, Operating Systems, Machine Learning and more, without judgment.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-5">
            <button
              id="hero-ask-doubt-btn"
              onClick={onOpenAskModal}
              className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-md transition-transform hover:scale-102 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Ask a Doubt Anonymously</span>
            </button>
            <button
              id="hero-browse-mentors-btn"
              onClick={() => onNavigate('mentors')}
              className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs sm:text-sm px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
            >
              <Award className="w-4 h-4 text-emerald-400" />
              <span>Meet Verified Mentors</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Counters */}
        <div className="mt-8 pt-6 border-t border-slate-800/80 grid grid-cols-3 gap-4 max-w-lg">
          <div>
            <span className="text-xl sm:text-2xl font-extrabold text-white block">
              {totalDoubts}
            </span>
            <span className="text-[11px] text-slate-400">Questions Asked</span>
          </div>
          <div>
            <span className="text-xl sm:text-2xl font-extrabold text-emerald-400 block">
              {resolvedCount}
            </span>
            <span className="text-[11px] text-slate-400">Doubts Solved</span>
          </div>
          <div>
            <span className="text-xl sm:text-2xl font-extrabold text-indigo-400 block">
              {mentors.length > 0 ? `${mentors.length}+` : 'Active'}
            </span>
            <span className="text-[11px] text-slate-400">Verified Mentors</span>
          </div>
        </div>
      </section>

      {/* AI Learning Tools Spotlight Launcher */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={() => onNavigate('tutor')}
          className="p-4 bg-white hover:bg-indigo-50/50 rounded-2xl border border-slate-200 hover:border-indigo-300 text-left transition-all cursor-pointer shadow-2xs group"
        >
          <div className="w-8 h-8 rounded-xl bg-indigo-50 group-hover:bg-indigo-600 text-indigo-600 group-hover:text-white flex items-center justify-center transition-colors mb-2">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-900 block group-hover:text-indigo-600">
            AI Academic Tutor
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Step-by-step doubt teaching
          </span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('advisor')}
          className="p-4 bg-white hover:bg-indigo-50/50 rounded-2xl border border-slate-200 hover:border-indigo-300 text-left transition-all cursor-pointer shadow-2xs group"
        >
          <div className="w-8 h-8 rounded-xl bg-purple-50 group-hover:bg-purple-600 text-purple-600 group-hover:text-white flex items-center justify-center transition-colors mb-2">
            <Compass className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-900 block group-hover:text-purple-600">
            Study Advisor
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Day-by-day exam roadmaps
          </span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('quiz')}
          className="p-4 bg-white hover:bg-indigo-50/50 rounded-2xl border border-slate-200 hover:border-indigo-300 text-left transition-all cursor-pointer shadow-2xs group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-50 group-hover:bg-emerald-600 text-emerald-600 group-hover:text-white flex items-center justify-center transition-colors mb-2">
            <Brain className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-900 block group-hover:text-emerald-600">
            AI Quiz Generator
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Test mastery & weak topics
          </span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('planner')}
          className="p-4 bg-white hover:bg-indigo-50/50 rounded-2xl border border-slate-200 hover:border-indigo-300 text-left transition-all cursor-pointer shadow-2xs group"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-50 group-hover:bg-amber-600 text-amber-600 group-hover:text-white flex items-center justify-center transition-colors mb-2">
            <Calendar className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-900 block group-hover:text-amber-600">
            Study Planner
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Schedule tasks & streaks
          </span>
        </button>
      </div>

      {/* Main Grid: Feed + Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left 3 Columns: Subject Bar, Filter Tabs, and Questions Feed */}
        <div className="lg:col-span-3 space-y-4">
          {/* Subject Bar */}
          <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                Select Academic Topic:
              </span>
              {selectedSubjectId !== 'all' && (
                <button
                  onClick={() => onSelectSubject('all')}
                  className="text-[11px] text-indigo-600 hover:text-indigo-700 font-semibold"
                >
                  Clear filter
                </button>
              )}
            </div>
            <SubjectPills
              subjects={subjects}
              selectedSubjectId={selectedSubjectId}
              onSelectSubject={onSelectSubject}
            />
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200/80 shadow-2xs">
            <div className="flex items-center gap-1.5">
              <button
                id="filter-tab-recent"
                onClick={() => setActiveFilter('recent')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeFilter === 'recent'
                    ? 'bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Recent Questions</span>
              </button>

              <button
                id="filter-tab-popular"
                onClick={() => setActiveFilter('popular')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeFilter === 'popular'
                    ? 'bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Popular</span>
              </button>

              <button
                id="filter-tab-unanswered"
                onClick={() => setActiveFilter('unanswered')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeFilter === 'unanswered'
                    ? 'bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Unanswered</span>
              </button>
            </div>

            <span className="text-xs text-slate-400 px-2 font-medium">
              Showing {questions.length} doubts
            </span>
          </div>

          {/* Questions Feed */}
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4].map(n => (
                <div key={n} className="bg-white rounded-2xl p-5 border border-slate-200 animate-pulse space-y-3">
                  <div className="flex justify-between items-center">
                    <div className="h-4 bg-slate-200 rounded w-1/4" />
                    <div className="h-4 bg-slate-200 rounded w-16" />
                  </div>
                  <div className="h-5 bg-slate-200 rounded w-3/4" />
                  <div className="h-4 bg-slate-100 rounded w-full" />
                </div>
              ))}
            </div>
          ) : questions.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
                <HelpCircle className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-800">No questions found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {searchQuery
                  ? `No doubts matched "${searchQuery}". Try different keywords or select a different topic.`
                  : 'Be the first student to ask a doubt in this subject!'}
              </p>
              <button
                onClick={onOpenAskModal}
                className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-4 py-2 rounded-xl shadow-xs cursor-pointer mt-2"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Ask Doubt Now</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {questions.map(q => (
                <QuestionCard
                  key={q.questionId}
                  question={q}
                  hasUpvoted={votedQuestionIds.has(q.questionId)}
                  onOpenQuestion={onOpenQuestion}
                  onOpenReport={onOpenReport}
                />
              ))}
            </div>
          )}
        </div>

        {/* Right Sidebar: Verified Mentors & Guidelines */}
        <div className="space-y-4">
          {/* Verified Mentors Spotlight */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-2xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <div className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-emerald-600" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Verified Mentors
                </h3>
              </div>
              <button
                onClick={() => onNavigate('mentors')}
                className="text-[11px] text-indigo-600 hover:underline font-semibold"
              >
                View all
              </button>
            </div>

            {mentors.length > 0 ? (
              <div className="space-y-3">
                {mentors.map(m => (
                  <div key={m.uid} className="flex items-start gap-2.5 p-2 rounded-xl hover:bg-slate-50 transition-colors">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs shrink-0">
                      {m.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 truncate">{m.name}</h4>
                      <MentorBadge specialization={m.subjectSpecialization} size="sm" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 py-2">
                Teachers and verified mentors help resolve doubts with detailed step-by-step explanations.
              </p>
            )}

            <div className="mt-3 pt-3 border-t border-slate-100 text-center">
              <span className="text-[11px] text-slate-500 block">
                Are you a Teacher or Teaching Assistant?
              </span>
              <button
                onClick={() => onNavigate('mentors')}
                className="text-xs text-indigo-600 font-semibold hover:underline mt-0.5 inline-block"
              >
                Learn how to become a mentor →
              </button>
            </div>
          </div>

          {/* Anonymity & Honor Code */}
          <div className="bg-indigo-50/50 rounded-2xl p-4 border border-indigo-100 text-indigo-950">
            <div className="flex items-center gap-2 mb-2 text-indigo-900 font-bold text-xs">
              <Shield className="w-4 h-4 text-indigo-600" />
              <span>Student Privacy Guarantee</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              When asking a question or responding as a student, your email and private profile are completely hidden. Only &ldquo;Anonymous Student&rdquo; is shown to peers.
            </p>
          </div>

          {/* Need help banner */}
          <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400 mb-1">
              Academic Support
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Stuck on a tricky algorithm, database query, or proof? Don&apos;t wait until the midterm!
            </p>
            <button
              onClick={onOpenAskModal}
              className="w-full mt-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              Ask Doubt Anonymously
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
