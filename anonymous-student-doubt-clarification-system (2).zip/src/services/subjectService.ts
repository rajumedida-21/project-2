import {
  collection,
  doc,
  getDocs,
  setDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { Subject } from '../types';
import { handleFirestoreError, OperationType } from './firestoreError';

export const DEFAULT_SUBJECTS: Subject[] = [
  { subjectId: 'data-structures', name: 'Data Structures', description: 'Arrays, Trees, Graphs, Hash Tables, Stacks & Queues' },
  { subjectId: 'java', name: 'Java', description: 'OOP concepts, JVM, Collections framework, Multi-threading' },
  { subjectId: 'python', name: 'Python', description: 'Core syntax, OOP, Scripting, NumPy & Pandas' },
  { subjectId: 'c-programming', name: 'C Programming', description: 'Pointers, Memory allocation, Structs, Low-level concepts' },
  { subjectId: 'dbms', name: 'DBMS', description: 'SQL queries, Normalization, ACID properties, Indexing & Transactions' },
  { subjectId: 'operating-systems', name: 'Operating Systems', description: 'Process scheduling, Threads, Deadlocks, Virtual memory' },
  { subjectId: 'computer-networks', name: 'Computer Networks', description: 'OSI Model, TCP/IP, Routing protocols, Socket programming' },
  { subjectId: 'artificial-intelligence', name: 'Artificial Intelligence', description: 'Search algorithms, Knowledge representation, Heuristics' },
  { subjectId: 'machine-learning', name: 'Machine Learning', description: 'Supervised/Unsupervised models, Neural networks, Deep learning' },
  { subjectId: 'web-development', name: 'Web Development', description: 'HTML/CSS, JavaScript, React, Node.js, REST APIs' },
  { subjectId: 'mathematics', name: 'Mathematics', description: 'Discrete math, Linear algebra, Calculus, Probability & Stats' },
  { subjectId: 'other', name: 'Other Academic Subjects', description: 'General college engineering, electronics, sciences and doubts' },
];

export async function getSubjects(): Promise<Subject[]> {
  if (!isFirebaseConfigured || !db) {
    return DEFAULT_SUBJECTS;
  }

  const path = 'subjects';
  try {
    const snap = await getDocs(collection(db, path));
    if (snap.empty) {
      // Return defaults while giving option to seed
      return DEFAULT_SUBJECTS;
    }
    return snap.docs.map(d => d.data() as Subject);
  } catch {
    return DEFAULT_SUBJECTS;
  }
}

export async function seedDefaultSubjects(): Promise<void> {
  if (!db) return;
  for (const sub of DEFAULT_SUBJECTS) {
    try {
      await setDoc(doc(db, 'subjects', sub.subjectId), sub, { merge: true });
    } catch (e) {
      console.warn(`Could not seed subject ${sub.subjectId}:`, e);
    }
  }
}

export async function addSubject(subject: Omit<Subject, 'subjectId'>): Promise<Subject> {
  if (!db) throw new Error('Database is not initialized');

  const subjectId = subject.name.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
  const fullSubject: Subject = {
    ...subject,
    subjectId,
    questionCount: 0,
  };

  const path = `subjects/${subjectId}`;
  try {
    await setDoc(doc(db, 'subjects', subjectId), fullSubject);
    return fullSubject;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}
