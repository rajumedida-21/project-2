import { AdaptiveRecommendation, AILearningGoal, StudySession } from '../types';
import { getDueFlashcards, getAllFlashcards } from './revisionService';

const GOALS_KEY = 'anondoubt_ai_goals_v1';
const SESSIONS_KEY = 'anondoubt_study_sessions_v1';

export const INITIAL_GOALS: AILearningGoal[] = [
  {
    id: 'goal_1',
    userId: 'local_student',
    title: 'Master Graph Algorithms & Dynamic Programming',
    subject: 'Algorithms & Data Structures',
    targetDate: '2026-09-30',
    progressPercentage: 40,
    tasks: [
      { id: 'g1_t1', title: 'Review BFS and DFS graph traversals', completed: true, estimatedMinutes: 25 },
      { id: 'g1_t2', title: 'Implement Dijkstra shortest path with priority queue', completed: true, estimatedMinutes: 35 },
      { id: 'g1_t3', title: 'Solve 0/1 Knapsack problem with memoization table', completed: false, estimatedMinutes: 40 },
      { id: 'g1_t4', title: 'Practice Longest Common Subsequence (LCS)', completed: false, estimatedMinutes: 30 },
      { id: 'g1_t5', title: 'Take comprehensive Graph & DP mastery quiz', completed: false, estimatedMinutes: 20 },
    ],
    suggestedNextStep: 'Work on solving the 0/1 Knapsack problem with memoization table.',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
];

export function getAILearningGoals(): AILearningGoal[] {
  try {
    const raw = localStorage.getItem(GOALS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.warn('Error reading AI goals:', e);
  }
  return INITIAL_GOALS;
}

export function saveAILearningGoals(goals: AILearningGoal[]): void {
  try {
    localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
  } catch (e) {
    console.warn('Error saving AI goals:', e);
  }
}

export function toggleGoalTask(goalId: string, taskId: string): AILearningGoal | null {
  const all = getAILearningGoals();
  const goalIndex = all.findIndex(g => g.id === goalId);
  if (goalIndex === -1) return null;

  const goal = { ...all[goalIndex] };
  goal.tasks = goal.tasks.map(t => (t.id === taskId ? { ...t, completed: !t.completed } : t));
  const completedCount = goal.tasks.filter(t => t.completed).length;
  goal.progressPercentage = Math.round((completedCount / goal.tasks.length) * 100);

  const nextIncomplete = goal.tasks.find(t => !t.completed);
  if (nextIncomplete) {
    goal.suggestedNextStep = `Next recommended task: "${nextIncomplete.title}"`;
  } else {
    goal.suggestedNextStep = '🎉 Goal complete! You have mastered all subtasks.';
  }

  all[goalIndex] = goal;
  saveAILearningGoals(all);
  return goal;
}

export function addAILearningGoal(goal: Omit<AILearningGoal, 'id' | 'createdAt' | 'progressPercentage'>): AILearningGoal {
  const all = getAILearningGoals();
  const completedCount = goal.tasks.filter(t => t.completed).length;
  const newGoal: AILearningGoal = {
    ...goal,
    id: `goal_${Date.now()}`,
    progressPercentage: goal.tasks.length > 0 ? Math.round((completedCount / goal.tasks.length) * 100) : 0,
    createdAt: new Date().toISOString(),
  };
  const updated = [newGoal, ...all];
  saveAILearningGoals(updated);
  return newGoal;
}

export function deleteAILearningGoal(id: string): void {
  const all = getAILearningGoals();
  const updated = all.filter(g => g.id !== id);
  saveAILearningGoals(updated);
}

// ----------------------------------------------------
// Study Sessions & Focus Logger
// ----------------------------------------------------
export function getStudySessions(): StudySession[] {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error reading study sessions:', e);
  }
  return [
    {
      id: 'sess_1',
      userId: 'local_student',
      subject: 'Algorithms',
      topic: 'Recursion Trees & Master Theorem',
      goal: 'Understand master theorem cases with step-by-step examples',
      durationMinutes: 30,
      completedAt: new Date(Date.now() - 86400000).toISOString(),
      reflection: 'Clear on Case 1 and 2, need more practice with irregular f(n) polynomials.',
      focusRating: 5,
    },
    {
      id: 'sess_2',
      userId: 'local_student',
      subject: 'Database Systems',
      topic: 'B-Trees and Indexing',
      goal: 'Compare clustered vs non-clustered index lookup costs',
      durationMinutes: 45,
      completedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      reflection: 'Understood why secondary indexes point to clustered keys in InnoDB.',
      focusRating: 4,
    }
  ];
}

export function logCompletedStudySession(session: Omit<StudySession, 'id' | 'completedAt'>): StudySession {
  const all = getStudySessions();
  const newSession: StudySession = {
    ...session,
    id: `sess_${Date.now()}`,
    completedAt: new Date().toISOString(),
  };
  const updated = [newSession, ...all];
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn('Error logging study session:', e);
  }
  return newSession;
}

// ----------------------------------------------------
// Adaptive Recommendation Engine
// ----------------------------------------------------
export function generateSmartRecommendations(options?: {
  quizAccuracy?: number;
  weakTopics?: string[];
  recentDoubtTopic?: string;
}): AdaptiveRecommendation[] {
  const dueCards = getDueFlashcards();
  const allCards = getAllFlashcards();
  const difficultCards = allCards.filter(c => c.status === 'difficult');
  const goals = getAILearningGoals();

  const recommendations: AdaptiveRecommendation[] = [];

  // 1. Spaced Repetition Due Flashcards Recommendation
  if (dueCards.length > 0) {
    recommendations.push({
      id: 'rec_flashcards_due',
      title: `Review ${dueCards.length} Spaced Repetition Flashcards`,
      reason: `Based on your spaced repetition memory curve: ${dueCards.length} flashcard(s) are due today to prevent memory decay.`,
      isPersonalized: true,
      category: 'flashcards',
      actionLabel: 'Start Flashcard Review',
      targetPage: 'flashcards',
      estimatedMinutes: Math.max(5, dueCards.length * 2),
      priority: 'high',
      difficulty: 'Medium',
    });
  }

  // 2. Weak Topic / Mistake in Flashcards
  if (difficultCards.length > 0) {
    const card = difficultCards[0];
    recommendations.push({
      id: `rec_difficult_${card.id}`,
      title: `Strengthen Concept: ${card.category || 'Core Theory'}`,
      reason: `Based on your recent reviews: You marked "${card.front.slice(0, 45)}..." as challenging.`,
      isPersonalized: true,
      category: 'weak_topic',
      actionLabel: 'Ask AI Tutor to Explain',
      targetPage: 'tutor',
      targetParams: { initialPrompt: `Can you explain this concept in simpler terms with an analogy and practice question: "${card.front}"` },
      estimatedMinutes: 10,
      priority: 'high',
      difficulty: 'Hard',
    });
  }

  // 3. Goal Next Step Recommendation
  const activeGoal = goals.find(g => g.progressPercentage < 100);
  if (activeGoal) {
    const nextTask = activeGoal.tasks.find(t => !t.completed);
    if (nextTask) {
      recommendations.push({
        id: `rec_goal_${activeGoal.id}`,
        title: `Goal Progress: ${nextTask.title}`,
        reason: `Based on your active learning goal "${activeGoal.title}" (${activeGoal.progressPercentage}% complete).`,
        isPersonalized: true,
        category: 'study',
        actionLabel: 'Open Focus Session',
        targetPage: 'focus',
        targetParams: { topic: nextTask.title, subject: activeGoal.subject, minutes: nextTask.estimatedMinutes },
        estimatedMinutes: nextTask.estimatedMinutes,
        priority: 'medium',
        difficulty: 'Medium',
      });
    }
  }

  // 4. Interactive Quiz Assessment
  recommendations.push({
    id: 'rec_quiz_assessment',
    title: 'Test Yourself on Core Data Structures & DBMS',
    reason: 'General Recommendation: Regular quick self-quizzes improve retention and exam readiness by 40%.',
    isPersonalized: false,
    category: 'quiz',
    actionLabel: 'Take 5-Min Quiz',
    targetPage: 'quiz',
    estimatedMinutes: 10,
    priority: 'low',
    difficulty: 'Medium',
  });

  return recommendations;
}
