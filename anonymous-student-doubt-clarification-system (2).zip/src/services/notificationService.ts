import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  getDocs,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { NotificationItem } from '../types';
import { handleFirestoreError, OperationType } from './firestoreError';

export interface CreateNotificationInput {
  recipientId: string;
  type: NotificationItem['type'];
  title: string;
  message: string;
  linkQuestionId?: string;
}

export async function createNotification(input: CreateNotificationInput): Promise<void> {
  if (!isFirebaseConfigured || !db || !input.recipientId) return;

  const notificationId = 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  const data: NotificationItem = {
    notificationId,
    recipientId: input.recipientId,
    type: input.type,
    title: input.title,
    message: input.message,
    linkQuestionId: input.linkQuestionId || '',
    isRead: false,
    createdAt: now,
  };

  const path = `notifications/${notificationId}`;
  try {
    await setDoc(doc(db, 'notifications', notificationId), data);
  } catch (error) {
    // Notifications should not crash the main thread
    console.warn('Notification save error:', error);
  }
}

export function subscribeToUserNotifications(
  userId: string,
  onData: (notifications: NotificationItem[]) => void,
  onError?: (err: unknown) => void
) {
  if (!isFirebaseConfigured || !db || !userId) {
    onData([]);
    return () => {};
  }

  const path = 'notifications';
  const q = query(
    collection(db, path),
    where('recipientId', '==', userId)
  );

  return onSnapshot(
    q,
    snapshot => {
      const items = snapshot.docs.map(d => d.data() as NotificationItem);
      // Sort newest first
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onData(items);
    },
    error => {
      console.warn('Notifications snapshot error:', error);
      if (onError) onError(error);
    }
  );
}

export async function markNotificationAsRead(notificationId: string): Promise<void> {
  if (!db) return;
  const path = `notifications/${notificationId}`;
  try {
    await updateDoc(doc(db, 'notifications', notificationId), {
      isRead: true,
    });
  } catch (error) {
    console.warn('Mark notification as read failed:', error);
  }
}

export async function markAllNotificationsAsRead(userId: string): Promise<void> {
  if (!db || !userId) return;
  try {
    const q = query(
      collection(db, 'notifications'),
      where('recipientId', '==', userId),
      where('isRead', '==', false)
    );
    const snap = await getDocs(q);
    const updates = snap.docs.map(d => updateDoc(d.ref, { isRead: true }));
    await Promise.all(updates);
  } catch (e) {
    console.warn('Mark all notifications error:', e);
  }
}

export async function deleteNotification(notificationId: string): Promise<void> {
  if (!db) return;
  try {
    await deleteDoc(doc(db, 'notifications', notificationId));
  } catch (e) {
    console.warn('Delete notification error:', e);
  }
}
