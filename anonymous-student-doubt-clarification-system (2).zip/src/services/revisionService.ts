import { SmartFlashcardItem, FlashcardMasteryStatus } from '../types';

const FLASHCARDS_KEY = 'anondoubt_smart_flashcards_v1';

export const INITIAL_FLASHCARDS: SmartFlashcardItem[] = [
  {
    id: 'fc_1',
    front: 'What is the Master Theorem in Algorithm Analysis?',
    back: 'The Master Theorem provides a cookbook solution in asymptotic terms (using Big O) for recurrence relations of the form T(n) = a*T(n/b) + f(n), where a >= 1 and b > 1.',
    category: 'Algorithms & Data Structures',
    status: 'new',
    mistakeCount: 0,
    timesReviewed: 0,
    nextReviewDue: new Date().toISOString(),
  },
  {
    id: 'fc_2',
    front: 'What are the 4 ACID properties in Database Management Systems?',
    back: 'Atomicity (all or nothing), Consistency (preserves database integrity), Isolation (concurrent transactions execute independently), and Durability (committed changes persist).',
    category: 'Database Systems (DBMS)',
    status: 'learning',
    mistakeCount: 1,
    timesReviewed: 2,
    nextReviewDue: new Date(Date.now() - 3600000 * 2).toISOString(), // Due now
  },
  {
    id: 'fc_3',
    front: 'What is the difference between TCP and UDP?',
    back: 'TCP is connection-oriented, reliable, orders packets, and provides error checking (ideal for HTTP/email). UDP is connectionless, fast, lightweight, and does not guarantee delivery (ideal for video streaming/DNS).',
    category: 'Computer Networks',
    status: 'difficult',
    mistakeCount: 3,
    timesReviewed: 4,
    nextReviewDue: new Date(Date.now() - 3600000 * 5).toISOString(), // Due now
  },
  {
    id: 'fc_4',
    front: 'Explain tail call optimization (TCO) in recursion.',
    back: 'TCO is a compiler optimization where a recursive call in the tail position (the very last operation in the function) replaces the current stack frame instead of adding a new one, preventing stack overflow (O(1) stack space).',
    category: 'Programming Languages',
    status: 'new',
    mistakeCount: 0,
    timesReviewed: 0,
    nextReviewDue: new Date().toISOString(),
  },
  {
    id: 'fc_5',
    front: 'What is Dijkstra’s Shortest Path Algorithm and its limitation?',
    back: 'Dijkstra finds the single-source shortest path in a weighted graph with non-negative edge weights using a priority queue (O((V+E) log V)). Limitation: It fails on graphs with negative edge weights (Bellman-Ford is needed instead).',
    category: 'Algorithms & Data Structures',
    status: 'mastered',
    mistakeCount: 0,
    timesReviewed: 5,
    lastReviewedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    nextReviewDue: new Date(Date.now() + 86400000 * 7).toISOString(),
  }
];

export function getAllFlashcards(): SmartFlashcardItem[] {
  try {
    const raw = localStorage.getItem(FLASHCARDS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.warn('Could not read flashcards from localStorage:', e);
  }
  return INITIAL_FLASHCARDS;
}

export function saveAllFlashcards(cards: SmartFlashcardItem[]): void {
  try {
    localStorage.setItem(FLASHCARDS_KEY, JSON.stringify(cards));
  } catch (e) {
    console.warn('Could not save flashcards to localStorage:', e);
  }
}

export function addFlashcard(card: Omit<SmartFlashcardItem, 'id' | 'mistakeCount' | 'timesReviewed' | 'nextReviewDue'>): SmartFlashcardItem {
  const all = getAllFlashcards();
  const newCard: SmartFlashcardItem = {
    ...card,
    id: `fc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    mistakeCount: 0,
    timesReviewed: 0,
    nextReviewDue: new Date().toISOString(),
  };
  const updated = [newCard, ...all];
  saveAllFlashcards(updated);
  return newCard;
}

export function deleteFlashcard(id: string): void {
  const all = getAllFlashcards();
  const updated = all.filter(c => c.id !== id);
  saveAllFlashcards(updated);
}

export type ReviewGrade = 'again' | 'hard' | 'good' | 'easy';

export function recordCardReview(id: string, grade: ReviewGrade): SmartFlashcardItem | null {
  const all = getAllFlashcards();
  const index = all.findIndex(c => c.id === id);
  if (index === -1) return null;

  const card = { ...all[index] };
  const now = Date.now();
  card.timesReviewed += 1;
  card.lastReviewedAt = new Date().toISOString();

  let nextIntervalHours = 24;

  switch (grade) {
    case 'again':
      card.status = 'difficult';
      card.mistakeCount += 1;
      nextIntervalHours = 4; // review again in 4 hours
      break;
    case 'hard':
      card.status = card.status === 'mastered' ? 'learning' : 'difficult';
      card.mistakeCount += 1;
      nextIntervalHours = 12; // review in 12 hours
      break;
    case 'good':
      card.status = 'learning';
      nextIntervalHours = card.timesReviewed >= 3 ? 72 : 24; // 1-3 days
      break;
    case 'easy':
      card.status = 'mastered';
      nextIntervalHours = card.timesReviewed >= 2 ? 168 : 72; // 3-7 days
      break;
  }

  card.nextReviewDue = new Date(now + nextIntervalHours * 3600000).toISOString();
  all[index] = card;
  saveAllFlashcards(all);
  return card;
}

export function getDueFlashcards(): SmartFlashcardItem[] {
  const all = getAllFlashcards();
  const now = new Date().toISOString();
  return all.filter(c => !c.nextReviewDue || c.nextReviewDue <= now);
}

export function getFlashcardStats() {
  const all = getAllFlashcards();
  const due = getDueFlashcards();
  const mastered = all.filter(c => c.status === 'mastered').length;
  const learning = all.filter(c => c.status === 'learning').length;
  const difficult = all.filter(c => c.status === 'difficult').length;
  const newCards = all.filter(c => c.status === 'new').length;

  return {
    total: all.length,
    dueCount: due.length,
    mastered,
    learning,
    difficult,
    newCards,
    masteryPercentage: all.length > 0 ? Math.round((mastered / all.length) * 100) : 0,
  };
}
