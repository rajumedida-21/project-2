import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  increment,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { Question, QuestionFilter } from '../types';
import {
  getLocalQuestions,
  addLocalQuestion,
  saveLocalQuestions,
} from './localFallback';

export interface CreateQuestionInput {
  title: string;
  description: string;
  subjectId: string;
  subjectName?: string;
  imageUrl?: string;
  isAnonymous?: boolean;
  authorId: string;
}

function filterQuestionsLocally(
  list: Question[],
  params?: {
    subjectId?: string;
    filter?: QuestionFilter;
    searchQuery?: string;
  }
): Question[] {
  let questions = [...list];

  if (params?.subjectId && params.subjectId !== 'all') {
    questions = questions.filter(q => q.subjectId === params.subjectId);
  }

  if (params?.filter) {
    if (params.filter === 'popular') {
      questions.sort((a, b) => (b.upvotes || 0) - (a.upvotes || 0));
    } else if (params.filter === 'unanswered') {
      questions = questions.filter(q => (q.answerCount || 0) === 0);
    } else if (params.filter === 'recent') {
      questions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
  } else {
    questions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  if (params?.searchQuery && params.searchQuery.trim()) {
    const lower = params.searchQuery.toLowerCase().trim();
    questions = questions.filter(
      q =>
        q.title.toLowerCase().includes(lower) ||
        q.description.toLowerCase().includes(lower) ||
        (q.subjectName && q.subjectName.toLowerCase().includes(lower))
    );
  }

  return questions;
}

export async function createQuestion(input: CreateQuestionInput): Promise<Question> {
  const questionId = 'q_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  const newQuestion: Question = {
    questionId,
    authorId: input.authorId,
    title: input.title.trim(),
    description: input.description.trim(),
    subjectId: input.subjectId,
    subjectName: input.subjectName || '',
    imageUrl: input.imageUrl || '',
    isAnonymous: input.isAnonymous ?? true,
    createdAt: now,
    status: 'open',
    views: 0,
    upvotes: 0,
    answerCount: 0,
  };

  // Always store locally for immediate optimistic update
  addLocalQuestion(newQuestion);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'questions', questionId), newQuestion);
      // Dual sync to doubts collection for schema interoperability
      await setDoc(doc(db, 'doubts', questionId), {
        ...newQuestion,
        doubtId: questionId,
        userId: input.authorId,
      });
    } catch (error) {
      console.warn('Could not sync question to Firestore:', error);
    }
  }

  return newQuestion;
}

/**
 * Listens to all questions from all students in real-time across the shared community collection
 */
export function subscribeToAllQuestions(
  callback: (questions: Question[]) => void,
  onError?: (err: unknown) => void
): () => void {
  if (!isFirebaseConfigured || !db) {
    callback(getLocalQuestions());
    return () => {};
  }

  const q = query(collection(db, 'questions'), orderBy('createdAt', 'desc'), limit(150));

  return onSnapshot(
    q,
    snapshot => {
      const list = snapshot.docs.map(d => d.data() as Question);
      callback(list);
    },
    error => {
      console.warn('subscribeToAllQuestions error:', error);
      if (onError) onError(error);
      callback(getLocalQuestions());
    }
  );
}

export async function askAIForQuestion(
  questionId: string,
  questionTitle: string,
  questionDescription: string,
  subjectName?: string,
  imageUrl?: string
): Promise<string> {
  const res = await fetch('/api/ai/answer-doubt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ questionTitle, questionDescription, subjectName, imageUrl }),
  });

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to generate AI explanation.');
  }

  const data = await res.json();
  const explanation = data.explanation;

  const now = new Date().toISOString();

  // Update local cache
  const localQuestions = getLocalQuestions();
  const idx = localQuestions.findIndex(q => q.questionId === questionId);
  if (idx >= 0) {
    localQuestions[idx] = {
      ...localQuestions[idx],
      aiExplanation: explanation,
      aiExplanationCreatedAt: now,
    };
    saveLocalQuestions(localQuestions);
  }

  // Persist AI answer to question document so other students can benefit immediately
  if (isFirebaseConfigured && db) {
    try {
      await updateDoc(doc(db, 'questions', questionId), {
        aiExplanation: explanation,
        aiExplanationCreatedAt: now,
      });
    } catch (err) {
      console.warn('Could not save AI answer to Firestore question:', err);
    }
  }

  return explanation;
}

export function subscribeToQuestions(
  params: {
    subjectId?: string;
    filter?: QuestionFilter;
    searchQuery?: string;
  },
  callback: (questions: Question[]) => void,
  onError?: (err: unknown) => void
): () => void {
  if (!isFirebaseConfigured || !db) {
    const local = getLocalQuestions();
    callback(filterQuestionsLocally(local, params));
    return () => {};
  }

  const path = 'questions';
  let q = query(collection(db, path), orderBy('createdAt', 'desc'), limit(100));

  if (params?.subjectId && params.subjectId !== 'all') {
    q = query(collection(db, path), where('subjectId', '==', params.subjectId), limit(100));
  }

  return onSnapshot(
    q,
    snapshot => {
      const remoteQuestions = snapshot.docs.map(d => d.data() as Question);
      callback(filterQuestionsLocally(remoteQuestions, params));
    },
    error => {
      console.warn('subscribeToQuestions error, falling back to local:', error);
      if (onError) onError(error);
      callback(filterQuestionsLocally(getLocalQuestions(), params));
    }
  );
}

export async function getQuestions(params?: {
  subjectId?: string;
  filter?: QuestionFilter;
  searchQuery?: string;
}): Promise<Question[]> {
  const localList = getLocalQuestions();

  if (!isFirebaseConfigured || !db) {
    return filterQuestionsLocally(localList, params);
  }

  const path = 'questions';
  try {
    let q = query(collection(db, path), orderBy('createdAt', 'desc'), limit(100));

    if (params?.subjectId && params.subjectId !== 'all') {
      q = query(collection(db, path), where('subjectId', '==', params.subjectId), limit(100));
    }

    const snap = await getDocs(q);
    if (snap.empty) {
      return filterQuestionsLocally(localList, params);
    }

    const remoteQuestions = snap.docs.map(d => d.data() as Question);
    const remoteIds = new Set(remoteQuestions.map(rq => rq.questionId));

    // Merge any freshly created local questions not yet indexed
    const combined = [...remoteQuestions];
    for (const lq of localList) {
      if (!remoteIds.has(lq.questionId)) {
        combined.push(lq);
      }
    }

    return filterQuestionsLocally(combined, params);
  } catch (error) {
    console.warn('Could not load questions from Firestore, using local cache:', error);
    return filterQuestionsLocally(localList, params);
  }
}

export async function getQuestionById(questionId: string): Promise<Question | null> {
  const localList = getLocalQuestions();
  const localMatch = localList.find(q => q.questionId === questionId) || null;

  if (!isFirebaseConfigured || !db) return localMatch;

  try {
    const snap = await getDoc(doc(db, 'questions', questionId));
    if (snap.exists()) {
      return snap.data() as Question;
    }
    return localMatch;
  } catch (error) {
    console.warn('Could not fetch question by ID from Firestore, using local match:', error);
    return localMatch;
  }
}

export function subscribeToQuestion(
  questionId: string,
  onData: (q: Question | null) => void,
  onError?: (err: unknown) => void
) {
  const localMatch = getLocalQuestions().find(q => q.questionId === questionId) || null;

  if (!isFirebaseConfigured || !db) {
    onData(localMatch);
    return () => {};
  }

  return onSnapshot(
    doc(db, 'questions', questionId),
    snap => {
      if (snap.exists()) {
        onData(snap.data() as Question);
      } else {
        onData(localMatch);
      }
    },
    error => {
      console.warn('Subscription error for question, using local match:', error);
      if (onError) onError(error);
      onData(localMatch);
    }
  );
}

export async function incrementQuestionViews(questionId: string): Promise<void> {
  // Update locally
  const questions = getLocalQuestions();
  const idx = questions.findIndex(q => q.questionId === questionId);
  if (idx >= 0) {
    questions[idx] = { ...questions[idx], views: (questions[idx].views || 0) + 1 };
    saveLocalQuestions(questions);
  }

  if (!isFirebaseConfigured || !db) return;

  try {
    await updateDoc(doc(db, 'questions', questionId), {
      views: increment(1),
    });
  } catch {
    // Non-blocking
  }
}

export async function deleteQuestion(questionId: string): Promise<void> {
  // Delete locally
  const questions = getLocalQuestions().filter(q => q.questionId !== questionId);
  saveLocalQuestions(questions);

  if (isFirebaseConfigured && db) {
    try {
      await Promise.allSettled([
        deleteDoc(doc(db, 'questions', questionId)),
        deleteDoc(doc(db, 'doubts', questionId)),
      ]);
    } catch (e) {
      console.warn('Could not delete question on Firestore:', e);
    }
  }
}

export async function getQuestionsByAuthor(authorId: string): Promise<Question[]> {
  const localMatch = getLocalQuestions().filter(q => q.authorId === authorId);

  if (!isFirebaseConfigured || !db) return localMatch;

  try {
    const q = query(collection(db, 'questions'), where('authorId', '==', authorId), limit(100));
    const snap = await getDocs(q);
    if (snap.empty) return localMatch;
    const results = snap.docs.map(d => d.data() as Question);
    results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return results;
  } catch {
    return localMatch;
  }
}

export async function getQuestionsByUser(userId: string): Promise<Question[]> {
  return getQuestionsByAuthor(userId);
}

export async function setQuestionAcceptedAnswer(
  questionId: string,
  answerId: string | undefined
): Promise<void> {
  const questions = getLocalQuestions();
  const idx = questions.findIndex(q => q.questionId === questionId);
  if (idx >= 0) {
    questions[idx] = {
      ...questions[idx],
      acceptedAnswerId: answerId || undefined,
      status: answerId ? 'resolved' : 'open',
      updatedAt: new Date().toISOString(),
    };
    saveLocalQuestions(questions);
  }

  if (isFirebaseConfigured && db) {
    try {
      const payload = {
        acceptedAnswerId: answerId || null,
        status: answerId ? 'resolved' : 'open',
        updatedAt: new Date().toISOString(),
      };
      await Promise.allSettled([
        updateDoc(doc(db, 'questions', questionId), payload),
        updateDoc(doc(db, 'doubts', questionId), payload),
      ]);
    } catch (e) {
      console.warn('Could not update accepted answer on Firestore:', e);
    }
  }
}
