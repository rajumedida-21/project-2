import {
  collection,
  doc,
  setDoc,
  getDocs,
  query,
  orderBy,
  deleteDoc,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { AIChatMessage } from '../types';

export interface DoubtAssistantOptions {
  message: string;
  image?: string; // Data URL or base64
  conversationHistory?: Array<{ role: 'user' | 'model'; content: string }>;
  actionType?: 'normal' | 'simpler' | 'example' | 'hint' | 'solution' | 'practice_question';
  subject?: string;
  language?: 'English' | 'Telugu' | 'Hindi';
}

export async function askAIDoubtAssistant(options: DoubtAssistantOptions): Promise<string> {
  const res = await fetch('/api/ai/doubt-assistant', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(options),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'AI Tutor is temporarily unavailable. Please try again.');
  }

  const data = await res.json();
  return data.reply;
}

export interface StudyPlanInputs {
  subjects: string[];
  topics: string;
  examDate: string;
  hoursPerDay: number;
  knowledgeLevel: string;
  strongSubjects: string;
  weakSubjects: string;
  preferredTime: string;
  dailyGoal: string;
}

export interface StudyPlanResponse {
  planText: string;
  suggestedTasks: Array<{
    title: string;
    subject: string;
    topic: string;
    durationMinutes: number;
    priority: 'High' | 'Medium' | 'Low';
    dayOffset: number;
  }>;
}

export async function generateAIStudyPlan(inputs: StudyPlanInputs): Promise<StudyPlanResponse> {
  const res = await fetch('/api/ai/study-plan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(inputs),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Unable to generate study plan at this time.');
  }

  return await res.json();
}

export async function generateAIQuiz(params: {
  subject: string;
  topic: string;
  difficulty: string;
  questionCount: number;
}) {
  const res = await fetch('/api/ai/quiz', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'AI quiz generation failed. Please try again.');
  }

  return await res.json();
}

export async function generateAILearningAnalysis(payload: {
  quizzesTaken: number;
  averageScore: number;
  quizHistory: any[];
  doubtsAsked: any[];
  completedTasks: any[];
  streakDays: number;
}) {
  const res = await fetch('/api/ai/learning-analysis', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Unable to generate learning analysis.');
  }

  return await res.json();
}

// ----------------------------------------------------
// Chat History Persistence (Scoped to User UID)
// ----------------------------------------------------
const LOCAL_CHAT_KEY = 'ai_doubt_assistant_messages';

export function getLocalChatMessages(): AIChatMessage[] {
  try {
    const raw = localStorage.getItem(LOCAL_CHAT_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveLocalChatMessages(msgs: AIChatMessage[]) {
  try {
    localStorage.setItem(LOCAL_CHAT_KEY, JSON.stringify(msgs.slice(-50)));
  } catch {
    // Ignore storage quota
  }
}

export async function saveAIChatMessage(userId: string, message: AIChatMessage): Promise<void> {
  // Always update local for snappy UI
  const current = getLocalChatMessages();
  saveLocalChatMessages([...current, message]);

  if (isFirebaseConfigured && db && userId) {
    try {
      const msgRef = doc(db, 'aiConversations', userId, 'messages', message.id);
      await setDoc(msgRef, message);
    } catch (e) {
      console.warn('Could not persist chat message to Firestore:', e);
    }
  }
}

export function subscribeToAIChatMessages(
  userId: string,
  onData: (messages: AIChatMessage[]) => void
): () => void {
  if (!isFirebaseConfigured || !db || !userId) {
    onData(getLocalChatMessages());
    return () => {};
  }

  const q = query(
    collection(db, 'aiConversations', userId, 'messages'),
    orderBy('timestamp', 'asc')
  );

  return onSnapshot(
    q,
    snapshot => {
      if (!snapshot.empty) {
        const msgs = snapshot.docs.map(d => d.data() as AIChatMessage);
        onData(msgs);
        saveLocalChatMessages(msgs);
      } else {
        onData(getLocalChatMessages());
      }
    },
    err => {
      console.warn('subscribeToAIChatMessages fallback:', err);
      onData(getLocalChatMessages());
    }
  );
}

export async function clearAIChatMessages(userId?: string): Promise<void> {
  localStorage.removeItem(LOCAL_CHAT_KEY);

  if (isFirebaseConfigured && db && userId) {
    try {
      const snap = await getDocs(collection(db, 'aiConversations', userId, 'messages'));
      const batchPromises = snap.docs.map(d => deleteDoc(d.ref));
      await Promise.allSettled(batchPromises);
    } catch (e) {
      console.warn('Could not delete AI chat messages in Firestore:', e);
    }
  }
}

// ----------------------------------------------------
// Semantic Search & Concept Similarity
// ----------------------------------------------------
export async function findSimilarDoubts(params: {
  currentQuestionId?: string;
  title: string;
  description?: string;
  subjectId?: string;
  allQuestions: any[];
}): Promise<Array<{
  questionId: string;
  title: string;
  subjectName: string;
  similarityScore: number;
  matchedConcept?: string;
}>> {
  try {
    const res = await fetch('/api/ai/similar-doubts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });

    if (!res.ok) return [];
    const data = await res.json();
    return data.similarQuestions || [];
  } catch (err) {
    console.warn('findSimilarDoubts failed:', err);
    return [];
  }
}

export async function performSemanticSearch(
  query: string,
  questions: any[]
): Promise<Array<{
  questionId: string;
  title: string;
  subjectName: string;
  similarityScore: number;
  matchedConcept?: string;
}>> {
  try {
    const res = await fetch('/api/ai/semantic-search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, questions }),
    });

    if (!res.ok) return [];
    const data = await res.json();
    return data.results || [];
  } catch (err) {
    console.warn('performSemanticSearch failed:', err);
    return [];
  }
}

// ----------------------------------------------------
// Tier 3: AI Learning Report, Goal Breakdown & Feed
// ----------------------------------------------------
export async function generateAILearningReport(payload: {
  quizzesTaken: number;
  averageScore: number;
  quizHistory: any[];
  doubtsAsked: any[];
  completedTasks: any[];
  streakDays: number;
  flashcardsCount?: number;
  flashcardMastery?: Record<string, number>;
  studyMinutes?: number;
}): Promise<{ reportText: string; generatedAt: string }> {
  const res = await fetch('/api/ai/learning-report', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Unable to generate learning report.');
  }

  return await res.json();
}

export async function breakDownAILearningGoal(payload: {
  goalTitle: string;
  subject?: string;
  targetDate?: string;
  currentLevel?: string;
}): Promise<{
  tasks: Array<{ id: string; title: string; estimatedMinutes: number; priority?: string }>;
  suggestedNextStep: string;
}> {
  const res = await fetch('/api/ai/break-down-goal', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Unable to break down goal.');
  }

  return await res.json();
}

export async function fetchPersonalizedDailyFeed(payload: {
  weakTopics?: string[];
  streakDays?: number;
  recentDoubts?: string[];
  dueFlashcardsCount?: number;
  activeGoals?: string[];
}): Promise<{
  greeting: string;
  summaryMessage?: string;
  tasks: Array<{
    id: string;
    title: string;
    category: 'study' | 'flashcard' | 'quiz' | 'practice';
    durationMinutes: number;
    subject?: string;
  }>;
}> {
  const res = await fetch('/api/ai/daily-feed-recommendation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    // Fallback gracefully
    return {
      greeting: 'Good day! Ready for your study sprint? 🎯',
      summaryMessage: 'Consistent review creates mastery.',
      tasks: [
        { id: 'f1', title: '20 min — Core concept review and lecture synthesis', category: 'study', durationMinutes: 20 },
        { id: 'f2', title: '10 min — Spaced repetition active recall flashcards', category: 'flashcard', durationMinutes: 10 },
        { id: 'f3', title: '15 min — Test understanding with an interactive quiz', category: 'quiz', durationMinutes: 15 },
      ],
    };
  }

  return await res.json();
}
