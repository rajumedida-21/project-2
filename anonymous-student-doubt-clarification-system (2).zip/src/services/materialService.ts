import {
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import {
  StudyDocument,
  DocumentChunk,
  SummaryType,
  KeyConceptItem,
  DocumentImportantQuestion,
  DocumentFlashcard,
  QuizQuestion,
  RAGQueryResult,
} from '../types';

const LOCAL_DOCUMENTS_KEY = 'ai_study_documents_cache';

export function getLocalDocuments(userId?: string): StudyDocument[] {
  try {
    const raw = localStorage.getItem(LOCAL_DOCUMENTS_KEY);
    if (!raw) return getStarterSampleDocuments();
    const parsed: StudyDocument[] = JSON.parse(raw);
    if (userId) {
      const userDocs = parsed.filter(d => d.userId === userId);
      return userDocs.length > 0 ? userDocs : parsed;
    }
    return parsed;
  } catch {
    return getStarterSampleDocuments();
  }
}

export function saveLocalDocuments(docs: StudyDocument[]) {
  try {
    // Avoid exceeding quota by trimming rawText if very large
    const trimmed = docs.map(d => ({
      ...d,
      rawText: (d.rawText || '').substring(0, 15000),
      chunks: (d.chunks || []).slice(0, 30),
    }));
    localStorage.setItem(LOCAL_DOCUMENTS_KEY, JSON.stringify(trimmed));
  } catch (e) {
    console.warn('Local storage save failed:', e);
  }
}

function getStarterSampleDocuments(): StudyDocument[] {
  return [
    {
      id: 'doc_starter_dsa',
      userId: 'system_demo',
      name: 'Binary Search Trees & Balancing Algorithms.pdf',
      subject: 'Data Structures & Algorithms',
      fileType: 'pdf',
      fileSize: '420 KB',
      uploadDate: new Date(Date.now() - 86400000 * 2).toISOString(),
      status: 'ready',
      extractedTextLength: 4250,
      chunkCount: 6,
      rawText: `Binary Search Trees (BST) and Self-Balancing Trees (AVL and Red-Black Trees).
A Binary Search Tree is a node-based binary tree data structure which has the following properties:
- The left subtree of a node contains only nodes with keys lesser than the node's key.
- The right subtree of a node contains only nodes with keys greater than the node's key.
- The left and right subtree each must also be a binary search tree.

Time Complexity Analysis:
In the best and average cases, Search, Insertion, and Deletion operations take O(log n) time.
In the worst case (when tree degenerates into a linear chain or skewed tree), operations degrade to O(n) time.

To prevent degradation, Self-Balancing Trees maintain a height of O(log n):
1. AVL Trees: Enforces that the height difference (balance factor = height(left) - height(right)) between left and right subtrees is at most 1 for every node. Rotations (Left, Right, Left-Right, Right-Left) restore balance after insertions and deletions.
2. Red-Black Trees: A self-balancing binary search tree where each node has a color (red or black).
Rules:
- Root is always black.
- Every leaf (NIL) is black.
- If a node is red, both its children are black (no two consecutive red nodes).
- Every path from a node to any of its descendant NIL nodes has the same number of black nodes (black height).
Used in Java TreeMap and C++ std::map due to faster insertion and deletion balancing rotations.`,
      chunks: [
        {
          chunkId: 'chunk_dsa_1',
          documentId: 'doc_starter_dsa',
          documentName: 'Binary Search Trees & Balancing Algorithms.pdf',
          chunkIndex: 0,
          content: 'Binary Search Trees (BST): A node-based binary tree where left child < node < right child. Average search, insert, delete is O(log n). Worst case degenerates to O(n) for skewed trees.',
          pageOrSection: 'Section 1: BST Fundamentals',
        },
        {
          chunkId: 'chunk_dsa_2',
          documentId: 'doc_starter_dsa',
          documentName: 'Binary Search Trees & Balancing Algorithms.pdf',
          chunkIndex: 1,
          content: 'AVL Trees: Self-balancing BST where the balance factor (height(left) - height(right)) is in {-1, 0, 1}. Uses single and double tree rotations (LL, RR, LR, RL) to rebalance in O(log n).',
          pageOrSection: 'Section 2: AVL Trees',
        },
        {
          chunkId: 'chunk_dsa_3',
          documentId: 'doc_starter_dsa',
          documentName: 'Binary Search Trees & Balancing Algorithms.pdf',
          chunkIndex: 2,
          content: 'Red-Black Trees: Root is black, no consecutive red nodes, equal black-height on all paths. Standard choice in C++ STL map/set and Java TreeMap due to fewer rotations on insertion.',
          pageOrSection: 'Section 3: Red-Black Trees',
        },
      ],
      summaries: {
        quick: 'This document provides a concise foundation on Binary Search Trees (BST), their search/insertion complexities, and why AVL and Red-Black trees are needed to avoid O(n) degenerate worst-cases.',
      },
    },
    {
      id: 'doc_starter_dbms',
      userId: 'system_demo',
      name: 'Database Transactions & ACID Properties.docx',
      subject: 'Database Systems',
      fileType: 'docx',
      fileSize: '310 KB',
      uploadDate: new Date(Date.now() - 86400000).toISOString(),
      status: 'ready',
      extractedTextLength: 3800,
      chunkCount: 5,
      rawText: `Relational Database Transactions and ACID Properties.
A database transaction is a logical unit of processing in a DBMS which entails one or more database access operations.
ACID Properties:
1. Atomicity: "All or nothing" rule. Either all operations in the transaction succeed and commit, or in the event of failure, the database rolls back to its state prior to transaction initiation. Implemented via Write-Ahead Logging (WAL) and Undo logs.
2. Consistency: A transaction must transform the database from one valid consistent state to another valid state, preserving all integrity constraints (primary keys, foreign keys, check constraints).
3. Isolation: Concurrent execution of transactions yields the same system state as if transactions were executed serially. Prevents phenomena like Dirty Reads, Non-Repeatable Reads, and Phantom Reads. Isolation levels: Read Uncommitted, Read Committed, Repeatable Read, Serializable.
4. Durability: Once a transaction commits, its effects are permanent and survive system crashes or power outages. Guaranteed via redo logs and non-volatile storage flushing.`,
      chunks: [
        {
          chunkId: 'chunk_dbms_1',
          documentId: 'doc_starter_dbms',
          documentName: 'Database Transactions & ACID Properties.docx',
          chunkIndex: 0,
          content: 'A transaction is a logical unit of work. Atomicity guarantees all-or-nothing execution via write-ahead logging (WAL) and undo logs.',
          pageOrSection: 'Section 1: Atomicity & Concept',
        },
        {
          chunkId: 'chunk_dbms_2',
          documentId: 'doc_starter_dbms',
          documentName: 'Database Transactions & ACID Properties.docx',
          chunkIndex: 1,
          content: 'Consistency ensures all constraints (PK, FK, unique) are satisfied before and after commit. Isolation prevents race conditions and dirty reads across transactions.',
          pageOrSection: 'Section 2: Consistency & Isolation',
        },
        {
          chunkId: 'chunk_dbms_3',
          documentId: 'doc_starter_dbms',
          documentName: 'Database Transactions & ACID Properties.docx',
          chunkIndex: 2,
          content: 'Durability ensures committed state persists across crashes via redo log flushes to disk. Four isolation levels include Serializable, Repeatable Read, Read Committed, and Read Uncommitted.',
          pageOrSection: 'Section 3: Durability & Isolation Levels',
        },
      ],
      summaries: {
        quick: 'Comprehensive revision notes covering database transaction lifecycles, ACID criteria (Atomicity, Consistency, Isolation, Durability), and isolation levels preventing dirty or phantom reads.',
      },
    },
  ];
}

/**
 * Upload and process a study document
 */
export async function processAndSaveDocument(params: {
  userId: string;
  name: string;
  subject: string;
  fileType: 'pdf' | 'docx' | 'txt' | 'notes';
  fileData?: string; // base64 or raw text
  rawText?: string;
  fileSizeFormatted?: string;
}): Promise<StudyDocument> {
  const docId = 'doc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  let extractedText = params.rawText || '';

  // 1. If binary/fileData is provided, extract text via server API
  if (params.fileData && !extractedText) {
    try {
      const res = await fetch('/api/ai/document/extract-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileData: params.fileData,
          fileName: params.name,
          fileType: params.fileType,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        extractedText = data.text;
      } else {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to extract text from file');
      }
    } catch (extractErr: any) {
      console.warn('Text extraction error:', extractErr);
      // If client-side raw text was given, keep it; else throw
      if (!extractedText) {
        throw new Error(extractErr.message || 'Could not parse document file.');
      }
    }
  }

  // 2. Chunk and embed
  let chunks: DocumentChunk[] = [];
  try {
    const chunkRes = await fetch('/api/ai/document/chunk-and-embed', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        documentId: docId,
        documentName: params.name,
        text: extractedText,
      }),
    });

    if (chunkRes.ok) {
      const chunkData = await chunkRes.json();
      chunks = chunkData.chunks || [];
    }
  } catch (chunkErr) {
    console.warn('Chunk and embed error, creating local fallback chunks:', chunkErr);
    // Fallback: simple text slice chunks
    chunks = [
      {
        chunkId: `${docId}_chunk_0`,
        documentId: docId,
        documentName: params.name,
        chunkIndex: 0,
        content: extractedText.substring(0, 1000),
        pageOrSection: 'Overview',
      },
    ];
  }

  const newDoc: StudyDocument = {
    id: docId,
    userId: params.userId,
    name: params.name,
    subject: params.subject,
    fileType: params.fileType,
    fileSize: params.fileSizeFormatted || `${Math.round(extractedText.length / 1024)} KB`,
    uploadDate: now,
    status: 'ready',
    extractedTextLength: extractedText.length,
    chunkCount: chunks.length,
    rawText: extractedText,
    chunks,
    summaries: {},
  };

  // 3. Save locally
  const current = getLocalDocuments();
  saveLocalDocuments([newDoc, ...current]);

  // 4. Save to Firestore if configured
  if (isFirebaseConfigured && db && params.userId) {
    try {
      // Store document record (store chunks without embedding in doc to stay under 1MB Firestore doc limit)
      const docPayload = {
        ...newDoc,
        rawText: extractedText.substring(0, 30000),
        chunks: chunks.map(c => ({
          chunkId: c.chunkId,
          documentId: c.documentId,
          documentName: c.documentName,
          chunkIndex: c.chunkIndex,
          content: c.content,
          pageOrSection: c.pageOrSection,
        })),
      };
      await setDoc(doc(db, 'studyDocuments', docId), docPayload);
    } catch (e) {
      console.warn('Firestore doc save error:', e);
    }
  }

  return newDoc;
}

/**
 * Subscribe to study documents for a student
 */
export function subscribeToStudyDocuments(
  userId: string,
  onData: (docs: StudyDocument[]) => void
): () => void {
  const localList = getLocalDocuments(userId);
  onData(localList);

  if (!isFirebaseConfigured || !db || !userId) {
    return () => {};
  }

  const q = query(
    collection(db, 'studyDocuments'),
    where('userId', '==', userId),
    orderBy('uploadDate', 'desc')
  );

  return onSnapshot(
    q,
    snapshot => {
      if (!snapshot.empty) {
        const remoteDocs = snapshot.docs.map(d => d.data() as StudyDocument);
        onData(remoteDocs);
        saveLocalDocuments(remoteDocs);
      }
    },
    err => {
      console.warn('subscribeToStudyDocuments fallback:', err);
      onData(getLocalDocuments(userId));
    }
  );
}

/**
 * Delete a study document
 */
export async function deleteStudyDocument(docId: string, userId?: string): Promise<void> {
  const current = getLocalDocuments();
  const updated = current.filter(d => d.id !== docId);
  saveLocalDocuments(updated);

  if (isFirebaseConfigured && db && docId) {
    try {
      await deleteDoc(doc(db, 'studyDocuments', docId));
    } catch (e) {
      console.warn('Firestore document delete error:', e);
    }
  }
}

/**
 * Query document with RAG Vector Search
 */
export async function queryDocumentRAG(params: {
  question: string;
  documentName?: string;
  chunks: DocumentChunk[];
  conversationHistory?: any[];
}): Promise<RAGQueryResult> {
  const res = await fetch('/api/ai/document/rag-chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to query document. Please try again.');
  }

  return await res.json();
}

/**
 * Analyze document (Summarize, Explain, MCQs, Questions, Flashcards, Key Concepts)
 */
export async function analyzeStudyDocument(params: {
  documentId: string;
  documentName: string;
  text: string;
  analysisType: 'summarize' | 'explain' | 'mcqs' | 'questions' | 'flashcards' | 'key_concepts';
  summarySubtype?: SummaryType;
  userId?: string;
}): Promise<any> {
  const res = await fetch('/api/ai/document/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to analyze document.');
  }

  const data = await res.json();

  // Cache result on local document
  try {
    const docs = getLocalDocuments();
    const target = docs.find(d => d.id === params.documentId);
    if (target) {
      if (params.analysisType === 'summarize' && data.result) {
        if (!target.summaries) target.summaries = {};
        target.summaries[params.summarySubtype || 'quick'] = data.result;
      } else if (params.analysisType === 'explain' && data.result) {
        target.explanation = data.result;
      } else if (params.analysisType === 'mcqs' && data.mcqs) {
        target.mcqs = data.mcqs;
      } else if (params.analysisType === 'questions' && data.questions) {
        target.importantQuestions = data.questions;
      } else if (params.analysisType === 'flashcards' && data.flashcards) {
        target.flashcards = data.flashcards;
      } else if (params.analysisType === 'key_concepts' && data.keyConcepts) {
        target.keyConcepts = data.keyConcepts;
      }
      saveLocalDocuments(docs);
    }
  } catch (cacheErr) {
    console.warn('Could not cache analysis on document:', cacheErr);
  }

  return data;
}
