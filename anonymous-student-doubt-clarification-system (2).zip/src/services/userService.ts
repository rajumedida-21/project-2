import {
  collection,
  doc,
  getDocs,
  updateDoc,
  query,
  where,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { UserProfile, UserRole } from '../types';

export async function getAllUsers(): Promise<UserProfile[]> {
  if (!isFirebaseConfigured || !db) return [];

  const path = 'users';
  try {
    const q = query(collection(db, path));
    const snapshot = await getDocs(q);
    if (snapshot.empty) return [];
    return snapshot.docs.map(docSnap => docSnap.data() as UserProfile);
  } catch (error) {
    console.warn('Could not list users from Firestore:', error);
    return [];
  }
}

export function subscribeToUsers(
  callback: (users: UserProfile[]) => void,
  onError?: (err: unknown) => void
): () => void {
  if (!isFirebaseConfigured || !db) {
    callback([]);
    return () => {};
  }

  return onSnapshot(
    collection(db, 'users'),
    snapshot => {
      const list = snapshot.docs.map(docSnap => docSnap.data() as UserProfile);
      callback(list);
    },
    error => {
      console.warn('subscribeToUsers error:', error);
      if (onError) onError(error);
    }
  );
}

export async function getVerifiedMentors(): Promise<UserProfile[]> {
  if (!isFirebaseConfigured || !db) return [];

  const path = 'users';
  try {
    const q = query(
      collection(db, path),
      where('role', 'in', ['mentor', 'admin']),
      where('isVerifiedMentor', '==', true)
    );
    const snapshot = await getDocs(q);
    if (snapshot.empty) return [];
    return snapshot.docs.map(docSnap => docSnap.data() as UserProfile);
  } catch (error) {
    try {
      const all = await getAllUsers();
      return all.filter(u => u.isVerifiedMentor);
    } catch {
      return [];
    }
  }
}

export async function updateUserRole(uid: string, newRole: UserRole): Promise<void> {
  if (!db) return;
  try {
    await updateDoc(doc(db, 'users', uid), {
      role: newRole,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.warn('Could not update user role on Firestore:', error);
  }
}

export async function toggleMentorVerification(uid: string, isVerified: boolean): Promise<void> {
  if (!db) return;
  try {
    await updateDoc(doc(db, 'users', uid), {
      isVerifiedMentor: isVerified,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.warn('Could not toggle mentor verification on Firestore:', error);
  }
}

export async function updateUserProfile(
  uid: string,
  data: Partial<Pick<UserProfile, 'name' | 'profileImage' | 'subjectSpecialization' | 'bio' | 'isVerifiedMentor' | 'role'>>
): Promise<void> {
  if (!db) return;
  try {
    await updateDoc(doc(db, 'users', uid), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.warn('Could not update user profile on Firestore:', error);
  }
}
