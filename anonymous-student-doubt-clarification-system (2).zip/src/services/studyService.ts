import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { StudyPlan, StudyTask } from '../types';

const LOCAL_PLANS_KEY = 'student_study_plans';
const LOCAL_TASKS_KEY = 'student_study_tasks';

// ----------------------------------------------------
// Local storage helpers (fallback)
// ----------------------------------------------------
function getLocalPlans(): StudyPlan[] {
  try {
    const raw = localStorage.getItem(LOCAL_PLANS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveLocalPlans(plans: StudyPlan[]) {
  try {
    localStorage.setItem(LOCAL_PLANS_KEY, JSON.stringify(plans));
  } catch {}
}

function getLocalTasks(): StudyTask[] {
  try {
    const raw = localStorage.getItem(LOCAL_TASKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveLocalTasks(tasks: StudyTask[]) {
  try {
    localStorage.setItem(LOCAL_TASKS_KEY, JSON.stringify(tasks));
  } catch {}
}

// ----------------------------------------------------
// Study Plans
// ----------------------------------------------------
export async function saveStudyPlan(plan: StudyPlan): Promise<void> {
  const local = getLocalPlans();
  const existingIdx = local.findIndex(p => p.planId === plan.planId);
  if (existingIdx >= 0) {
    local[existingIdx] = plan;
  } else {
    local.unshift(plan);
  }
  saveLocalPlans(local);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'studyPlans', plan.planId), plan);
    } catch (e) {
      console.warn('Could not save study plan to Firestore:', e);
    }
  }
}

export function subscribeToUserStudyPlans(
  userId: string,
  onData: (plans: StudyPlan[]) => void
): () => void {
  if (!isFirebaseConfigured || !db || !userId) {
    const userLocal = getLocalPlans().filter(p => p.userId === userId);
    onData(userLocal);
    return () => {};
  }

  const q = query(
    collection(db, 'studyPlans'),
    where('userId', '==', userId),
    limit(20)
  );

  return onSnapshot(
    q,
    snapshot => {
      const plans = snapshot.docs.map(d => d.data() as StudyPlan);
      plans.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onData(plans);
      // Sync local
      saveLocalPlans(plans);
    },
    err => {
      console.warn('subscribeToUserStudyPlans error:', err);
      const userLocal = getLocalPlans().filter(p => p.userId === userId);
      onData(userLocal);
    }
  );
}

// ----------------------------------------------------
// Study Tasks (Study Planner)
// ----------------------------------------------------
export async function createStudyTask(task: StudyTask): Promise<void> {
  const local = getLocalTasks();
  local.unshift(task);
  saveLocalTasks(local);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'studyTasks', task.taskId), task);
    } catch (e) {
      console.warn('Could not save study task to Firestore:', e);
    }
  }
}

export async function batchAddStudyTasks(tasks: StudyTask[]): Promise<void> {
  const local = getLocalTasks();
  const updated = [...tasks, ...local];
  saveLocalTasks(updated);

  if (isFirebaseConfigured && db) {
    try {
      await Promise.allSettled(
        tasks.map(t => setDoc(doc(db, 'studyTasks', t.taskId), t))
      );
    } catch (e) {
      console.warn('Batch task sync error:', e);
    }
  }
}

export function subscribeToStudyTasks(
  userId: string,
  onData: (tasks: StudyTask[]) => void
): () => void {
  if (!isFirebaseConfigured || !db || !userId) {
    const userTasks = getLocalTasks().filter(t => t.userId === userId);
    onData(userTasks);
    return () => {};
  }

  const q = query(
    collection(db, 'studyTasks'),
    where('userId', '==', userId)
  );

  return onSnapshot(
    q,
    snapshot => {
      const tasks = snapshot.docs.map(d => d.data() as StudyTask);
      tasks.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onData(tasks);
      saveLocalTasks(tasks);
    },
    err => {
      console.warn('subscribeToStudyTasks error:', err);
      onData(getLocalTasks().filter(t => t.userId === userId));
    }
  );
}

export async function toggleStudyTaskCompletion(taskId: string, completed: boolean): Promise<void> {
  const local = getLocalTasks();
  const idx = local.findIndex(t => t.taskId === taskId);
  const now = new Date().toISOString();
  if (idx >= 0) {
    local[idx].completed = completed;
    local[idx].completedAt = completed ? now : undefined;
    saveLocalTasks(local);
  }

  if (isFirebaseConfigured && db) {
    try {
      await updateDoc(doc(db, 'studyTasks', taskId), {
        completed,
        completedAt: completed ? now : null,
      });
    } catch (e) {
      console.warn('Could not update task status in Firestore:', e);
    }
  }
}

export async function deleteStudyTask(taskId: string): Promise<void> {
  const local = getLocalTasks().filter(t => t.taskId !== taskId);
  saveLocalTasks(local);

  if (isFirebaseConfigured && db) {
    try {
      await deleteDoc(doc(db, 'studyTasks', taskId));
    } catch (e) {
      console.warn('Could not delete task in Firestore:', e);
    }
  }
}

// ----------------------------------------------------
// Streak Calculation (Real calculation from active days)
// ----------------------------------------------------
export function calculateRealStreak(
  tasks: StudyTask[],
  quizDates: string[],
  doubtDates: string[]
): { currentStreak: number; longestStreak: number; activeDaysCount: number } {
  const activeDateSet = new Set<string>();

  // Add task completed dates
  tasks.forEach(t => {
    if (t.completed && t.completedAt) {
      activeDateSet.add(t.completedAt.split('T')[0]);
    }
  });

  // Add quiz dates
  quizDates.forEach(d => {
    if (d) activeDateSet.add(d.split('T')[0]);
  });

  // Add doubt ask dates
  doubtDates.forEach(d => {
    if (d) activeDateSet.add(d.split('T')[0]);
  });

  if (activeDateSet.size === 0) {
    return { currentStreak: 0, longestStreak: 0, activeDaysCount: 0 };
  }

  const sortedDates = Array.from(activeDateSet).sort();
  const today = new Date().toISOString().split('T')[0];

  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterday = yesterdayDate.toISOString().split('T')[0];

  let currentStreak = 0;
  let maxStreak = 0;
  let tempStreak = 0;

  // Calculate current streak backward from today / yesterday
  let checkDate = activeDateSet.has(today) ? new Date() : (activeDateSet.has(yesterday) ? yesterdayDate : null);

  if (checkDate) {
    while (true) {
      const dateStr = checkDate.toISOString().split('T')[0];
      if (activeDateSet.has(dateStr)) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  }

  // Calculate longest streak
  for (let i = 0; i < sortedDates.length; i++) {
    if (i === 0) {
      tempStreak = 1;
    } else {
      const prev = new Date(sortedDates[i - 1]);
      const curr = new Date(sortedDates[i]);
      const diffDays = Math.round((curr.getTime() - prev.getTime()) / (1000 * 3600 * 24));
      if (diffDays === 1) {
        tempStreak++;
      } else {
        tempStreak = 1;
      }
    }
    if (tempStreak > maxStreak) {
      maxStreak = tempStreak;
    }
  }

  return {
    currentStreak,
    longestStreak: Math.max(maxStreak, currentStreak),
    activeDaysCount: activeDateSet.size,
  };
}
