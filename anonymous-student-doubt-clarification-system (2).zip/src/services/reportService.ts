import {
  collection,
  doc,
  setDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { Report } from '../types';
import { createNotification } from './notificationService';

export interface CreateReportInput {
  reportedBy: string;
  contentType: 'question' | 'answer';
  contentId: string;
  contentSnippet?: string;
  reason: Report['reason'];
  details?: string;
}

export async function createReport(input: CreateReportInput): Promise<Report> {
  const reportId = 'rep_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  const reportData: Report = {
    reportId,
    reportedBy: input.reportedBy,
    contentType: input.contentType,
    contentId: input.contentId,
    contentSnippet: input.contentSnippet || '',
    reason: input.reason,
    details: input.details?.trim() || '',
    createdAt: now,
    status: 'pending',
  };

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'reports', reportId), reportData);
    } catch (error) {
      console.warn('Could not sync report to Firestore, returning local report:', error);
    }
  }

  return reportData;
}

export async function getAllReports(): Promise<Report[]> {
  if (!isFirebaseConfigured || !db) return [];

  const path = 'reports';
  try {
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as Report);
  } catch (error) {
    console.warn('Could not list reports from Firestore:', error);
    return [];
  }
}

export async function updateReportStatus(
  reportId: string,
  newStatus: Report['status'],
  reportedBy?: string
): Promise<void> {
  if (!db) return;

  try {
    await updateDoc(doc(db, 'reports', reportId), {
      status: newStatus,
      updatedAt: new Date().toISOString(),
    });

    if (reportedBy) {
      try {
        await createNotification({
          recipientId: reportedBy,
          type: 'report',
          title: 'Report update',
          message: `Your report has been marked as "${newStatus}" by moderators.`,
        });
      } catch {
        // Non-blocking
      }
    }
  } catch (error) {
    console.warn('Could not update report status on Firestore:', error);
  }
}

export async function deleteReport(reportId: string): Promise<void> {
  if (!db) return;
  try {
    await deleteDoc(doc(db, 'reports', reportId));
  } catch (error) {
    console.warn('Could not delete report on Firestore:', error);
  }
}
