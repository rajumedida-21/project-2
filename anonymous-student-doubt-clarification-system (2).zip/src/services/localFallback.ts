import { Question, Answer, UserProfile } from '../types';

// Real-time pure state: No fake or mock static questions/answers/mentors
export const INITIAL_QUESTIONS: Question[] = [];
export const INITIAL_ANSWERS: Answer[] = [];
export const INITIAL_MENTORS: UserProfile[] = [];

const LOCAL_QUESTIONS_KEY = 'doubt_local_questions_store';
const LOCAL_ANSWERS_KEY = 'doubt_local_answers_store';
const LOCAL_VOTES_KEY = 'doubt_local_votes_store';

// Purge any stale legacy dummy data from previous sessions
function sanitizeQuestions(list: Question[]): Question[] {
  const dummyIds = new Set(['q_dsa_1', 'q_dbms_1', 'q_os_1', 'q_java_1']);
  return list.filter(q => !dummyIds.has(q.questionId) && !q.authorId.startsWith('student_'));
}

function sanitizeAnswers(list: Answer[]): Answer[] {
  const dummyIds = new Set(['ans_dsa_1', 'ans_dbms_1']);
  return list.filter(a => !dummyIds.has(a.answerId) && !a.authorId.startsWith('mentor_'));
}

export function getLocalQuestions(): Question[] {
  try {
    const raw = localStorage.getItem(LOCAL_QUESTIONS_KEY);
    if (raw) {
      const parsed: Question[] = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        const sanitized = sanitizeQuestions(parsed);
        if (sanitized.length !== parsed.length) {
          saveLocalQuestions(sanitized);
        }
        return sanitized;
      }
    }
  } catch {
    // ignore
  }
  return [];
}

export function saveLocalQuestions(questions: Question[]): void {
  try {
    const sanitized = sanitizeQuestions(questions);
    localStorage.setItem(LOCAL_QUESTIONS_KEY, JSON.stringify(sanitized));
  } catch {
    // ignore
  }
}

export function addLocalQuestion(question: Question): void {
  const current = getLocalQuestions();
  const filtered = current.filter(q => q.questionId !== question.questionId);
  saveLocalQuestions([question, ...filtered]);
}

export function getLocalAnswers(questionId?: string): Answer[] {
  let allAnswers: Answer[] = [];
  try {
    const raw = localStorage.getItem(LOCAL_ANSWERS_KEY);
    if (raw) {
      const parsed: Answer[] = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        allAnswers = sanitizeAnswers(parsed);
      }
    }
  } catch {
    // ignore
  }

  if (questionId) {
    return allAnswers.filter(a => a.questionId === questionId);
  }
  return allAnswers;
}

export function saveLocalAnswers(answers: Answer[]): void {
  try {
    const sanitized = sanitizeAnswers(answers);
    localStorage.setItem(LOCAL_ANSWERS_KEY, JSON.stringify(sanitized));
  } catch {
    // ignore
  }
}

export function addLocalAnswer(answer: Answer): void {
  const current = getLocalAnswers();
  const filtered = current.filter(a => a.answerId !== answer.answerId);
  saveLocalAnswers([...filtered, answer]);

  // Also update local question answerCount
  const questions = getLocalQuestions();
  const qIndex = questions.findIndex(q => q.questionId === answer.questionId);
  if (qIndex >= 0) {
    questions[qIndex] = {
      ...questions[qIndex],
      answerCount: (questions[qIndex].answerCount || 0) + 1,
      updatedAt: new Date().toISOString(),
    };
    saveLocalQuestions(questions);
  }
}

export function getLocalUserVotes(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(LOCAL_VOTES_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return {};
}

export function saveLocalUserVote(targetId: string, hasVoted: boolean): void {
  try {
    const votes = getLocalUserVotes();
    if (hasVoted) {
      votes[targetId] = true;
    } else {
      delete votes[targetId];
    }
    localStorage.setItem(LOCAL_VOTES_KEY, JSON.stringify(votes));
  } catch {
    // ignore
  }
}

