import { collection, getDocs, onSnapshot } from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { UserProfile, Question, Answer } from '../types';
import { getAllUsers } from './userService';
import { getQuestions } from './questionService';
import { getAllAnswers } from './answerService';
import { getLocalQuestions, getLocalAnswers } from './localFallback';

export interface DoubtReplyAnalytics {
  answerId: string;
  questionId: string;
  answerText: string;
  authorId: string;
  authorRole: string;
  isVerifiedMentor: boolean;
  isAccepted: boolean;
  upvotes: number;
  createdAt: string;
  replier?: UserProfile | null;
  replierName: string;
  replierEmail: string;
  replierRole: string;
}

export interface DoubtAnalyticsItem {
  id: string; // doubt id
  title: string;
  description: string;
  subjectName: string;
  subjectId: string;
  createdAt: string;
  status: 'open' | 'resolved' | 'closed';
  isAnonymous: boolean;
  upvotes: number;
  userId: string; // author ID
  student?: UserProfile | null;
  studentName: string;
  studentEmail: string;
  studentRole: string;
  replies: DoubtReplyAnalytics[];
  replyCount: number;
  hasMentorReply: boolean;
  hasAcceptedReply: boolean;
  views: number;
}

export interface DoubtAnalyticsSummary {
  totalDoubts: number;
  totalUsers: number;
  totalStudents: number;
  totalMentors: number;
  totalReplies: number;
  resolvedDoubtsCount: number;
  unansweredDoubtsCount: number;
  mentorAnsweredCount: number;
  resolutionRate: number; // percentage
}

export interface DoubtAnalyticsData {
  items: DoubtAnalyticsItem[];
  users: UserProfile[];
  summary: DoubtAnalyticsSummary;
}

function processAnalytics(
  userProfiles: UserProfile[],
  doubts: Question[],
  allReplies: Answer[]
): DoubtAnalyticsData {
  const userMap = new Map<string, UserProfile>();
  userProfiles.forEach(u => userMap.set(u.uid, u));

  // Group replies by question/doubt ID
  const repliesByDoubtId = new Map<string, Answer[]>();
  allReplies.forEach(ans => {
    const qId = ans.questionId;
    const list = repliesByDoubtId.get(qId) || [];
    list.push(ans);
    repliesByDoubtId.set(qId, list);
  });

  const items: DoubtAnalyticsItem[] = [];

  doubts.forEach(doubt => {
    const doubtUserId = doubt.authorId || (doubt as unknown as { userId?: string }).userId || '';
    const studentProfile = userMap.get(doubtUserId);

    // Map replies to users
    const rawReplies = repliesByDoubtId.get(doubt.questionId) || [];
    const mappedReplies: DoubtReplyAnalytics[] = rawReplies.map(reply => {
      const replierId = reply.authorId || (reply as unknown as { userId?: string }).userId || '';
      const replierProfile = userMap.get(replierId);

      return {
        answerId: reply.answerId,
        questionId: reply.questionId,
        answerText: reply.answerText,
        authorId: replierId,
        authorRole: replierProfile?.role || reply.authorRole || 'student',
        isVerifiedMentor: Boolean(replierProfile?.isVerifiedMentor || reply.isVerifiedMentor),
        isAccepted: Boolean(reply.isAccepted || (doubt.acceptedAnswerId && doubt.acceptedAnswerId === reply.answerId)),
        upvotes: reply.upvotes || 0,
        createdAt: reply.createdAt,
        replier: replierProfile || null,
        replierName: replierProfile?.name || reply.mentorName || (reply.isAnonymous ? 'Anonymous Peer' : 'Student Contributor'),
        replierEmail: replierProfile?.email || 'Not disclosed',
        replierRole: replierProfile?.role || reply.authorRole || (reply.isVerifiedMentor ? 'mentor' : 'student'),
      };
    });

    const hasMentorReply = mappedReplies.some(r => r.isVerifiedMentor || r.replierRole === 'mentor');
    const hasAcceptedReply = mappedReplies.some(r => r.isAccepted) || doubt.status === 'resolved';

    items.push({
      id: doubt.questionId,
      title: doubt.title,
      description: doubt.description,
      subjectName: doubt.subjectName || 'General Academic',
      subjectId: doubt.subjectId,
      createdAt: doubt.createdAt,
      status: hasAcceptedReply ? 'resolved' : doubt.status,
      isAnonymous: Boolean(doubt.isAnonymous),
      upvotes: doubt.upvotes || 0,
      userId: doubtUserId,
      student: studentProfile || null,
      studentName: studentProfile?.name || (doubt.isAnonymous ? 'Anonymous Student' : 'College Student'),
      studentEmail: studentProfile?.email || 'Unregistered / Anonymous',
      studentRole: studentProfile?.role || 'student',
      replies: mappedReplies,
      replyCount: mappedReplies.length,
      hasMentorReply,
      hasAcceptedReply,
      views: doubt.views || 0,
    });
  });

  // Sort descending by creation date
  items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Compute summary metrics
  const totalDoubts = items.length;
  const totalUsers = userProfiles.length;
  const totalStudents = userProfiles.filter(u => u.role === 'student').length;
  const totalMentors = userProfiles.filter(u => u.role === 'mentor' || u.isVerifiedMentor).length;
  const totalReplies = items.reduce((acc, curr) => acc + curr.replyCount, 0);
  const resolvedDoubtsCount = items.filter(d => d.hasAcceptedReply || d.status === 'resolved').length;
  const unansweredDoubtsCount = items.filter(d => d.replyCount === 0).length;
  const mentorAnsweredCount = items.filter(d => d.hasMentorReply).length;
  const resolutionRate = totalDoubts > 0 ? Math.round((resolvedDoubtsCount / totalDoubts) * 100) : 0;

  return {
    items,
    users: userProfiles,
    summary: {
      totalDoubts,
      totalUsers,
      totalStudents,
      totalMentors,
      totalReplies,
      resolvedDoubtsCount,
      unansweredDoubtsCount,
      mentorAnsweredCount,
      resolutionRate,
    },
  };
}

/**
 * Real-time subscription to the entire live Doubt Analytics dataset.
 * Reactively invokes callback whenever doubts, answers, or users change in Firestore.
 */
export function subscribeToDoubtAnalytics(
  callback: (data: DoubtAnalyticsData) => void,
  onError?: (err: unknown) => void
): () => void {
  if (!isFirebaseConfigured || !db) {
    const fallbackData = processAnalytics([], getLocalQuestions(), getLocalAnswers());
    callback(fallbackData);
    return () => {};
  }

  let latestUsers: UserProfile[] = [];
  let latestQuestionsMap = new Map<string, Question>();
  let latestAnswers: Answer[] = [];

  const update = () => {
    const doubts = Array.from(latestQuestionsMap.values());
    const data = processAnalytics(latestUsers, doubts, latestAnswers);
    callback(data);
  };

  // 1. Users listener
  const unsubUsers = onSnapshot(
    collection(db, 'users'),
    snap => {
      latestUsers = snap.docs.map(d => d.data() as UserProfile);
      update();
    },
    err => {
      console.warn('Real-time users analytics error:', err);
      if (onError) onError(err);
    }
  );

  // 2. Questions listener
  const unsubQuestions = onSnapshot(
    collection(db, 'questions'),
    snap => {
      snap.docs.forEach(docSnap => {
        const q = docSnap.data() as Question;
        latestQuestionsMap.set(q.questionId, q);
      });
      update();
    },
    err => {
      console.warn('Real-time questions analytics error:', err);
      if (onError) onError(err);
    }
  );

  // 3. Doubts collection listener (to catch any doubts posted to /doubts)
  const unsubDoubts = onSnapshot(
    collection(db, 'doubts'),
    snap => {
      snap.docs.forEach(docSnap => {
        const data = docSnap.data() as Record<string, unknown>;
        const id = (data.id || data.questionId || data.doubtId || docSnap.id) as string;
        const authorId = (data.userId || data.authorId || '') as string;
        latestQuestionsMap.set(id, {
          questionId: id,
          authorId,
          title: (data.title || 'Untitled Doubt') as string,
          description: (data.description || '') as string,
          subjectId: (data.subjectId || 'general') as string,
          subjectName: (data.subjectName || 'General') as string,
          imageUrl: (data.imageUrl || '') as string,
          isAnonymous: Boolean(data.isAnonymous),
          createdAt: (data.createdAt || new Date().toISOString()) as string,
          status: (data.status || 'open') as 'open' | 'resolved' | 'closed',
          views: Number(data.views || 0),
          upvotes: Number(data.upvotes || 0),
          answerCount: Number(data.answerCount || 0),
          acceptedAnswerId: data.acceptedAnswerId as string | undefined,
        });
      });
      update();
    },
    err => {
      // Non-fatal if /doubts collection is empty
      console.warn('Real-time doubts collection error:', err);
    }
  );

  // 4. Answers listener
  const unsubAnswers = onSnapshot(
    collection(db, 'answers'),
    snap => {
      latestAnswers = snap.docs.map(d => d.data() as Answer);
      update();
    },
    err => {
      console.warn('Real-time answers analytics error:', err);
      if (onError) onError(err);
    }
  );

  return () => {
    unsubUsers();
    unsubQuestions();
    unsubDoubts();
    unsubAnswers();
  };
}

/**
 * One-time fetch of doubt analytics data from live Firestore.
 */
export async function fetchDoubtAnalyticsData(): Promise<DoubtAnalyticsData> {
  let userProfiles: UserProfile[] = [];
  const doubtsMap = new Map<string, Question>();
  let allReplies: Answer[] = [];

  // 1. Fetch real users from /users
  try {
    if (isFirebaseConfigured && db) {
      const usersSnap = await getDocs(collection(db, 'users'));
      if (!usersSnap.empty) {
        userProfiles = usersSnap.docs.map(doc => doc.data() as UserProfile);
      }
    }
  } catch (err) {
    console.warn('Direct /users query failed, fallback to getAllUsers:', err);
  }

  if (userProfiles.length === 0) {
    userProfiles = await getAllUsers();
  }

  // 2. Fetch real doubts from /doubts and /questions
  try {
    if (isFirebaseConfigured && db) {
      const doubtsSnap = await getDocs(collection(db, 'doubts'));
      doubtsSnap.forEach(doc => {
        const data = doc.data() as Record<string, unknown>;
        const id = (data.id || data.questionId || data.doubtId || doc.id) as string;
        const authorId = (data.userId || data.authorId || '') as string;
        doubtsMap.set(id, {
          questionId: id,
          authorId,
          title: (data.title || 'Untitled Doubt') as string,
          description: (data.description || '') as string,
          subjectId: (data.subjectId || 'general') as string,
          subjectName: (data.subjectName || 'General') as string,
          imageUrl: (data.imageUrl || '') as string,
          isAnonymous: Boolean(data.isAnonymous),
          createdAt: (data.createdAt || new Date().toISOString()) as string,
          status: (data.status || 'open') as 'open' | 'resolved' | 'closed',
          views: Number(data.views || 0),
          upvotes: Number(data.upvotes || 0),
          answerCount: Number(data.answerCount || 0),
          acceptedAnswerId: data.acceptedAnswerId as string | undefined,
        });
      });
    }
  } catch (err) {
    console.warn('Could not read from /doubts collection:', err);
  }

  try {
    const questions = await getQuestions({});
    questions.forEach(q => {
      if (!doubtsMap.has(q.questionId)) {
        doubtsMap.set(q.questionId, q);
      }
    });
  } catch (err) {
    console.warn('Could not read from questions collection:', err);
  }

  // 3. Fetch real answers from /answers
  try {
    allReplies = await getAllAnswers();
  } catch (err) {
    console.warn('Could not fetch all answers:', err);
    allReplies = getLocalAnswers();
  }

  return processAnalytics(userProfiles, Array.from(doubtsMap.values()), allReplies);
}
