import {
  doc,
  getDoc,
  setDoc,
  deleteDoc,
  updateDoc,
  collection,
  getDocs,
  query,
  where,
  increment,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { createNotification } from './notificationService';
import {
  getLocalUserVotes,
  saveLocalUserVote,
  getLocalQuestions,
  saveLocalQuestions,
  getLocalAnswers,
  saveLocalAnswers,
} from './localFallback';

export async function toggleQuestionVote(
  questionId: string,
  userId: string,
  authorId?: string,
  questionTitle?: string
): Promise<{ hasVoted: boolean; newCountChange: number }> {
  // Update local memory / storage immediately
  const localVotes = getLocalUserVotes();
  const currentVoted = !!localVotes[questionId];
  const newVoted = !currentVoted;
  saveLocalUserVote(questionId, newVoted);

  const questions = getLocalQuestions();
  const qIndex = questions.findIndex(q => q.questionId === questionId);
  if (qIndex >= 0) {
    questions[qIndex] = {
      ...questions[qIndex],
      upvotes: Math.max(0, (questions[qIndex].upvotes || 0) + (newVoted ? 1 : -1)),
    };
    saveLocalQuestions(questions);
  }

  if (!isFirebaseConfigured || !db) {
    return { hasVoted: newVoted, newCountChange: newVoted ? 1 : -1 };
  }

  const voteId = `${questionId}_${userId}`;
  const voteRef = doc(db, 'questionVotes', voteId);
  const questionRef = doc(db, 'questions', questionId);

  try {
    const voteSnap = await getDoc(voteRef);

    if (voteSnap.exists()) {
      await deleteDoc(voteRef);
      await updateDoc(questionRef, {
        upvotes: increment(-1),
      });
      return { hasVoted: false, newCountChange: -1 };
    } else {
      await setDoc(voteRef, {
        voteId,
        questionId,
        userId,
        createdAt: new Date().toISOString(),
      });
      await updateDoc(questionRef, {
        upvotes: increment(1),
      });

      if (authorId && authorId !== userId) {
        try {
          await createNotification({
            recipientId: authorId,
            type: 'upvote',
            title: 'Question upvoted! 👍',
            message: `A student found your question helpful: "${questionTitle || 'Doubt'}"`,
            linkQuestionId: questionId,
          });
        } catch {
          // Non-blocking
        }
      }

      return { hasVoted: true, newCountChange: 1 };
    }
  } catch (error) {
    console.warn('Could not sync question vote to Firestore, handled locally:', error);
    return { hasVoted: newVoted, newCountChange: newVoted ? 1 : -1 };
  }
}

export async function toggleAnswerVote(
  answerId: string,
  questionId: string,
  userId: string,
  answerAuthorId?: string
): Promise<{ hasVoted: boolean; newCountChange: number }> {
  // Update local memory / storage immediately
  const localVotes = getLocalUserVotes();
  const currentVoted = !!localVotes[answerId];
  const newVoted = !currentVoted;
  saveLocalUserVote(answerId, newVoted);

  const answers = getLocalAnswers();
  const aIndex = answers.findIndex(a => a.answerId === answerId);
  if (aIndex >= 0) {
    answers[aIndex] = {
      ...answers[aIndex],
      upvotes: Math.max(0, (answers[aIndex].upvotes || 0) + (newVoted ? 1 : -1)),
    };
    saveLocalAnswers(answers);
  }

  if (!isFirebaseConfigured || !db) {
    return { hasVoted: newVoted, newCountChange: newVoted ? 1 : -1 };
  }

  const voteId = `${answerId}_${userId}`;
  const voteRef = doc(db, 'answerVotes', voteId);
  const answerRef = doc(db, 'answers', answerId);

  try {
    const voteSnap = await getDoc(voteRef);

    if (voteSnap.exists()) {
      await deleteDoc(voteRef);
      await updateDoc(answerRef, {
        upvotes: increment(-1),
      });
      return { hasVoted: false, newCountChange: -1 };
    } else {
      await setDoc(voteRef, {
        voteId,
        answerId,
        userId,
        createdAt: new Date().toISOString(),
      });
      await updateDoc(answerRef, {
        upvotes: increment(1),
      });

      if (answerAuthorId && answerAuthorId !== userId) {
        try {
          await createNotification({
            recipientId: answerAuthorId,
            type: 'upvote',
            title: 'Answer upvoted! 👍',
            message: 'Your answer received an upvote from a student.',
            linkQuestionId: questionId,
          });
        } catch {
          // Non-blocking
        }
      }

      return { hasVoted: true, newCountChange: 1 };
    }
  } catch (error) {
    console.warn('Could not sync answer vote to Firestore, handled locally:', error);
    return { hasVoted: newVoted, newCountChange: newVoted ? 1 : -1 };
  }
}

export async function getUserVotedQuestionIds(userId: string): Promise<Set<string>> {
  const localVotes = getLocalUserVotes();
  const set = new Set<string>();
  Object.keys(localVotes).forEach(k => {
    if (k.startsWith('q_') && localVotes[k]) {
      set.add(k);
    }
  });

  if (!isFirebaseConfigured || !db || !userId) return set;

  try {
    const q = query(collection(db, 'questionVotes'), where('userId', '==', userId));
    const snap = await getDocs(q);
    snap.docs.forEach(docSnap => {
      const data = docSnap.data();
      if (data.questionId) set.add(data.questionId);
    });
    return set;
  } catch (error) {
    console.warn('Failed to load user question votes from Firestore, using local cache:', error);
    return set;
  }
}

export async function getUserVotedAnswerIds(userId: string): Promise<Set<string>> {
  const localVotes = getLocalUserVotes();
  const set = new Set<string>();
  Object.keys(localVotes).forEach(k => {
    if (k.startsWith('ans_') && localVotes[k]) {
      set.add(k);
    }
  });

  if (!isFirebaseConfigured || !db || !userId) return set;

  try {
    const q = query(collection(db, 'answerVotes'), where('userId', '==', userId));
    const snap = await getDocs(q);
    snap.docs.forEach(docSnap => {
      const data = docSnap.data();
      if (data.answerId) set.add(data.answerId);
    });
    return set;
  } catch (error) {
    console.warn('Failed to load user answer votes from Firestore, using local cache:', error);
    return set;
  }
}
