import {
  collection,
  doc,
  setDoc,
  query,
  where,
  orderBy,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { QuizResult } from '../types';

const LOCAL_QUIZ_RESULTS_KEY = 'student_quiz_results';

function getLocalQuizResults(): QuizResult[] {
  try {
    const raw = localStorage.getItem(LOCAL_QUIZ_RESULTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveLocalQuizResults(results: QuizResult[]) {
  try {
    localStorage.setItem(LOCAL_QUIZ_RESULTS_KEY, JSON.stringify(results));
  } catch {}
}

export async function saveQuizResult(result: QuizResult): Promise<void> {
  const local = getLocalQuizResults();
  local.unshift(result);
  saveLocalQuizResults(local);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'quizResults', result.resultId), result);
    } catch (e) {
      console.warn('Could not save quiz result to Firestore:', e);
    }
  }
}

export function subscribeToUserQuizResults(
  userId: string,
  onData: (results: QuizResult[]) => void
): () => void {
  if (!isFirebaseConfigured || !db || !userId) {
    const local = getLocalQuizResults().filter(r => r.userId === userId);
    onData(local);
    return () => {};
  }

  const q = query(
    collection(db, 'quizResults'),
    where('userId', '==', userId)
  );

  return onSnapshot(
    q,
    snapshot => {
      const results = snapshot.docs.map(d => d.data() as QuizResult);
      results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onData(results);
      saveLocalQuizResults(results);
    },
    err => {
      console.warn('subscribeToUserQuizResults error:', err);
      onData(getLocalQuizResults().filter(r => r.userId === userId));
    }
  );
}

export interface TopicPerformance {
  topic: string;
  subject: string;
  totalAttempts: number;
  averageScore: number;
  status: 'weak' | 'moderate' | 'strong';
}

export function computeTopicBreakdown(results: QuizResult[]): TopicPerformance[] {
  const topicMap = new Map<string, { subject: string; scores: number[] }>();

  results.forEach(r => {
    const key = `${r.subject}:::${r.topic}`;
    const existing = topicMap.get(key) || { subject: r.subject, scores: [] };
    existing.scores.push(r.scorePercentage);
    topicMap.set(key, existing);
  });

  const performances: TopicPerformance[] = [];

  topicMap.forEach((val, key) => {
    const topic = key.split(':::')[1];
    const avg = Math.round(val.scores.reduce((a, b) => a + b, 0) / val.scores.length);
    let status: 'weak' | 'moderate' | 'strong' = 'moderate';
    if (avg < 60) status = 'weak';
    else if (avg >= 80) status = 'strong';

    performances.push({
      topic,
      subject: val.subject,
      totalAttempts: val.scores.length,
      averageScore: avg,
      status,
    });
  });

  return performances.sort((a, b) => a.averageScore - b.averageScore);
}
