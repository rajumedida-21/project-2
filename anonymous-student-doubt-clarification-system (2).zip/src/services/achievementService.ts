import {
  collection,
  doc,
  setDoc,
  query,
  where,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { UserAchievement } from '../types';

export interface BadgeDefinition {
  badgeId: string;
  title: string;
  description: string;
  icon: string;
  category: 'doubts' | 'answers' | 'quizzes' | 'streak' | 'planner';
}

export const ALL_BADGES: BadgeDefinition[] = [
  {
    badgeId: 'first-doubt',
    title: 'Curious Inquirer',
    description: 'Asked your first academic doubt anonymously.',
    icon: 'HelpCircle',
    category: 'doubts',
  },
  {
    badgeId: 'first-answer',
    title: 'Peer Supporter',
    description: 'Answered a classmate’s doubt to help them understand.',
    icon: 'MessageSquare',
    category: 'answers',
  },
  {
    badgeId: 'first-quiz',
    title: 'Quiz Starter',
    description: 'Completed your first AI-generated academic quiz.',
    icon: 'Brain',
    category: 'quizzes',
  },
  {
    badgeId: 'streak-7',
    title: '7-Day Scholar',
    description: 'Maintained an unbroken 7-day study and learning streak.',
    icon: 'Flame',
    category: 'streak',
  },
  {
    badgeId: 'quiz-10',
    title: 'Test Master',
    description: 'Completed 10 academic quizzes to reinforce core concepts.',
    icon: 'Award',
    category: 'quizzes',
  },
  {
    badgeId: 'helpful-student',
    title: 'Helpful Mind',
    description: 'Received helpful upvotes or had an answer accepted as solution.',
    icon: 'CheckCircle2',
    category: 'answers',
  },
  {
    badgeId: 'study-master',
    title: 'Strategic Planner',
    description: 'Completed 10 or more structured tasks in the Study Planner.',
    icon: 'Calendar',
    category: 'planner',
  },
];

const LOCAL_ACHIEVEMENTS_KEY = 'student_unlocked_achievements';

function getLocalAchievements(): UserAchievement[] {
  try {
    const raw = localStorage.getItem(LOCAL_ACHIEVEMENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveLocalAchievements(list: UserAchievement[]) {
  try {
    localStorage.setItem(LOCAL_ACHIEVEMENTS_KEY, JSON.stringify(list));
  } catch {}
}

export async function unlockAchievement(
  userId: string,
  badgeId: string
): Promise<UserAchievement | null> {
  const badge = ALL_BADGES.find(b => b.badgeId === badgeId);
  if (!badge || !userId) return null;

  const local = getLocalAchievements();
  if (local.some(a => a.userId === userId && a.badgeId === badgeId)) {
    return null; // Already unlocked
  }

  const id = `ach_${userId}_${badgeId}`;
  const achievement: UserAchievement = {
    id,
    userId,
    badgeId,
    title: badge.title,
    description: badge.description,
    icon: badge.icon,
    category: badge.category,
    unlockedAt: new Date().toISOString(),
  };

  local.push(achievement);
  saveLocalAchievements(local);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'achievements', id), achievement);
    } catch (e) {
      console.warn('Could not save achievement to Firestore:', e);
    }
  }

  return achievement;
}

export function subscribeToAchievements(
  userId: string,
  onData: (achievements: UserAchievement[]) => void
): () => void {
  if (!isFirebaseConfigured || !db || !userId) {
    onData(getLocalAchievements().filter(a => a.userId === userId));
    return () => {};
  }

  const q = query(collection(db, 'achievements'), where('userId', '==', userId));

  return onSnapshot(
    q,
    snapshot => {
      const list = snapshot.docs.map(d => d.data() as UserAchievement);
      onData(list);
      saveLocalAchievements(list);
    },
    err => {
      console.warn('subscribeToAchievements error:', err);
      onData(getLocalAchievements().filter(a => a.userId === userId));
    }
  );
}

/**
 * Checks all metrics and unlocks any badges earned
 */
export async function evaluateStudentAchievements(
  userId: string,
  stats: {
    doubtsCount: number;
    answersCount: number;
    quizzesCount: number;
    completedTasksCount: number;
    currentStreak: number;
    hasAcceptedAnswer?: boolean;
    totalUpvotes?: number;
  }
): Promise<UserAchievement[]> {
  if (!userId) return [];

  const newlyUnlocked: UserAchievement[] = [];

  if (stats.doubtsCount >= 1) {
    const res = await unlockAchievement(userId, 'first-doubt');
    if (res) newlyUnlocked.push(res);
  }
  if (stats.answersCount >= 1) {
    const res = await unlockAchievement(userId, 'first-answer');
    if (res) newlyUnlocked.push(res);
  }
  if (stats.quizzesCount >= 1) {
    const res = await unlockAchievement(userId, 'first-quiz');
    if (res) newlyUnlocked.push(res);
  }
  if (stats.currentStreak >= 7) {
    const res = await unlockAchievement(userId, 'streak-7');
    if (res) newlyUnlocked.push(res);
  }
  if (stats.quizzesCount >= 10) {
    const res = await unlockAchievement(userId, 'quiz-10');
    if (res) newlyUnlocked.push(res);
  }
  if (stats.hasAcceptedAnswer || (stats.totalUpvotes && stats.totalUpvotes >= 5)) {
    const res = await unlockAchievement(userId, 'helpful-student');
    if (res) newlyUnlocked.push(res);
  }
  if (stats.completedTasksCount >= 10) {
    const res = await unlockAchievement(userId, 'study-master');
    if (res) newlyUnlocked.push(res);
  }

  return newlyUnlocked;
}
