import {
  collection,
  doc,
  setDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  increment,
  onSnapshot,
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { Answer, UserRole } from '../types';
import { createNotification } from './notificationService';
import { setQuestionAcceptedAnswer } from './questionService';
import {
  getLocalAnswers,
  addLocalAnswer,
  saveLocalAnswers,
} from './localFallback';

export interface CreateAnswerInput {
  questionId: string;
  questionTitle?: string;
  questionAuthorId?: string;
  content?: string;
  answerText?: string;
  imageUrl?: string;
  authorId?: string;
  isAnonymous?: boolean;
  isMentor?: boolean;
  mentorSpecialization?: string;
  mentorName?: string;
  authorRole?: UserRole;
  user?: {
    uid: string;
    role: UserRole;
    isVerifiedMentor?: boolean;
    subjectSpecialization?: string;
    name?: string;
  };
}

function sortAnswers(answers: Answer[]): Answer[] {
  return [...answers].sort((a, b) => {
    if (a.isAccepted && !b.isAccepted) return -1;
    if (!a.isAccepted && b.isAccepted) return 1;
    if (b.upvotes !== a.upvotes) return b.upvotes - a.upvotes;
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });
}

export async function createAnswer(input: CreateAnswerInput): Promise<Answer> {
  const answerId = 'ans_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();

  const authorId = input.authorId || input.user?.uid || '';
  const authorRole: UserRole = input.authorRole || input.user?.role || (input.isMentor ? 'mentor' : 'student');
  const isVerifiedMentor = Boolean(
    input.isMentor || (input.user?.isVerifiedMentor && input.user?.role === 'mentor')
  );
  const mentorSpecialization = input.mentorSpecialization || input.user?.subjectSpecialization;
  const mentorName = input.mentorName || (isVerifiedMentor ? input.user?.name : undefined);
  const finalAnswerText = (input.content || input.answerText || '').trim();

  const newAnswer: Answer = {
    answerId,
    questionId: input.questionId,
    authorId,
    authorRole,
    isVerifiedMentor,
    mentorSpecialization,
    mentorName,
    answerText: finalAnswerText,
    imageUrl: input.imageUrl || '',
    isAnonymous: input.isAnonymous ?? !isVerifiedMentor,
    createdAt: now,
    upvotes: 0,
    isAccepted: false,
  };

  // Always store locally first
  addLocalAnswer(newAnswer);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'answers', answerId), newAnswer);

      // Increment question's answerCount
      try {
        await updateDoc(doc(db, 'questions', input.questionId), {
          answerCount: increment(1),
          updatedAt: now,
        });
      } catch {
        // Non-blocking
      }

      // Notify question owner if it's someone else answering
      if (input.questionAuthorId && input.questionAuthorId !== authorId) {
        try {
          await createNotification({
            recipientId: input.questionAuthorId,
            type: 'answer',
            title: 'New answer received',
            message: `${newAnswer.isVerifiedMentor ? 'A Verified Mentor' : 'A peer'} answered your question: "${input.questionTitle || 'Academic Doubt'}"`,
            linkQuestionId: input.questionId,
          });
        } catch {
          // Non-blocking
        }
      }
    } catch (error) {
      console.warn('Could not sync answer to Firestore, stored locally:', error);
    }
  }

  return newAnswer;
}

export async function getAnswersForQuestion(questionId: string): Promise<Answer[]> {
  const localList = getLocalAnswers(questionId);

  if (!isFirebaseConfigured || !db) return sortAnswers(localList);

  const path = 'answers';
  try {
    const q = query(collection(db, path), where('questionId', '==', questionId));
    const snap = await getDocs(q);
    if (snap.empty) {
      return sortAnswers(localList);
    }
    const remoteAnswers = snap.docs.map(docSnap => docSnap.data() as Answer);
    const remoteIds = new Set(remoteAnswers.map(a => a.answerId));

    const combined = [...remoteAnswers];
    for (const la of localList) {
      if (!remoteIds.has(la.answerId)) {
        combined.push(la);
      }
    }

    return sortAnswers(combined);
  } catch (error) {
    console.warn('Could not fetch answers from Firestore, using local cache:', error);
    return sortAnswers(localList);
  }
}

export function subscribeToAnswers(
  questionId: string,
  onData: (answers: Answer[]) => void,
  onError?: (err: unknown) => void
) {
  const localList = getLocalAnswers(questionId);

  if (!isFirebaseConfigured || !db) {
    onData(sortAnswers(localList));
    return () => {};
  }

  const path = 'answers';
  const q = query(collection(db, path), where('questionId', '==', questionId));

  return onSnapshot(
    q,
    snapshot => {
      const remoteAnswers = snapshot.docs.map(docSnap => docSnap.data() as Answer);
      const remoteIds = new Set(remoteAnswers.map(a => a.answerId));
      const combined = [...remoteAnswers];
      for (const la of localList) {
        if (!remoteIds.has(la.answerId)) {
          combined.push(la);
        }
      }
      onData(sortAnswers(combined));
    },
    error => {
      console.warn('Error in subscribeToAnswers, using local cache:', error);
      if (onError) onError(error);
      onData(sortAnswers(localList));
    }
  );
}

export async function acceptAnswer(
  questionId: string,
  answerId: string,
  _authorId?: string
): Promise<void> {
  const answers = getLocalAnswers();
  const idx = answers.findIndex(a => a.answerId === answerId);
  if (idx >= 0) {
    answers[idx] = { ...answers[idx], isAccepted: true, updatedAt: new Date().toISOString() };
    saveLocalAnswers(answers);
  }
  await setQuestionAcceptedAnswer(questionId, answerId);

  if (isFirebaseConfigured && db) {
    try {
      await updateDoc(doc(db, 'answers', answerId), {
        isAccepted: true,
        updatedAt: new Date().toISOString(),
      });
    } catch (e) {
      console.warn('Could not accept answer on Firestore:', e);
    }
  }
}

export async function toggleAcceptAnswer(
  questionId: string,
  answer: Answer,
  questionTitle?: string
): Promise<boolean> {
  const newAcceptedState = !answer.isAccepted;
  const answers = getLocalAnswers();
  const idx = answers.findIndex(a => a.answerId === answer.answerId);
  if (idx >= 0) {
    answers[idx] = { ...answers[idx], isAccepted: newAcceptedState, updatedAt: new Date().toISOString() };
    saveLocalAnswers(answers);
  }
  await setQuestionAcceptedAnswer(questionId, newAcceptedState ? answer.answerId : undefined);

  if (isFirebaseConfigured && db) {
    try {
      await updateDoc(doc(db, 'answers', answer.answerId), {
        isAccepted: newAcceptedState,
        updatedAt: new Date().toISOString(),
      });

      if (newAcceptedState && answer.authorId) {
        try {
          await createNotification({
            recipientId: answer.authorId,
            type: 'accepted',
            title: 'Answer accepted! 🎉',
            message: `Your answer was marked as the accepted solution for: "${questionTitle || 'Question'}"`,
            linkQuestionId: questionId,
          });
        } catch {
          // Non-blocking
        }
      }
    } catch (e) {
      console.warn('Could not toggle answer acceptance on Firestore:', e);
    }
  }

  return newAcceptedState;
}

export async function deleteAnswer(answerId: string, questionId?: string): Promise<void> {
  const answers = getLocalAnswers().filter(a => a.answerId !== answerId);
  saveLocalAnswers(answers);

  if (isFirebaseConfigured && db) {
    try {
      await deleteDoc(doc(db, 'answers', answerId));
      if (questionId) {
        try {
          await updateDoc(doc(db, 'questions', questionId), {
            answerCount: increment(-1),
          });
        } catch {
          // Non-blocking
        }
      }
    } catch (e) {
      console.warn('Could not delete answer on Firestore:', e);
    }
  }
}

export async function getAnswersByUser(userId: string): Promise<Answer[]> {
  return getAnswersByAuthor(userId);
}

export async function getAnswersByAuthor(authorId: string): Promise<Answer[]> {
  const localList = getLocalAnswers().filter(a => a.authorId === authorId);

  if (!isFirebaseConfigured || !db) return localList;

  try {
    const q = query(collection(db, 'answers'), where('authorId', '==', authorId));
    const snap = await getDocs(q);
    if (snap.empty) return localList;
    const results = snap.docs.map(d => d.data() as Answer);
    results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return results;
  } catch {
    return localList;
  }
}

export async function getAllAnswers(): Promise<Answer[]> {
  const localList = getLocalAnswers();

  if (!isFirebaseConfigured || !db) return localList;

  try {
    const q = query(collection(db, 'answers'));
    const snap = await getDocs(q);
    if (snap.empty) return localList;
    const remoteAnswers = snap.docs.map(d => d.data() as Answer);
    const remoteIds = new Set(remoteAnswers.map(a => a.answerId));
    const combined = [...remoteAnswers];
    for (const la of localList) {
      if (!remoteIds.has(la.answerId)) {
        combined.push(la);
      }
    }
    return combined;
  } catch (err) {
    console.warn('Could not fetch all answers from Firestore, using local fallback:', err);
    return localList;
  }
}
