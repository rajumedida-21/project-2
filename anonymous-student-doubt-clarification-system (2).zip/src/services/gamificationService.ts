import { StudentGamificationData, LeaderboardEntry } from '../types';

const GAMIFICATION_KEY = 'anondoubt_gamification_v1';

export interface BadgeDefinition {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'doubts' | 'answers' | 'quizzes' | 'study' | 'streak';
}

export const ALL_BADGES: BadgeDefinition[] = [
  {
    id: 'first_doubt',
    name: 'First Inquiry',
    description: 'Asked your first anonymous academic doubt.',
    icon: '💡',
    category: 'doubts',
  },
  {
    id: 'curious_mind',
    name: 'Curious Mind',
    description: 'Asked 5 or more academic doubts.',
    icon: '🔍',
    category: 'doubts',
  },
  {
    id: 'helpful_peer',
    name: 'Helpful Peer',
    description: 'Provided peer answers to help classmates.',
    icon: '🤝',
    category: 'answers',
  },
  {
    id: 'top_contributor',
    name: 'Master Explainer',
    description: 'Had answers upvoted or verified by peers/faculty.',
    icon: '🏆',
    category: 'answers',
  },
  {
    id: 'quiz_ace',
    name: 'Quiz Champion',
    description: 'Scored 85% or higher on a concept quiz.',
    icon: '🎯',
    category: 'quizzes',
  },
  {
    id: 'flashcard_pro',
    name: 'Spaced Recall Pro',
    description: 'Reviewed 15+ smart flashcards.',
    icon: '📇',
    category: 'study',
  },
  {
    id: 'streak_flame_3',
    name: '3-Day Momentum',
    description: 'Maintained a 3-day continuous learning streak.',
    icon: '🔥',
    category: 'streak',
  },
  {
    id: 'deep_focus',
    name: 'Deep Focus Pioneer',
    description: 'Completed a 30+ minute distraction-free study session.',
    icon: '⏱️',
    category: 'study',
  },
  {
    id: 'multilingual_learner',
    name: 'Multilingual Scholar',
    description: 'Learned in Telugu or Hindi with Voice AI.',
    icon: '🌐',
    category: 'study',
  },
];

export function getLevelTitle(level: number): string {
  if (level <= 1) return 'Novice Scholar';
  if (level === 2) return 'Inquisitive Learner';
  if (level === 3) return 'Dedicated Student';
  if (level === 4) return 'Concept Builder';
  if (level === 5) return 'Academic Explorer';
  if (level === 6) return 'Knowledge Specialist';
  if (level === 7) return 'Peer Mentor';
  if (level === 8) return 'Master Inquirer';
  if (level === 9) return 'Distinguished Fellow';
  return 'Polymath Scholar';
}

export function getLevelFromXP(xp: number): number {
  return Math.max(1, Math.floor(Math.sqrt(xp / 40)) + 1);
}

export function getXPForNextLevel(currentLevel: number): { currentLevelXP: number; nextLevelXP: number; progressPercent: number } {
  const currentLevelXP = (currentLevel - 1) ** 2 * 40;
  const nextLevelXP = currentLevel ** 2 * 40;
  return {
    currentLevelXP,
    nextLevelXP,
    progressPercent: 0,
  };
}

const DEFAULT_GAMIFICATION: StudentGamificationData = {
  userId: 'local_student',
  xp: 185,
  level: 3,
  streak: 3,
  badges: ['first_doubt', 'streak_flame_3', 'quiz_ace'],
  doubtsAskedCount: 4,
  answersGivenCount: 3,
  helpfulAnswersCount: 2,
  quizzesCompletedCount: 3,
  flashcardsReviewedCount: 12,
  totalStudyMinutes: 75,
};

export function getGamificationData(): StudentGamificationData {
  try {
    const raw = localStorage.getItem(GAMIFICATION_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_GAMIFICATION, ...parsed };
    }
  } catch (e) {
    console.warn('Error reading gamification data:', e);
  }
  return DEFAULT_GAMIFICATION;
}

export function saveGamificationData(data: StudentGamificationData): void {
  try {
    localStorage.setItem(GAMIFICATION_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('Error saving gamification data:', e);
  }
}

export function addXP(amount: number, reason?: string): { newXP: number; newLevel: number; leveledUp: boolean; newBadges: string[] } {
  const current = getGamificationData();
  const oldLevel = current.level;
  const newXP = current.xp + amount;
  const newLevel = getLevelFromXP(newXP);
  const leveledUp = newLevel > oldLevel;

  const currentBadges = new Set(current.badges);
  const newlyUnlocked: string[] = [];

  // Check badge conditions
  if (current.doubtsAskedCount >= 1 && !currentBadges.has('first_doubt')) {
    currentBadges.add('first_doubt');
    newlyUnlocked.push('first_doubt');
  }
  if (current.doubtsAskedCount >= 5 && !currentBadges.has('curious_mind')) {
    currentBadges.add('curious_mind');
    newlyUnlocked.push('curious_mind');
  }
  if (current.answersGivenCount >= 1 && !currentBadges.has('helpful_peer')) {
    currentBadges.add('helpful_peer');
    newlyUnlocked.push('helpful_peer');
  }
  if (current.helpfulAnswersCount >= 2 && !currentBadges.has('top_contributor')) {
    currentBadges.add('top_contributor');
    newlyUnlocked.push('top_contributor');
  }
  if (current.streak >= 3 && !currentBadges.has('streak_flame_3')) {
    currentBadges.add('streak_flame_3');
    newlyUnlocked.push('streak_flame_3');
  }
  if (current.flashcardsReviewedCount >= 15 && !currentBadges.has('flashcard_pro')) {
    currentBadges.add('flashcard_pro');
    newlyUnlocked.push('flashcard_pro');
  }
  if (current.totalStudyMinutes >= 30 && !currentBadges.has('deep_focus')) {
    currentBadges.add('deep_focus');
    newlyUnlocked.push('deep_focus');
  }

  const updated: StudentGamificationData = {
    ...current,
    xp: newXP,
    level: newLevel,
    badges: Array.from(currentBadges),
  };

  saveGamificationData(updated);

  return {
    newXP,
    newLevel,
    leveledUp,
    newBadges: newlyUnlocked,
  };
}

export function recordActivityEvent(event: {
  type: 'doubt_asked' | 'answer_given' | 'answer_helpful' | 'quiz_completed' | 'flashcard_reviewed' | 'study_session' | 'multilingual';
  value?: number; // e.g. quiz score or study minutes
}) {
  const current = getGamificationData();
  let xpGain = 10;

  switch (event.type) {
    case 'doubt_asked':
      current.doubtsAskedCount += 1;
      xpGain = 15;
      break;
    case 'answer_given':
      current.answersGivenCount += 1;
      xpGain = 25;
      break;
    case 'answer_helpful':
      current.helpfulAnswersCount += 1;
      xpGain = 50;
      break;
    case 'quiz_completed':
      current.quizzesCompletedCount += 1;
      const score = event.value || 70;
      xpGain = 30 + Math.round(score * 0.4);
      if (score >= 85 && !current.badges.includes('quiz_ace')) {
        current.badges.push('quiz_ace');
      }
      break;
    case 'flashcard_reviewed':
      current.flashcardsReviewedCount += 1;
      xpGain = 5;
      break;
    case 'study_session':
      const mins = event.value || 25;
      current.totalStudyMinutes += mins;
      xpGain = 20 + Math.round(mins * 0.5);
      break;
    case 'multilingual':
      if (!current.badges.includes('multilingual_learner')) {
        current.badges.push('multilingual_learner');
      }
      xpGain = 20;
      break;
  }

  saveGamificationData(current);
  return addXP(xpGain);
}

export function getLeaderboard(): LeaderboardEntry[] {
  const user = getGamificationData();

  const peerScholars: LeaderboardEntry[] = [
    {
      userId: 'peer_1',
      displayName: 'QuantumThinker #409',
      isAnonymous: true,
      xp: 420,
      level: 4,
      streak: 7,
      helpfulAnswers: 8,
      acceptedAnswers: 5,
      quizzesCompleted: 9,
      rank: 1,
    },
    {
      userId: 'peer_2',
      displayName: 'AlgorithmicMind #88',
      isAnonymous: true,
      xp: 360,
      level: 3,
      streak: 5,
      helpfulAnswers: 6,
      acceptedAnswers: 4,
      quizzesCompleted: 7,
      rank: 2,
    },
    {
      userId: 'local_student',
      displayName: 'You (Anonymous Student)',
      isAnonymous: true,
      xp: user.xp,
      level: user.level,
      streak: user.streak,
      helpfulAnswers: user.helpfulAnswersCount,
      acceptedAnswers: Math.floor(user.helpfulAnswersCount / 2),
      quizzesCompleted: user.quizzesCompletedCount,
      rank: 3,
    },
    {
      userId: 'peer_3',
      displayName: 'ByteScholar #12',
      isAnonymous: true,
      xp: 170,
      level: 2,
      streak: 2,
      helpfulAnswers: 3,
      acceptedAnswers: 1,
      quizzesCompleted: 4,
      rank: 4,
    },
    {
      userId: 'peer_4',
      displayName: 'DataPioneer #901',
      isAnonymous: true,
      xp: 140,
      level: 2,
      streak: 3,
      helpfulAnswers: 2,
      acceptedAnswers: 1,
      quizzesCompleted: 3,
      rank: 5,
    },
    {
      userId: 'peer_5',
      displayName: 'LogicSeeker #55',
      isAnonymous: true,
      xp: 95,
      level: 1,
      streak: 1,
      helpfulAnswers: 1,
      acceptedAnswers: 0,
      quizzesCompleted: 2,
      rank: 6,
    }
  ];

  // Re-rank dynamically based on XP
  return peerScholars
    .sort((a, b) => b.xp - a.xp)
    .map((item, index) => ({ ...item, rank: index + 1 }));
}
