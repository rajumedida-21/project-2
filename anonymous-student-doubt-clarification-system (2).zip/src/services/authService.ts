import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, isFirebaseConfigured } from '../firebase/firebaseConfig';
import { UserProfile, UserRole } from '../types';
import { handleFirestoreError, OperationType } from './firestoreError';

export interface RegisterData {
  name: string;
  email: string;
  password: string;
  role: 'student' | 'mentor';
  subjectSpecialization?: string;
}

export function mapFirebaseAuthError(error: unknown): string {
  if (typeof error === 'object' && error !== null && 'code' in error) {
    const code = (error as { code: string }).code;
    switch (code) {
      case 'auth/email-already-in-use':
        return 'An account already exists with this email address.';
      case 'auth/invalid-email':
        return 'Please enter a valid email address.';
      case 'auth/weak-password':
        return 'Password should be at least 6 characters long.';
      case 'auth/user-not-found':
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
        return 'Invalid email or password. Please try again.';
      case 'auth/too-many-requests':
        return 'Access to this account has been temporarily disabled due to many failed login attempts. Reset your password or try later.';
      case 'auth/network-request-failed':
        return 'Network connection failed. Please check your internet connection.';
      default:
        return (error as { message?: string }).message || 'Authentication failed. Please try again.';
    }
  }
  return error instanceof Error ? error.message : 'An unexpected error occurred.';
}

export async function registerUser(data: RegisterData): Promise<UserProfile> {
  if (!isFirebaseConfigured || !auth || !db) {
    throw new Error('Firebase is not configured. Please add your credentials in .env or the setup panel.');
  }

  // 1. Create auth user
  const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
  const fbUser = userCredential.user;

  // 2. Set display name in Auth
  await updateProfile(fbUser, {
    displayName: data.name,
  });

  // 3. Prevent self-admin registration
  const safeRole: UserRole = data.role === 'mentor' ? 'mentor' : 'student';

  const userProfile: UserProfile = {
    uid: fbUser.uid,
    name: data.name.trim(),
    email: data.email.trim().toLowerCase(),
    role: safeRole,
    createdAt: new Date().toISOString(),
    isVerifiedMentor: false, // Must be verified by Admin
    subjectSpecialization: data.subjectSpecialization?.trim() || '',
  };

  const userRef = doc(db, 'users', fbUser.uid);
  try {
    await setDoc(userRef, {
      ...userProfile,
      serverCreatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `users/${fbUser.uid}`);
  }

  return userProfile;
}

export async function loginUser(email: string, password: string): Promise<UserProfile> {
  if (!isFirebaseConfigured || !auth || !db) {
    throw new Error('Firebase is not configured. Please configure Firebase credentials.');
  }

  const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
  const fbUser = userCredential.user;

  // Fetch user profile from Firestore
  return await fetchUserProfile(fbUser.uid, fbUser);
}

export async function fetchUserProfile(uid: string, fbUser?: FirebaseUser | null): Promise<UserProfile> {
  const email = fbUser?.email || '';
  const isAdminEmail = email === 'rajumedida41@gmail.com' || email === 'vandanraju6@gmail.com' || email.includes('admin');

  const fallbackProfile: UserProfile = {
    uid,
    name: fbUser?.displayName || email.split('@')[0] || 'Student',
    email,
    role: isAdminEmail ? 'admin' : 'student',
    createdAt: new Date().toISOString(),
    isVerifiedMentor: false,
  };

  if (!db) {
    return fallbackProfile;
  }

  const userRef = doc(db, 'users', uid);
  try {
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    
    // Auto-bootstrap profile if missing in Firestore
    try {
      await setDoc(userRef, fallbackProfile);
    } catch {
      // Non-blocking write
    }
    return fallbackProfile;
  } catch (error) {
    console.warn('Could not read user profile from Firestore, using auth profile:', error);
    return fallbackProfile;
  }
}

export async function logoutUser(): Promise<void> {
  if (auth) {
    await firebaseSignOut(auth);
  }
}

export async function resetUserPassword(email: string): Promise<void> {
  if (!auth) {
    throw new Error('Authentication is not initialized.');
  }
  await sendPasswordResetEmail(auth, email.trim());
}

export function subscribeToAuthChanges(callback: (user: FirebaseUser | null) => void) {
  if (!auth) {
    callback(null);
    return () => {};
  }
  return onAuthStateChanged(auth, callback);
}
