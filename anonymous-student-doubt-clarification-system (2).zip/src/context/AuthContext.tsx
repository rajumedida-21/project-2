import React, { createContext, useContext, useEffect, useState } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { UserProfile, UserRole } from '../types';
import {
  loginUser,
  registerUser,
  logoutUser,
  resetUserPassword,
  fetchUserProfile,
  subscribeToAuthChanges,
  RegisterData,
} from '../services/authService';
import { isFirebaseConfigured, auth } from '../firebase/firebaseConfig';

interface AuthContextType {
  currentUser: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  isConfigured: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  refreshProfile: () => Promise<void>;
  demoLogin: (role: UserRole) => void;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'register' | 'forgot';
  openAuthModal: (mode?: 'login' | 'register' | 'forgot') => void;
  closeAuthModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_USER_KEY = 'doubt_demo_user';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot'>('login');

  // Check for demo user session if not in Firebase
  const checkDemoUser = (): UserProfile | null => {
    try {
      const saved = sessionStorage.getItem(DEMO_USER_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return null;
  };

  useEffect(() => {
    if (!isFirebaseConfigured || !auth) {
      const demo = checkDemoUser();
      if (demo) {
        setCurrentUser(demo);
      }
      setLoading(false);
      return;
    }

    const unsubscribe = subscribeToAuthChanges(async fbUser => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        try {
          const profile = await fetchUserProfile(fbUser.uid, fbUser);
          setCurrentUser(profile);
        } catch (error) {
          console.error('Error fetching user profile:', error);
          // Graceful fallback to avoid locking user out
          setCurrentUser({
            uid: fbUser.uid,
            name: fbUser.displayName || 'Student',
            email: fbUser.email || '',
            role: (fbUser.email === 'rajumedida41@gmail.com' || fbUser.email === 'vandanraju6@gmail.com' || fbUser.email?.includes('admin')) ? 'admin' : 'student',
            createdAt: new Date().toISOString(),
            isVerifiedMentor: false,
          });
        }
      } else {
        const demo = checkDemoUser();
        setCurrentUser(demo);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    sessionStorage.removeItem(DEMO_USER_KEY);
    const profile = await loginUser(email, pass);
    setCurrentUser(profile);
  };

  const register = async (data: RegisterData) => {
    sessionStorage.removeItem(DEMO_USER_KEY);
    const profile = await registerUser(data);
    setCurrentUser(profile);
  };

  const logout = async () => {
    sessionStorage.removeItem(DEMO_USER_KEY);
    await logoutUser();
    setCurrentUser(null);
    setFirebaseUser(null);
  };

  const resetPassword = async (email: string) => {
    await resetUserPassword(email);
  };

  const refreshProfile = async () => {
    if (firebaseUser) {
      const profile = await fetchUserProfile(firebaseUser.uid, firebaseUser);
      setCurrentUser(profile);
    }
  };

  const demoLogin = (role: UserRole) => {
    const demoProfiles: Record<UserRole, UserProfile> = {
      student: {
        uid: 'demo_student_01',
        name: 'Alex Chen',
        email: 'student@college.edu',
        role: 'student',
        createdAt: new Date().toISOString(),
        isVerifiedMentor: false,
        subjectSpecialization: 'Computer Science',
      },
      mentor: {
        uid: 'demo_mentor_01',
        name: 'Dr. Sarah Mitchell',
        email: 's.mitchell@college.edu',
        role: 'mentor',
        createdAt: new Date().toISOString(),
        isVerifiedMentor: true,
        subjectSpecialization: 'Data Structures & Algorithms',
        bio: 'Assistant Professor in Computer Science with 8+ years experience.',
      },
      admin: {
        uid: 'demo_admin_01',
        name: 'Admin Moderator',
        email: 'rajumedida41@gmail.com',
        role: 'admin',
        createdAt: new Date().toISOString(),
        isVerifiedMentor: true,
      },
    };

    const chosen = demoProfiles[role];
    sessionStorage.setItem(DEMO_USER_KEY, JSON.stringify(chosen));
    setCurrentUser(chosen);
    setIsAuthModalOpen(false);
  };

  const openAuthModal = (mode: 'login' | 'register' | 'forgot' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        firebaseUser,
        loading,
        isConfigured: isFirebaseConfigured,
        login,
        register,
        logout,
        resetPassword,
        refreshProfile,
        demoLogin,
        isAuthModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
