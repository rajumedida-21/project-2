import React, { createContext, useContext, useState, useEffect } from 'react';
import { SupportedLanguage, UserSettings } from '../types';

interface StudentProfile {
  displayName: string;
  avatarSeed: string;
  primarySubject: string;
  targetExam: string;
  dailyStudyGoalMinutes: number;
}

interface SettingsContextType {
  settings: UserSettings;
  profile: StudentProfile;
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  updateNotificationSettings: (notifications: Partial<UserSettings['notifications']>) => void;
  updatePrivacySettings: (privacy: Partial<UserSettings['privacy']>) => void;
  updateProfile: (newProfile: Partial<StudentProfile>) => void;
}

const DEFAULT_SETTINGS: UserSettings = {
  theme: 'system',
  defaultLanguage: 'English',
  voiceEnabled: true,
  autoSpeechRate: 1.0,
  speechPitch: 1.0,
  notifications: {
    studyReminders: true,
    communityAnswers: true,
    quizReminders: true,
    revisionReminders: true,
    aiRecommendations: true,
  },
  privacy: {
    anonymousByDefault: true,
    showOnLeaderboard: true,
    showStreakPublicly: true,
  },
};

const DEFAULT_PROFILE: StudentProfile = {
  displayName: 'Anonymous Scholar',
  avatarSeed: 'scholar_1',
  primarySubject: 'Computer Science & Engineering',
  targetExam: 'Semester Finals 2026',
  dailyStudyGoalMinutes: 60,
};

const SETTINGS_STORAGE_KEY = 'anondoubt_user_settings_v1';
const PROFILE_STORAGE_KEY = 'anondoubt_student_profile_v1';

const SettingsContext = createContext<SettingsContextType>({
  settings: DEFAULT_SETTINGS,
  profile: DEFAULT_PROFILE,
  updateSettings: () => {},
  updateNotificationSettings: () => {},
  updatePrivacySettings: () => {},
  updateProfile: () => {},
});

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettingsState] = useState<UserSettings>(() => {
    try {
      const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return { ...DEFAULT_SETTINGS, ...parsed, notifications: { ...DEFAULT_SETTINGS.notifications, ...(parsed.notifications || {}) }, privacy: { ...DEFAULT_SETTINGS.privacy, ...(parsed.privacy || {}) } };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_SETTINGS;
  });

  const [profile, setProfileState] = useState<StudentProfile>(() => {
    try {
      const raw = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (raw) {
        return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_PROFILE;
  });

  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch (e) {
      console.warn('Could not save settings:', e);
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.warn('Could not save profile:', e);
    }
  }, [profile]);

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettingsState(prev => ({ ...prev, ...newSettings }));
  };

  const updateNotificationSettings = (notifications: Partial<UserSettings['notifications']>) => {
    setSettingsState(prev => ({
      ...prev,
      notifications: { ...prev.notifications, ...notifications },
    }));
  };

  const updatePrivacySettings = (privacy: Partial<UserSettings['privacy']>) => {
    setSettingsState(prev => ({
      ...prev,
      privacy: { ...prev.privacy, ...privacy },
    }));
  };

  const updateProfile = (newProfile: Partial<StudentProfile>) => {
    setProfileState(prev => ({ ...prev, ...newProfile }));
  };

  return (
    <SettingsContext.Provider
      value={{
        settings,
        profile,
        updateSettings,
        updateNotificationSettings,
        updatePrivacySettings,
        updateProfile,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => useContext(SettingsContext);
