import React from 'react';
import { Bell, CheckCheck, Trash2, X, MessageSquare, ThumbsUp, CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';
import { useNotifications } from '../context/NotificationContext';
import { formatRelativeTime } from '../utils/dateUtils';

interface NotificationDrawerProps {
  onSelectQuestion: (questionId: string) => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ onSelectQuestion }) => {
  const { notifications, unreadCount, markAsRead, markAllAsRead, removeNotification, isOpen, setIsOpen } =
    useNotifications();

  if (!isOpen) return null;

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'answer':
        return <MessageSquare className="w-4 h-4 text-indigo-600" />;
      case 'upvote':
        return <ThumbsUp className="w-4 h-4 text-emerald-600" />;
      case 'accepted':
        return <CheckCircle className="w-4 h-4 text-amber-600" />;
      case 'report':
        return <AlertCircle className="w-4 h-4 text-rose-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div
      id="notification-drawer-overlay"
      className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex justify-end"
      onClick={() => setIsOpen(false)}
    >
      <div
        id="notification-drawer"
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">Notifications</h3>
            {unreadCount > 0 && (
              <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full font-semibold">
                {unreadCount} new
              </span>
            )}
          </div>
          <div className="flex items-center gap-1">
            {notifications.length > 0 && unreadCount > 0 && (
              <button
                id="mark-all-read-btn"
                onClick={() => markAllAsRead()}
                className="text-xs text-indigo-600 hover:text-indigo-700 font-medium px-2 py-1 rounded hover:bg-indigo-50 transition-colors flex items-center gap-1 cursor-pointer"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark all read</span>
              </button>
            )}
            <button
              id="close-notifications-btn"
              onClick={() => setIsOpen(false)}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {notifications.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <Bell className="w-10 h-10 stroke-1 mb-2 text-slate-300" />
              <p className="text-sm font-medium text-slate-600">No notifications yet</p>
              <p className="text-xs text-slate-400 mt-1">
                You will be notified when someone answers your questions or upvotes your explanations.
              </p>
            </div>
          ) : (
            notifications.map(item => (
              <div
                key={item.notificationId}
                id={`notification-item-${item.notificationId}`}
                onClick={() => {
                  if (!item.isRead) markAsRead(item.notificationId);
                  if (item.linkQuestionId) {
                    onSelectQuestion(item.linkQuestionId);
                    setIsOpen(false);
                  }
                }}
                className={`p-3 rounded-xl border transition-all cursor-pointer relative group ${
                  item.isRead
                    ? 'bg-white border-slate-200/70 hover:border-slate-300'
                    : 'bg-indigo-50/40 border-indigo-200/80 hover:bg-indigo-50/60'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-white rounded-lg border border-slate-100 shadow-2xs shrink-0 mt-0.5">
                    {getTypeIcon(item.type)}
                  </div>
                  <div className="flex-1 min-w-0 pr-6">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h4 className="text-xs font-semibold text-slate-900 truncate">{item.title}</h4>
                      {!item.isRead && <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 shrink-0" />}
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{item.message}</p>
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      {formatRelativeTime(item.createdAt)}
                    </span>
                  </div>
                </div>

                <button
                  id={`delete-notif-${item.notificationId}`}
                  onClick={e => {
                    e.stopPropagation();
                    removeNotification(item.notificationId);
                  }}
                  className="absolute top-3 right-3 text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity p-1"
                  title="Remove notification"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
