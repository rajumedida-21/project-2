import React, { useState } from 'react';
import { Sparkles, Bot, Check, Copy, ChevronDown, ChevronUp, AlertCircle, RefreshCw } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { askAIForQuestion } from '../services/questionService';

interface AIDoubtCardAnswerProps {
  questionId: string;
  questionTitle: string;
  questionDescription: string;
  subjectName?: string;
  existingAIExplanation?: string;
  imageUrl?: string;
}

export const AIDoubtCardAnswer: React.FC<AIDoubtCardAnswerProps> = ({
  questionId,
  questionTitle,
  questionDescription,
  subjectName,
  existingAIExplanation,
  imageUrl,
}) => {
  const [explanation, setExplanation] = useState<string | null>(existingAIExplanation || null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(Boolean(existingAIExplanation));
  const [copied, setCopied] = useState(false);

  const handleAskAI = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setLoading(true);
    setError(null);
    setIsExpanded(true);

    try {
      const reply = await askAIForQuestion(
        questionId,
        questionTitle,
        questionDescription,
        subjectName,
        imageUrl
      );
      setExplanation(reply);
    } catch (err: any) {
      setError(err?.message || 'AI explanation could not be generated. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!explanation) return;
    navigator.clipboard.writeText(explanation);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      id={`ai-doubt-assistant-section-${questionId}`}
      className="mt-4 rounded-xl border border-indigo-100 bg-linear-to-b from-indigo-50/40 via-white to-white overflow-hidden shadow-2xs"
    >
      {/* Header bar */}
      <div className="px-4 py-3 bg-linear-to-r from-indigo-600/10 via-purple-600/5 to-transparent flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-2xs">
            <Bot className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-bold text-indigo-950">AI Assistant</span>
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">
                <Sparkles className="w-2.5 h-2.5" />
                Teaching Tutor
              </span>
              {imageUrl && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">
                  📷 Multimodal Vision
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!explanation && !loading ? (
            <button
              type="button"
              id={`ask-ai-doubt-btn-${questionId}`}
              onClick={handleAskAI}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs transition-transform active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI</span>
            </button>
          ) : (
            <>
              {explanation && (
                <>
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="p-1 text-slate-500 hover:text-indigo-600 rounded transition-colors text-[11px] inline-flex items-center gap-1 cursor-pointer"
                    title="Copy AI explanation"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span className="hidden sm:inline">{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleAskAI}
                    disabled={loading}
                    className="p-1 text-slate-500 hover:text-indigo-600 rounded transition-colors text-[11px] inline-flex items-center gap-1 cursor-pointer"
                    title="Regenerate explanation"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                    <span className="hidden sm:inline">Refresh</span>
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
                className="p-1 text-slate-500 hover:text-indigo-600 rounded transition-colors cursor-pointer"
                title={isExpanded ? 'Collapse' : 'Expand'}
              >
                {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Content body */}
      {isExpanded && (
        <div className="p-4 border-t border-indigo-50">
          {loading ? (
            <div className="py-6 flex flex-col items-center justify-center gap-3 text-slate-500">
              <div className="relative">
                <div className="w-8 h-8 rounded-full border-2 border-indigo-600/30 border-t-indigo-600 animate-spin" />
                <Sparkles className="w-3.5 h-3.5 text-indigo-600 absolute inset-0 m-auto" />
              </div>
              <p className="text-xs font-medium text-slate-600 animate-pulse">
                AI Assistant is analyzing this doubt and structuring a step-by-step academic explanation...
              </p>
            </div>
          ) : error ? (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2 text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold">Unable to fetch AI explanation</p>
                <p>{error}</p>
                <button
                  type="button"
                  onClick={handleAskAI}
                  className="text-rose-800 underline font-semibold hover:text-rose-900 cursor-pointer pt-1 block"
                >
                  Try again
                </button>
              </div>
            </div>
          ) : explanation ? (
            <div className="prose prose-xs sm:prose-sm max-w-none text-slate-800 leading-relaxed space-y-2">
              <div className="markdown-body">
                <ReactMarkdown>{explanation}</ReactMarkdown>
              </div>
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>🤖 Generated by Academic AI Assistant • Verified teaching format</span>
                <span>Identity protected</span>
              </div>
            </div>
          ) : (
            <div className="text-center py-4 text-xs text-slate-500">
              Click &quot;Ask AI&quot; above to receive a teaching-oriented conceptual breakdown of this doubt.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
