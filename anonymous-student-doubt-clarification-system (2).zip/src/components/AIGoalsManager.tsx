import React, { useState, useEffect } from 'react';
import {
  Target,
  Plus,
  CheckCircle2,
  Circle,
  Clock,
  Sparkles,
  Bot,
  Trash2,
  ChevronRight,
  ArrowRight,
  Play,
} from 'lucide-react';
import { AILearningGoal } from '../types';
import {
  getAILearningGoals,
  toggleGoalTask,
  addAILearningGoal,
  deleteAILearningGoal,
} from '../services/adaptiveService';
import { breakDownAILearningGoal } from '../services/aiService';

interface AIGoalsManagerProps {
  onStartFocusSession?: (topic: string, subject: string, minutes: number) => void;
  onAskTutor?: (topic: string) => void;
}

export const AIGoalsManager: React.FC<AIGoalsManagerProps> = ({
  onStartFocusSession,
  onAskTutor,
}) => {
  const [goals, setGoals] = useState<AILearningGoal[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [goalTitle, setGoalTitle] = useState('');
  const [goalSubject, setGoalSubject] = useState('Computer Science');
  const [targetDate, setTargetDate] = useState('2 weeks');
  const [currentLevel, setCurrentLevel] = useState('Intermediate');
  const [isAiDeconstructing, setIsAiDeconstructing] = useState(false);

  const refreshGoals = () => {
    setGoals(getAILearningGoals());
  };

  useEffect(() => {
    refreshGoals();
  }, []);

  const handleToggleTask = (goalId: string, taskId: string) => {
    toggleGoalTask(goalId, taskId);
    refreshGoals();
  };

  const handleDeleteGoal = (goalId: string) => {
    if (confirm('Delete this learning goal?')) {
      deleteAILearningGoal(goalId);
      refreshGoals();
    }
  };

  const handleCreateGoalWithAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle.trim()) return;

    setIsAiDeconstructing(true);
    try {
      const breakdown = await breakDownAILearningGoal({
        goalTitle: goalTitle.trim(),
        subject: goalSubject,
        targetDate,
        currentLevel,
      });

      addAILearningGoal({
        userId: 'local_student',
        title: goalTitle.trim(),
        subject: goalSubject,
        targetDate,
        tasks: breakdown.tasks.map(t => ({
          id: t.id || `task_${Date.now()}_${Math.random()}`,
          title: t.title,
          completed: false,
          estimatedMinutes: t.estimatedMinutes || 25,
        })),
        suggestedNextStep: breakdown.suggestedNextStep || `Start with the first milestone: ${breakdown.tasks[0]?.title}`,
      });

      setGoalTitle('');
      setIsCreating(false);
      refreshGoals();
    } catch (err: any) {
      alert(err.message || 'Failed to break down goal with AI.');
    } finally {
      setIsAiDeconstructing(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">AI Goal Deconstruction & Mastery</h3>
            <p className="text-xs text-slate-500">
              Set high-level learning targets and let AI break them into focused micro-milestones.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsCreating(!isCreating)}
          className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New AI Goal</span>
        </button>
      </div>

      {/* Creation form */}
      {isCreating && (
        <form
          onSubmit={handleCreateGoalWithAI}
          className="bg-slate-50 rounded-2xl p-5 border border-indigo-200/80 space-y-4 animate-in fade-in"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              AI Intelligent Goal Breakdown
            </span>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="text-xs text-slate-400 hover:text-slate-700"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Learning Target / Exam Goal
              </label>
              <input
                type="text"
                value={goalTitle}
                onChange={e => setGoalTitle(e.target.value)}
                placeholder="e.g. Master Graph Algorithms, Pass Operating Systems Mid-Sem..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Subject</label>
              <input
                type="text"
                value={goalSubject}
                onChange={e => setGoalSubject(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Target Timeline
              </label>
              <select
                value={targetDate}
                onChange={e => setTargetDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="1 week">1 Week Sprint</option>
                <option value="2 weeks">2 Weeks</option>
                <option value="1 month">1 Month</option>
                <option value="Semester End">Final Exams</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Current Grasp Level
              </label>
              <select
                value={currentLevel}
                onChange={e => setCurrentLevel(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="Beginner">Beginner (Starting from scratch)</option>
                <option value="Intermediate">Intermediate (Know basics)</option>
                <option value="Exam Revision">Exam Revision (Quick mastery)</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={isAiDeconstructing || !goalTitle.trim()}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            {isAiDeconstructing ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>AI is structuring micro-milestones...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Deconstruct Goal with AI</span>
              </>
            )}
          </button>
        </form>
      )}

      {/* Goals list */}
      <div className="space-y-4">
        {goals.map(goal => (
          <div
            key={goal.id}
            className="border border-slate-200 rounded-2xl p-5 space-y-4 hover:border-slate-300 transition-colors"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md">
                    {goal.subject}
                  </span>
                  <span className="text-xs text-slate-400">Target: {goal.targetDate}</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900">{goal.title}</h4>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-indigo-600">
                  {goal.progressPercentage}%
                </span>
                <button
                  type="button"
                  onClick={() => handleDeleteGoal(goal.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                  title="Delete goal"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div
                className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${goal.progressPercentage}%` }}
              />
            </div>

            {/* Subtasks checklist */}
            <div className="space-y-2 pt-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Micro-Milestone Checklist ({goal.tasks.filter(t => t.completed).length}/{goal.tasks.length})
              </span>
              <div className="space-y-1.5">
                {goal.tasks.map(task => (
                  <div
                    key={task.id}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-colors ${
                      task.completed
                        ? 'bg-slate-50/80 border-slate-200 text-slate-400 line-through'
                        : 'bg-white border-slate-200 text-slate-800 hover:border-indigo-200'
                    }`}
                  >
                    <div
                      onClick={() => handleToggleTask(goal.id, task.id)}
                      className="flex items-center gap-2.5 flex-1 min-w-0 cursor-pointer select-none"
                    >
                      {task.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-300 hover:text-indigo-600 shrink-0" />
                      )}
                      <span className="text-xs font-medium truncate">{task.title}</span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {task.estimatedMinutes}m
                      </span>
                      {!task.completed && onStartFocusSession && (
                        <button
                          type="button"
                          onClick={() =>
                            onStartFocusSession(task.title, goal.subject, task.estimatedMinutes)
                          }
                          className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                          title="Start Pomodoro Focus"
                        >
                          <Play className="w-2.5 h-2.5 fill-current" />
                          <span>Focus</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Next Recommended Step */}
            {goal.suggestedNextStep && (
              <div className="bg-indigo-50/70 border border-indigo-100 rounded-xl p-3 flex items-center justify-between text-xs text-indigo-900 gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span className="font-medium">{goal.suggestedNextStep}</span>
                </div>
                {onAskTutor && (
                  <button
                    type="button"
                    onClick={() => onAskTutor(`I am working on my goal "${goal.title}". Can you guide me through: ${goal.suggestedNextStep}`)}
                    className="text-xs font-bold text-indigo-700 hover:underline shrink-0 flex items-center gap-1"
                  >
                    <span>Ask Tutor</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
