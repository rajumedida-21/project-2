import React from 'react';
import { Subject } from '../types';

interface SubjectPillsProps {
  subjects: Subject[];
  selectedSubjectId: string;
  onSelectSubject: (id: string) => void;
}

export const SubjectPills: React.FC<SubjectPillsProps> = ({
  subjects,
  selectedSubjectId,
  onSelectSubject,
}) => {
  return (
    <div className="w-full overflow-x-auto no-scrollbar py-2">
      <div className="flex items-center gap-2 min-w-max">
        <button
          id="subject-pill-all"
          type="button"
          onClick={() => onSelectSubject('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
            selectedSubjectId === 'all'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          All Topics
        </button>

        {subjects.map(s => {
          const isSelected = selectedSubjectId === s.subjectId;
          return (
            <button
              key={s.subjectId}
              id={`subject-pill-${s.subjectId}`}
              type="button"
              onClick={() => onSelectSubject(s.subjectId)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                  : 'bg-white text-slate-700 hover:bg-indigo-50/60 hover:text-indigo-600 border border-slate-200/80'
              }`}
            >
              {s.name}
            </button>
          );
        })}
      </div>
    </div>
  );
};
