import React from 'react';
import { CheckCircle2, Award } from 'lucide-react';

interface MentorBadgeProps {
  specialization?: string;
  size?: 'sm' | 'md' | 'lg';
  showSpecialization?: boolean;
}

export const MentorBadge: React.FC<MentorBadgeProps> = ({
  specialization,
  size = 'md',
  showSpecialization = true,
}) => {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };

  return (
    <div className="inline-flex items-center flex-wrap gap-1.5">
      <span
        id="verified-mentor-badge"
        className={`inline-flex items-center font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/80 rounded-full shadow-xs ${sizeClasses[size]}`}
        title="Verified Academic Mentor / Teacher"
      >
        <CheckCircle2 className={size === 'sm' ? 'w-3 h-3 text-emerald-600' : 'w-3.5 h-3.5 text-emerald-600'} />
        <span>Verified Mentor</span>
      </span>
      {showSpecialization && specialization && (
        <span
          id="mentor-specialization-badge"
          className="inline-flex items-center text-xs font-normal text-slate-500 bg-slate-100 border border-slate-200/70 px-2 py-0.5 rounded-md"
        >
          <Award className="w-3 h-3 mr-1 text-slate-400" />
          {specialization}
        </span>
      )}
    </div>
  );
};
