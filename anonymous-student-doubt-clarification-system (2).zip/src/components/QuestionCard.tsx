import React, { useState } from 'react';
import { MessageSquare, ThumbsUp, Eye, CheckCircle2, Shield, User, Image as ImageIcon, Flag, Sparkles } from 'lucide-react';
import { Question } from '../types';
import { formatRelativeTime } from '../utils/dateUtils';
import { toggleQuestionVote } from '../services/voteService';
import { useAuth } from '../context/AuthContext';
import { AIDoubtCardAnswer } from './AIDoubtCardAnswer';

interface QuestionCardProps {
  question: Question;
  hasUpvoted?: boolean;
  onOpenQuestion: (questionId: string) => void;
  onOpenReport?: (question: Question) => void;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  hasUpvoted: initialHasUpvoted = false,
  onOpenQuestion,
  onOpenReport,
}) => {
  const { currentUser, openAuthModal } = useAuth();
  const [upvotes, setUpvotes] = useState(question.upvotes || 0);
  const [hasUpvoted, setHasUpvoted] = useState(initialHasUpvoted);
  const [voting, setVoting] = useState(false);
  const [showAIExplanation, setShowAIExplanation] = useState(Boolean(question.aiExplanation));

  const handleUpvote = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) {
      openAuthModal('login');
      return;
    }
    if (voting) return;

    setVoting(true);
    // Optimistic update
    const nextState = !hasUpvoted;
    setHasUpvoted(nextState);
    setUpvotes(prev => prev + (nextState ? 1 : -1));

    try {
      const res = await toggleQuestionVote(
        question.questionId,
        currentUser.uid,
        question.authorId,
        question.title
      );
      setHasUpvoted(res.hasVoted);
    } catch (err) {
      // Revert on error
      console.error('Vote failed:', err);
      setHasUpvoted(!nextState);
      setUpvotes(prev => prev + (nextState ? -1 : 1));
    } finally {
      setVoting(false);
    }
  };

  const isResolved = Boolean(question.acceptedAnswerId || question.status === 'resolved');

  return (
    <article
      id={`question-card-${question.questionId}`}
      onClick={() => onOpenQuestion(question.questionId)}
      className="bg-white rounded-2xl p-5 border border-slate-200/90 hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
    >
      <div>
        {/* Author Header & Subject Tag */}
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500 shadow-2xs">
              <User className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-slate-800">
                  {question.isAnonymous ? 'Anonymous Student' : 'Anonymous Student'}
                </span>
                <span title="Anonymous Student Identity Protected" className="text-indigo-600">
                  <Shield className="w-3 h-3" />
                </span>
              </div>
              <span className="text-[11px] text-slate-400 block">
                {formatRelativeTime(question.createdAt)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {isResolved && (
              <span
                id="resolved-pill"
                className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-semibold px-2 py-0.5 rounded-full"
                title="This doubt has a verified accepted answer"
              >
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                <span className="hidden sm:inline">Solved</span>
              </span>
            )}
            <span className="text-[11px] font-medium bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-md border border-slate-200/80">
              {question.subjectName || question.subjectId}
            </span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-2 mb-2">
          {question.title}
        </h3>

        {/* Description Snippet */}
        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-3">
          {question.description}
        </p>

        {/* Image indicator if attachment exists */}
        {question.imageUrl && (
          <div className="mb-3 flex items-center gap-1 text-[11px] text-indigo-600 font-medium">
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Contains visual diagram / attachment</span>
          </div>
        )}
      </div>

      {/* Footer Metrics */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-3">
          <button
            type="button"
            id={`upvote-question-btn-${question.questionId}`}
            onClick={handleUpvote}
            disabled={voting}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
              hasUpvoted
                ? 'bg-indigo-50 text-indigo-600 font-semibold ring-1 ring-indigo-300'
                : 'hover:bg-slate-100 text-slate-600'
            }`}
            title="Upvote this question"
          >
            <ThumbsUp className={`w-3.5 h-3.5 ${hasUpvoted ? 'fill-indigo-600 text-indigo-600' : ''}`} />
            <span>{upvotes}</span>
          </button>

          <span className="flex items-center gap-1 text-slate-600">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{question.answerCount || 0} answers</span>
          </span>

          <span className="hidden sm:flex items-center gap-1 text-slate-400">
            <Eye className="w-3.5 h-3.5" />
            <span>{question.views || 0}</span>
          </span>

          <button
            type="button"
            id={`card-ask-ai-btn-${question.questionId}`}
            onClick={e => {
              e.stopPropagation();
              setShowAIExplanation(prev => !prev);
            }}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              showAIExplanation || question.aiExplanation
                ? 'bg-purple-50 text-purple-700 ring-1 ring-purple-300'
                : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700'
            }`}
            title="Ask AI Assistant for explanation"
          >
            <Sparkles className="w-3 h-3 text-indigo-600" />
            <span>{question.aiExplanation ? 'AI Answer' : 'Ask AI'}</span>
          </button>
        </div>

        {onOpenReport && (
          <button
            type="button"
            id={`report-question-btn-${question.questionId}`}
            onClick={e => {
              e.stopPropagation();
              onOpenReport(question);
            }}
            className="p-1 text-slate-400 hover:text-rose-500 rounded hover:bg-slate-100 transition-colors"
            title="Report this question"
          >
            <Flag className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* AI Assistant Explanation Directly Underneath */}
      {showAIExplanation && (
        <div onClick={e => e.stopPropagation()}>
          <AIDoubtCardAnswer
            questionId={question.questionId}
            questionTitle={question.title}
            questionDescription={question.description}
            subjectName={question.subjectName}
            existingAIExplanation={question.aiExplanation}
            imageUrl={question.imageUrl}
          />
        </div>
      )}
    </article>
  );
};
