import React, { useState } from 'react';
import { Database, AlertTriangle, KeyRound, Check, RefreshCw, X, ExternalLink, ShieldCheck, Copy, CheckCircle2 } from 'lucide-react';
import {
  isFirebaseConfigured,
  activeFirebaseConfig,
  saveStoredFirebaseConfig,
  clearStoredFirebaseConfig,
  getStoredFirebaseConfig,
} from '../firebase/firebaseConfig';

const FIRESTORE_RULES_SNIPPET = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isSignedIn() { return request.auth != null; }
    function isOwner(userId) { return isSignedIn() && request.auth.uid == userId; }
    function isBootstrappedAdmin() {
      return isSignedIn() && (
        request.auth.token.email in ['rajumedida41@gmail.com', 'vandanraju6@gmail.com'] ||
        (request.auth.token.email != null && request.auth.token.email.matches('.*admin.*'))
      );
    }
    function isAdmin() {
      return isBootstrappedAdmin() || (
        isSignedIn() && (
          exists(/databases/$(database)/documents/admins/$(request.auth.uid)) ||
          (exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
           get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin')
        )
      );
    }

    match /users/{userId} {
      allow read: if true;
      allow create, update: if isOwner(userId) || isAdmin();
      allow delete: if isAdmin();
    }
    match /admins/{userId} {
      allow read: if isSignedIn();
      allow write: if isAdmin();
    }
    match /questions/{questionId} {
      allow read: if true;
      allow create, update: if isSignedIn();
      allow delete: if isSignedIn() && (resource.data.authorId == request.auth.uid || isAdmin());
    }
    match /answers/{answerId} {
      allow read: if true;
      allow create, update: if isSignedIn();
      allow delete: if isSignedIn() && (resource.data.authorId == request.auth.uid || isAdmin());
    }
    match /questionVotes/{voteId} {
      allow read, write: if isSignedIn();
    }
    match /answerVotes/{voteId} {
      allow read, write: if isSignedIn();
    }
    match /reports/{reportId} {
      allow read, create: if isSignedIn();
      allow update, delete: if isAdmin();
    }
    match /subjects/{subjectId} {
      allow read: if true;
      allow write: if isSignedIn();
    }
    match /notifications/{notificationId} {
      allow read, write: if isSignedIn();
    }
  }
}`;

export const FirebaseSetupBanner: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'credentials' | 'rules'>('credentials');
  const [copiedRules, setCopiedRules] = useState(false);

  const [apiKey, setApiKey] = useState(activeFirebaseConfig.apiKey || '');
  const [authDomain, setAuthDomain] = useState(activeFirebaseConfig.authDomain || '');
  const [projectId, setProjectId] = useState(activeFirebaseConfig.projectId || '');
  const [storageBucket, setStorageBucket] = useState(activeFirebaseConfig.storageBucket || '');
  const [messagingSenderId, setMessagingSenderId] = useState(activeFirebaseConfig.messagingSenderId || '');
  const [appId, setAppId] = useState(activeFirebaseConfig.appId || '');
  const [appCheckKey, setAppCheckKey] = useState(activeFirebaseConfig.appCheckKey || '6LdmFLQtAAAAAPtbHTcj3NHZZZVZiu17DuDaVoGZ');
  const [rawJson, setRawJson] = useState('');
  const [pasteError, setPasteError] = useState('');

  const hasStoredOverride = Boolean(getStoredFirebaseConfig());

  const handleJsonPaste = (text: string) => {
    setRawJson(text);
    setPasteError('');
    try {
      let clean = text.trim();
      if (clean.startsWith('const firebaseConfig =')) {
        clean = clean.replace('const firebaseConfig =', '').replace(/;$/, '').trim();
      }
      clean = clean.replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":');
      clean = clean.replace(/'/g, '"');
      const parsed = JSON.parse(clean);

      if (parsed.apiKey) setApiKey(parsed.apiKey);
      if (parsed.authDomain) setAuthDomain(parsed.authDomain);
      if (parsed.projectId) setProjectId(parsed.projectId);
      if (parsed.storageBucket) setStorageBucket(parsed.storageBucket);
      if (parsed.messagingSenderId) setMessagingSenderId(parsed.messagingSenderId);
      if (parsed.appId) setAppId(parsed.appId);
      if (parsed.appCheckKey) setAppCheckKey(parsed.appCheckKey);
    } catch {
      setPasteError('Could not auto-parse JSON. Please fill the fields manually below.');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveStoredFirebaseConfig({
      apiKey: apiKey.trim(),
      authDomain: authDomain.trim(),
      projectId: projectId.trim(),
      storageBucket: storageBucket.trim(),
      messagingSenderId: messagingSenderId.trim(),
      appId: appId.trim(),
      appCheckKey: appCheckKey.trim(),
    });
  };

  const copyRulesToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(FIRESTORE_RULES_SNIPPET);
      setCopiedRules(true);
      setTimeout(() => setCopiedRules(false), 2000);
    } catch {
      // fallback
    }
  };

  const currentProj = projectId || activeFirebaseConfig.projectId || 'doubt-14353';

  return (
    <>
      {!isFirebaseConfigured && (
        <div
          id="firebase-status-banner"
          className="bg-amber-500/10 border-b border-amber-500/20 text-amber-900 px-4 py-2.5 text-xs sm:text-sm font-medium flex items-center justify-between gap-3 transition-all"
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Firebase Setup:</strong> Running with smart local storage fallback. Questions, answers & votes work seamlessly. Connect your Firebase credentials anytime for cloud sync.
            </span>
          </div>
          <button
            id="open-firebase-config-btn"
            onClick={() => {
              setActiveTab('credentials');
              setIsOpen(true);
            }}
            className="inline-flex items-center gap-1 bg-amber-600 hover:bg-amber-700 text-white text-xs px-3 py-1 rounded-md font-semibold transition-colors shrink-0 shadow-xs cursor-pointer"
          >
            <KeyRound className="w-3.5 h-3.5" />
            Firebase Settings
          </button>
        </div>
      )}

      {/* Floating config badge for quick status check */}
      <button
        id="toggle-firebase-status-modal"
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 z-40 bg-white/95 backdrop-blur-xs hover:bg-slate-50 border border-slate-200 shadow-md text-slate-700 px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-2 cursor-pointer transition-transform hover:scale-105"
        title="Firebase connection status and settings"
      >
        <span
          className={`w-2 h-2 rounded-full ${
            isFirebaseConfigured ? 'bg-emerald-500 ring-2 ring-emerald-200' : 'bg-amber-500 ring-2 ring-amber-200'
          }`}
        />
        <span className="hidden sm:inline">Firebase:</span>
        <span className="font-semibold">{isFirebaseConfigured ? 'Connected' : 'Offline / Local Fallback'}</span>
      </button>

      {/* Configuration Modal */}
      {isOpen && (
        <div
          id="firebase-config-modal-overlay"
          className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
        >
          <div
            id="firebase-config-modal"
            className="bg-white rounded-xl shadow-2xl max-w-xl w-full p-6 border border-slate-200 relative my-8"
          >
            <button
              id="close-firebase-config-btn"
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 mb-2">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Firebase & Database Settings</h3>
                <p className="text-xs text-slate-500">Project: <span className="font-mono font-semibold text-slate-700">{currentProj}</span></p>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-slate-200 mb-4 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('credentials')}
                className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'credentials'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                API Credentials
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('rules')}
                className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'rules'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                Firestore Security Rules & Fix Guide
              </button>
            </div>

            {activeTab === 'credentials' ? (
              <>
                <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                  The app automatically switches between live Firebase Firestore and local persistent storage if connection or permissions are pending.
                </p>

                {/* Quick Paste Area */}
                <div className="mb-4">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Quick Paste (from Firebase Console SDK snippet):
                  </label>
                  <textarea
                    id="firebase-raw-paste-input"
                    rows={2}
                    placeholder={`const firebaseConfig = {\n  apiKey: "AIzaSy...",\n  projectId: "${currentProj}",\n  appId: "1:..."\n};`}
                    value={rawJson}
                    onChange={e => handleJsonPaste(e.target.value)}
                    className="w-full text-xs font-mono p-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                  {pasteError && <p className="text-xs text-amber-600 mt-1">{pasteError}</p>}
                </div>

                {/* Form Fields */}
                <form onSubmit={handleSave} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        VITE_FIREBASE_API_KEY *
                      </label>
                      <input
                        id="input-firebase-api-key"
                        type="text"
                        required
                        value={apiKey}
                        onChange={e => setApiKey(e.target.value)}
                        placeholder="AIzaSy..."
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        VITE_FIREBASE_PROJECT_ID *
                      </label>
                      <input
                        id="input-firebase-project-id"
                        type="text"
                        required
                        value={projectId}
                        onChange={e => setProjectId(e.target.value)}
                        placeholder={currentProj}
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        VITE_FIREBASE_AUTH_DOMAIN
                      </label>
                      <input
                        id="input-firebase-auth-domain"
                        type="text"
                        value={authDomain}
                        onChange={e => setAuthDomain(e.target.value)}
                        placeholder={`${currentProj}.firebaseapp.com`}
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        VITE_FIREBASE_APP_ID *
                      </label>
                      <input
                        id="input-firebase-app-id"
                        type="text"
                        required
                        value={appId}
                        onChange={e => setAppId(e.target.value)}
                        placeholder="1:123456789:web:abcdef"
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-semibold text-slate-700">
                        App Check reCAPTCHA Enterprise Site Key
                      </label>
                      <span className="text-[10px] text-emerald-600 font-medium bg-emerald-50 px-1.5 py-0.5 rounded-sm">Active Protection</span>
                    </div>
                    <input
                      id="input-firebase-appcheck-key"
                      type="text"
                      value={appCheckKey}
                      onChange={e => setAppCheckKey(e.target.value)}
                      placeholder="6LdmFLQtAAAAAPtbHTcj3NHZZZVZiu17DuDaVoGZ"
                      className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-mono"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Protects Firestore database against abuse, bots, and unauthorized clients using reCAPTCHA Enterprise.
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-slate-100 gap-2">
                    {hasStoredOverride ? (
                      <button
                        type="button"
                        id="clear-firebase-config-btn"
                        onClick={clearStoredFirebaseConfig}
                        className="text-xs text-rose-600 hover:text-rose-700 font-medium px-2 py-1 cursor-pointer"
                      >
                        Reset to Environment
                      </button>
                    ) : (
                      <span className="text-xs text-slate-400">Stored safely in browser</span>
                    )}
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setIsOpen(false)}
                        className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                      >
                        Close
                      </button>
                      <button
                        type="submit"
                        id="save-firebase-config-btn"
                        className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Save & Reload
                      </button>
                    </div>
                  </div>
                </form>
              </>
            ) : (
              <div className="space-y-4">
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-700 space-y-2">
                  <p className="font-semibold text-slate-800">
                    If you see &ldquo;Could not reach Cloud Firestore backend&rdquo; or &ldquo;Missing permissions&rdquo;:
                  </p>
                  <ol className="list-decimal list-inside space-y-1 text-slate-600">
                    <li>
                      Go to{' '}
                      <a
                        href={`https://console.firebase.google.com/project/${currentProj}/firestore`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-indigo-600 hover:underline font-medium inline-flex items-center gap-1"
                      >
                        Firebase Console &gt; Firestore Database <ExternalLink className="w-3 h-3" />
                      </a>{' '}
                      and ensure the database is created.
                    </li>
                    <li>
                      Open the <strong>Rules</strong> tab in Firestore console.
                    </li>
                    <li>
                      Copy the rules below, paste them into the editor, and click <strong>Publish</strong>.
                    </li>
                  </ol>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-semibold text-slate-700">Firestore Security Rules</span>
                    <button
                      type="button"
                      onClick={copyRulesToClipboard}
                      className="inline-flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
                    >
                      {copiedRules ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-600">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Rules</span>
                        </>
                      )}
                    </button>
                  </div>
                  <pre className="text-[11px] font-mono bg-slate-900 text-slate-100 p-3 rounded-lg overflow-x-auto max-h-48 leading-relaxed border border-slate-800">
                    {FIRESTORE_RULES_SNIPPET}
                  </pre>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setIsOpen(false)}
                    className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
