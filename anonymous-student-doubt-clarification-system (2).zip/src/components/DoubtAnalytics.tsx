import React, { useState, useEffect, useMemo } from 'react';
import {
  BarChart3,
  Search,
  RefreshCw,
  Filter,
  Users,
  MessageSquare,
  CheckCircle2,
  Clock,
  Award,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  ShieldCheck,
  GraduationCap,
  Sparkles,
  Layers,
  ArrowUpDown,
  Mail,
  UserCheck,
  AlertCircle,
  FileSpreadsheet,
} from 'lucide-react';
import {
  fetchDoubtAnalyticsData,
  subscribeToDoubtAnalytics,
  DoubtAnalyticsData,
  DoubtAnalyticsItem,
  DoubtReplyAnalytics,
} from '../services/analyticsService';
import { formatRelativeTime } from '../utils/dateUtils';
import { MentorBadge } from './MentorBadge';

interface DoubtAnalyticsProps {
  onOpenQuestion?: (questionId: string) => void;
}

export const DoubtAnalytics: React.FC<DoubtAnalyticsProps> = ({ onOpenQuestion }) => {
  const [data, setData] = useState<DoubtAnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'resolved' | 'unresolved' | 'unanswered'>('all');
  const [mentorFilter, setMentorFilter] = useState<'all' | 'with_mentor' | 'no_mentor'>('all');
  const [expandedDoubtId, setExpandedDoubtId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'doubts_table' | 'users_overview'>('doubts_table');
  const [sortField, setSortField] = useState<'createdAt' | 'replies' | 'upvotes' | 'title'>('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  // Real-time live Firestore subscription
  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeToDoubtAnalytics(
      liveData => {
        setData(liveData);
        setLoading(false);
        setRefreshing(false);
      },
      err => {
        console.error('Real-time analytics error:', err);
        setLoading(false);
        setRefreshing(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  const manualRefresh = async () => {
    setRefreshing(true);
    try {
      const res = await fetchDoubtAnalyticsData();
      setData(res);
    } catch (err) {
      console.error('Manual refresh failed:', err);
    } finally {
      setRefreshing(false);
    }
  };

  // Filter and sort items
  const filteredItems = useMemo(() => {
    if (!data) return [];
    let list = [...data.items];

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(item => {
        const titleMatch = item.title.toLowerCase().includes(q);
        const descMatch = item.description.toLowerCase().includes(q);
        const subjectMatch = item.subjectName.toLowerCase().includes(q);
        const studentNameMatch = item.studentName.toLowerCase().includes(q);
        const studentEmailMatch = item.studentEmail.toLowerCase().includes(q);
        const mentorMatch = item.replies.some(
          r => r.replierName.toLowerCase().includes(q) || r.replierEmail.toLowerCase().includes(q)
        );
        return titleMatch || descMatch || subjectMatch || studentNameMatch || studentEmailMatch || mentorMatch;
      });
    }

    // Status filter
    if (statusFilter === 'resolved') {
      list = list.filter(i => i.hasAcceptedReply || i.status === 'resolved');
    } else if (statusFilter === 'unresolved') {
      list = list.filter(i => !i.hasAcceptedReply && i.status !== 'resolved');
    } else if (statusFilter === 'unanswered') {
      list = list.filter(i => i.replyCount === 0);
    }

    // Mentor filter
    if (mentorFilter === 'with_mentor') {
      list = list.filter(i => i.hasMentorReply);
    } else if (mentorFilter === 'no_mentor') {
      list = list.filter(i => !i.hasMentorReply);
    }

    // Sorting
    list.sort((a, b) => {
      let valA: number | string = '';
      let valB: number | string = '';

      if (sortField === 'createdAt') {
        valA = new Date(a.createdAt).getTime();
        valB = new Date(b.createdAt).getTime();
      } else if (sortField === 'replies') {
        valA = a.replyCount;
        valB = b.replyCount;
      } else if (sortField === 'upvotes') {
        valA = a.upvotes;
        valB = b.upvotes;
      } else if (sortField === 'title') {
        valA = a.title.toLowerCase();
        valB = b.title.toLowerCase();
      }

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return list;
  }, [data, searchQuery, statusFilter, mentorFilter, sortField, sortDirection]);

  const toggleSort = (field: 'createdAt' | 'replies' | 'upvotes' | 'title') => {
    if (sortField === field) {
      setSortDirection(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const handleExportCSV = () => {
    if (!filteredItems.length) return;
    const headers = ['Doubt ID', 'Title', 'Subject', 'Student Name', 'Student Email', 'Student Role', 'Is Anonymous Publicly', 'Replies Count', 'Has Mentor Reply', 'Has Accepted Reply', 'Created At'];
    const rows = filteredItems.map(item => [
      `"${item.id}"`,
      `"${item.title.replace(/"/g, '""')}"`,
      `"${item.subjectName}"`,
      `"${item.studentName.replace(/"/g, '""')}"`,
      `"${item.studentEmail}"`,
      `"${item.studentRole}"`,
      item.isAnonymous ? 'Yes' : 'No',
      item.replyCount,
      item.hasMentorReply ? 'Yes' : 'No',
      item.hasAcceptedReply ? 'Yes' : 'No',
      `"${item.createdAt}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `doubt_analytics_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
        <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800">Compiling Doubt Analytics...</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
          Fetching records from <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-600">/users</code>,{' '}
          <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-600">/doubts</code>, and mapping replies.
        </p>
      </div>
    );
  }

  const summary = data?.summary;

  return (
    <div className="space-y-6" id="doubt-analytics-container">
      {/* Top Header & Actions */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                <BarChart3 className="w-4 h-4" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">Doubt Analytics & User Mapping</h2>
              <span className="text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100 px-2 py-0.5 rounded-full">
                Admin Console
              </span>
              <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Live Real-Time Sync
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Cross-referenced overview mapping doubts to registered student profiles and replies from mentors and peers.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              id="doubt-analytics-export-btn"
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl cursor-pointer transition-colors shadow-2xs"
              title="Export filtered dataset to CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Export CSV</span>
            </button>

            <button
              id="doubt-analytics-refresh-btn"
              onClick={manualRefresh}
              disabled={refreshing}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl cursor-pointer transition-colors shadow-2xs disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              <span>{refreshing ? 'Syncing...' : 'Sync Now'}</span>
            </button>
          </div>
        </div>

        {/* Analytics KPI Metric Cards */}
        {summary && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-slate-100">
            <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
              <span className="text-[11px] font-medium text-slate-400 block mb-0.5">Total Doubts</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-slate-900">{summary.totalDoubts}</span>
                <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-1.5 py-0.2 rounded">items</span>
              </div>
            </div>

            <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
              <span className="text-[11px] font-medium text-slate-400 block mb-0.5">Total Users</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-slate-900">{summary.totalUsers}</span>
                <span className="text-[10px] text-slate-500 font-medium">({summary.totalStudents} stud, {summary.totalMentors} ment)</span>
              </div>
            </div>

            <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
              <span className="text-[11px] font-medium text-slate-400 block mb-0.5">Total Replies</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-slate-900">{summary.totalReplies}</span>
                <span className="text-[10px] text-slate-500 font-medium">responses</span>
              </div>
            </div>

            <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
              <span className="text-[11px] font-medium text-slate-400 block mb-0.5">Resolution Rate</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-emerald-600">{summary.resolutionRate}%</span>
                <span className="text-[10px] text-emerald-600 font-medium">({summary.resolvedDoubtsCount} resolved)</span>
              </div>
            </div>

            <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
              <span className="text-[11px] font-medium text-slate-400 block mb-0.5">Mentor Answered</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-indigo-600">{summary.mentorAnsweredCount}</span>
                <span className="text-[10px] text-indigo-600 font-medium">verified</span>
              </div>
            </div>

            <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100">
              <span className="text-[11px] font-medium text-slate-400 block mb-0.5">Unanswered</span>
              <div className="flex items-baseline gap-1.5">
                <span className={`text-2xl font-black ${summary.unansweredDoubtsCount > 0 ? 'text-amber-600' : 'text-slate-900'}`}>
                  {summary.unansweredDoubtsCount}
                </span>
                <span className="text-[10px] text-slate-400 font-medium">pending</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Sub-Tabs: Doubts Table vs Users Directory */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          id="tab-btn-doubts-analytics"
          onClick={() => setActiveTab('doubts_table')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'doubts_table'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Doubts & Replies Mapping ({filteredItems.length})</span>
        </button>

        <button
          id="tab-btn-users-overview"
          onClick={() => setActiveTab('users_overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'users_overview'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Registered Profiles & Roles ({data?.users.length || 0})</span>
        </button>
      </div>

      {activeTab === 'doubts_table' ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {/* Filters Bar */}
          <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                id="analytics-search-input"
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Filter by doubt title, student name, email, or mentor..."
                className="w-full text-xs pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden transition-all placeholder:text-slate-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs">
                <Filter className="w-3 h-3 text-slate-400" />
                <span className="text-[11px] font-semibold text-slate-500">Status:</span>
                <select
                  id="analytics-filter-status"
                  value={statusFilter}
                  onChange={e => setStatusFilter(e.target.value as any)}
                  className="text-xs bg-transparent border-none text-slate-700 font-medium focus:outline-hidden cursor-pointer"
                >
                  <option value="all">All Doubts</option>
                  <option value="resolved">Resolved / Accepted</option>
                  <option value="unresolved">Unresolved / In Progress</option>
                  <option value="unanswered">Unanswered (0 replies)</option>
                </select>
              </div>

              <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs">
                <Award className="w-3 h-3 text-slate-400" />
                <span className="text-[11px] font-semibold text-slate-500">Mentors:</span>
                <select
                  id="analytics-filter-mentor"
                  value={mentorFilter}
                  onChange={e => setMentorFilter(e.target.value as any)}
                  className="text-xs bg-transparent border-none text-slate-700 font-medium focus:outline-hidden cursor-pointer"
                >
                  <option value="all">All Doubts</option>
                  <option value="with_mentor">With Mentor Reply</option>
                  <option value="no_mentor">Awaiting Mentor</option>
                </select>
              </div>
            </div>
          </div>

          {/* Table Container (Horizontal & Vertical Scrollable) */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" id="doubts-analytics-table">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-100/60 text-[11px] font-bold text-slate-600 uppercase tracking-wider select-none">
                  <th
                    className="py-3 px-4 cursor-pointer hover:bg-slate-200/50 transition-colors"
                    onClick={() => toggleSort('title')}
                  >
                    <div className="flex items-center gap-1">
                      <span>Doubt / Question</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Student (Who Asked)</th>
                  <th className="py-3 px-4">Subject</th>
                  <th
                    className="py-3 px-4 cursor-pointer hover:bg-slate-200/50 transition-colors"
                    onClick={() => toggleSort('replies')}
                  >
                    <div className="flex items-center gap-1">
                      <span>Replies & Mentors</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Status</th>
                  <th
                    className="py-3 px-4 cursor-pointer hover:bg-slate-200/50 transition-colors"
                    onClick={() => toggleSort('createdAt')}
                  >
                    <div className="flex items-center gap-1">
                      <span>Asked Date</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th className="py-3 px-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      <AlertCircle className="w-6 h-6 mx-auto mb-2 text-slate-300" />
                      <p className="font-semibold text-slate-600">No matching doubts found</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">Try adjusting your search terms or filters.</p>
                    </td>
                  </tr>
                ) : (
                  filteredItems.map(item => {
                    const isExpanded = expandedDoubtId === item.id;

                    return (
                      <React.Fragment key={item.id}>
                        <tr
                          id={`doubt-row-${item.id}`}
                          className={`hover:bg-indigo-50/30 transition-colors ${
                            isExpanded ? 'bg-indigo-50/40' : ''
                          }`}
                        >
                          {/* Title & snippet */}
                          <td className="py-3.5 px-4 max-w-xs">
                            <div className="font-semibold text-slate-900 line-clamp-1 group flex items-center gap-1.5">
                              <span>{item.title}</span>
                              {item.isAnonymous && (
                                <span
                                  className="text-[10px] font-medium text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded shrink-0"
                                  title="Posted with anonymous shield on the public board"
                                >
                                  Anon Flag
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {item.description}
                            </p>
                          </td>

                          {/* Student Who Asked (Mapped to /users) */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs shrink-0">
                                {item.studentName.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <div className="flex items-center gap-1">
                                  <span className="font-bold text-slate-900 text-xs">
                                    {item.studentName}
                                  </span>
                                  <span className="text-[10px] font-medium text-slate-500 capitalize bg-slate-100 px-1 py-0.2 rounded">
                                    {item.studentRole}
                                  </span>
                                </div>
                                <div className="text-[11px] text-slate-400 font-mono truncate max-w-[150px]">
                                  {item.studentEmail}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Subject */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
                              <Layers className="w-3 h-3 text-indigo-500" />
                              {item.subjectName}
                            </span>
                          </td>

                          {/* Replies & Mentors */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1 font-bold text-slate-800">
                                <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                                <span>{item.replyCount}</span>
                              </div>

                              {item.hasMentorReply && (
                                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                                  <Award className="w-3 h-3 text-emerald-600" />
                                  Mentor
                                </span>
                              )}

                              {item.replyCount === 0 && (
                                <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded font-medium">
                                  Needs answer
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Status */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            {item.hasAcceptedReply ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                Resolved
                              </span>
                            ) : item.replyCount > 0 ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full">
                                In Discussion
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                                Open
                              </span>
                            )}
                          </td>

                          {/* Date */}
                          <td className="py-3.5 px-4 whitespace-nowrap text-[11px] text-slate-500">
                            {formatRelativeTime(item.createdAt)}
                          </td>

                          {/* Actions */}
                          <td className="py-3.5 px-4 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1.5">
                              {onOpenQuestion && (
                                <button
                                  id={`btn-open-doubt-${item.id}`}
                                  onClick={() => onOpenQuestion(item.id)}
                                  className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-lg transition-colors"
                                  title="View Doubt in public feed"
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </button>
                              )}

                              <button
                                id={`btn-toggle-expand-${item.id}`}
                                onClick={() => setExpandedDoubtId(isExpanded ? null : item.id)}
                                className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer ${
                                  isExpanded
                                    ? 'bg-indigo-600 text-white'
                                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                                }`}
                              >
                                <span>{isExpanded ? 'Hide Replies' : `Replies (${item.replyCount})`}</span>
                                {isExpanded ? (
                                  <ChevronUp className="w-3 h-3" />
                                ) : (
                                  <ChevronDown className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                          </td>
                        </tr>

                        {/* Expanded Thread Drawer showing detailed mapping of replies */}
                        {isExpanded && (
                          <tr className="bg-slate-50/70">
                            <td colSpan={7} className="p-4 sm:px-6 sm:py-4">
                              <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-4">
                                {/* Detailed Doubt Metadata */}
                                <div className="border-b border-slate-100 pb-3">
                                  <div className="flex items-center justify-between gap-2 mb-1">
                                    <h4 className="font-bold text-sm text-slate-900">{item.title}</h4>
                                    <span className="text-[10px] font-mono text-slate-400">ID: {item.id}</span>
                                  </div>
                                  <p className="text-xs text-slate-600 whitespace-pre-line leading-relaxed">
                                    {item.description}
                                  </p>

                                  <div className="mt-3 flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                                    <div>
                                      <span className="text-slate-400">Asked by Student: </span>
                                      <strong className="text-slate-800">{item.studentName}</strong> ({item.studentEmail})
                                    </div>
                                    <span className="text-slate-300">•</span>
                                    <div>
                                      <span className="text-slate-400">Student ID: </span>
                                      <code className="text-indigo-600 font-mono text-[10px]">{item.userId || 'unassigned'}</code>
                                    </div>
                                    <span className="text-slate-300">•</span>
                                    <div>
                                      <span className="text-slate-400">Anonymous Flag: </span>
                                      <span className="font-medium text-slate-700">{item.isAnonymous ? 'True (Shielded)' : 'False (Public)'}</span>
                                    </div>
                                  </div>
                                </div>

                                {/* Replies / Answers List */}
                                <div>
                                  <div className="flex items-center justify-between mb-2.5">
                                    <h5 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                                      <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                                      <span>Replies & Mentors Responded ({item.replies.length})</span>
                                    </h5>
                                    {item.hasAcceptedReply && (
                                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                                        ✓ Solution Accepted
                                      </span>
                                    )}
                                  </div>

                                  {item.replies.length === 0 ? (
                                    <div className="py-6 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200 text-slate-400">
                                      <p className="text-xs font-medium">No replies have been recorded for this doubt yet.</p>
                                      <p className="text-[11px] mt-0.5 text-slate-400">
                                        College mentors or peers can reply to this doubt from the main feed.
                                      </p>
                                    </div>
                                  ) : (
                                    <div className="space-y-2.5">
                                      {item.replies.map((reply, idx) => (
                                        <div
                                          key={reply.answerId || idx}
                                          className={`p-3 rounded-xl border text-xs transition-colors ${
                                            reply.isAccepted
                                              ? 'bg-emerald-50/40 border-emerald-200'
                                              : 'bg-slate-50/60 border-slate-200'
                                          }`}
                                        >
                                          <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                                            <div className="flex items-center gap-2">
                                              <div className="w-6 h-6 rounded-md bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-[10px]">
                                                {reply.replierName.charAt(0).toUpperCase()}
                                              </div>
                                              <div>
                                                <div className="flex items-center gap-1.5">
                                                  <span className="font-bold text-slate-900 text-xs">
                                                    {reply.replierName}
                                                  </span>
                                                  {reply.isVerifiedMentor ? (
                                                    <span className="text-[9px] font-semibold text-emerald-700 bg-emerald-100 px-1 py-0.2 rounded flex items-center gap-0.5">
                                                      <Award className="w-2.5 h-2.5" />
                                                      Verified Mentor
                                                    </span>
                                                  ) : (
                                                    <span className="text-[9px] font-medium text-slate-600 bg-slate-200 px-1 py-0.2 rounded capitalize">
                                                      {reply.replierRole}
                                                    </span>
                                                  )}
                                                </div>
                                                <span className="text-[10px] text-slate-400 font-mono">
                                                  {reply.replierEmail} • ID: {reply.authorId}
                                                </span>
                                              </div>
                                            </div>

                                            <div className="flex items-center gap-2 text-[11px] text-slate-500">
                                              {reply.isAccepted && (
                                                <span className="text-emerald-600 font-bold flex items-center gap-0.5 bg-emerald-100 px-1.5 py-0.5 rounded text-[10px]">
                                                  <CheckCircle2 className="w-3 h-3" /> Accepted Answer
                                                </span>
                                              )}
                                              <span>{formatRelativeTime(reply.createdAt)}</span>
                                              <span className="bg-slate-100 text-slate-700 font-semibold px-1.5 py-0.5 rounded text-[10px]">
                                                ▲ {reply.upvotes}
                                              </span>
                                            </div>
                                          </div>

                                          <p className="text-slate-700 leading-relaxed pl-8 mt-1 whitespace-pre-line">
                                            {reply.answerText}
                                          </p>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Users Directory Overview (Fetched from /users) */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900">User Profiles Directory (/users)</h3>
              <p className="text-[11px] text-slate-500">
                Registered profiles fetched from the user collection including role and mentor status.
              </p>
            </div>
            <span className="text-xs font-semibold text-slate-600 bg-slate-200 px-2.5 py-1 rounded-lg">
              {data?.users.length || 0} Registered Users
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" id="users-directory-table">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-100/60 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">UID (ID Field)</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Mentor Verification</th>
                  <th className="py-3 px-4">Specialization</th>
                  <th className="py-3 px-4 text-right">Activity Stats</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {data?.users.map(u => {
                  const doubtsCount = data.items.filter(i => i.userId === u.uid).length;
                  const answersCount = data.items.reduce(
                    (acc, i) => acc + i.replies.filter(r => r.authorId === u.uid).length,
                    0
                  );

                  return (
                    <tr key={u.uid} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs">
                            {u.name.charAt(0).toUpperCase()}
                          </div>
                          <span>{u.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 font-mono text-[11px]">{u.email}</td>
                      <td className="py-3 px-4 text-slate-400 font-mono text-[10px]">{u.uid}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            u.role === 'admin'
                              ? 'bg-purple-100 text-purple-700'
                              : u.role === 'mentor'
                              ? 'bg-emerald-100 text-emerald-700'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {u.isVerifiedMentor ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Verified
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">—</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-600 text-[11px]">
                        {u.subjectSpecialization || 'General'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-2 text-[11px]">
                          <span className="font-semibold text-indigo-700">{doubtsCount} doubts asked</span>
                          <span className="text-slate-300">•</span>
                          <span className="font-semibold text-emerald-700">{answersCount} replies</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
