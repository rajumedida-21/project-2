import React, { useState } from 'react';
import {
  GraduationCap,
  Search,
  PlusCircle,
  Bell,
  User,
  Shield,
  LogOut,
  ChevronDown,
  Layers,
  Award,
  Settings,
  HelpCircle,
  BarChart3,
  Sparkles,
  Brain,
  Calendar,
  TrendingUp,
  LayoutDashboard,
  Compass,
  Trophy,
  RotateCw,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { MentorBadge } from './MentorBadge';
import { ConnectionStatusIndicator } from './ConnectionStatusIndicator';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  searchQuery: string;
  onSearchChange: (val: string) => void;
  onOpenAskModal: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  searchQuery,
  onSearchChange,
  onOpenAskModal,
  currentPage,
  onNavigate,
}) => {
  const { currentUser, openAuthModal, logout } = useAuth();
  const { unreadCount, setIsOpen: setNotifOpen } = useNotifications();
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const navTabs = [
    { id: 'home', label: 'Doubts Feed', icon: HelpCircle },
    { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard },
    { id: 'tutor', label: 'AI Voice Tutor', icon: Sparkles, highlight: true },
    { id: 'revision', label: 'Spaced Revision', icon: RotateCw, badge: 'New' },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'quiz', label: 'AI Quiz', icon: Brain },
    { id: 'advisor', label: 'Study Advisor', icon: Compass },
    { id: 'planner', label: 'Planner', icon: Calendar },
    { id: 'progress', label: 'Analytics', icon: TrendingUp },
    { id: 'settings', label: 'Settings', icon: Settings, hideOnSmall: true },
    { id: 'mentors', label: 'Mentors', icon: Award, hideOnSmall: true },
    { id: 'subjects', label: 'Subjects', icon: Layers, hideOnSmall: true },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
      {/* Top Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & Brand */}
          <div
            id="brand-logo-btn"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 cursor-pointer shrink-0 select-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <span className="text-sm sm:text-base font-black tracking-tight text-slate-900 block leading-tight">
                AnonDoubt <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">AI</span>
              </span>
              <span className="text-[10px] text-slate-400 block font-medium">
                Student Learning Platform
              </span>
            </div>
          </div>

          {/* Search bar in center */}
          <div className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                id="navbar-search-input"
                type="text"
                value={searchQuery}
                onChange={e => onSearchChange(e.target.value)}
                placeholder="Search academic doubts, concepts, or subjects..."
                className="w-full text-xs pl-10 pr-4 py-2 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all placeholder:text-slate-400"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Right Navigation, Status & CTAs */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* PWA Install Button */}
            <PWAInstallButton />

            {/* Connection Status Indicator */}
            <ConnectionStatusIndicator />

            {/* Ask Doubt Button */}
            <button
              id="navbar-ask-doubt-btn"
              onClick={onOpenAskModal}
              className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold px-3.5 py-2 rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden xs:inline">Ask a Doubt</span>
              <span className="xs:hidden">Ask</span>
            </button>

            {/* Notifications Bell */}
            {currentUser && (
              <button
                id="notifications-bell-btn"
                onClick={() => setNotifOpen(true)}
                className="relative p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span
                    id="unread-notifications-badge"
                    className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white"
                  >
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>
            )}

            {/* User Profile / Auth */}
            {currentUser ? (
              <div className="relative">
                <button
                  id="user-profile-menu-btn"
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs">
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="hidden sm:block text-left">
                    <span className="text-xs font-semibold text-slate-800 block leading-tight max-w-[110px] truncate">
                      {currentUser.name}
                    </span>
                    <span className="text-[10px] text-slate-400 capitalize block leading-none">
                      {currentUser.role}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
                </button>

                {/* Profile Dropdown */}
                {profileDropdownOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-30"
                      onClick={() => setProfileDropdownOpen(false)}
                    />
                    <div
                      id="user-profile-dropdown"
                      className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 z-40 animate-in fade-in zoom-in-95 duration-100"
                    >
                      {/* Identity header with privacy shield */}
                      <div className="p-2.5 bg-slate-50 rounded-xl mb-2 border border-slate-100">
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="text-xs font-bold text-slate-900 truncate">
                            {currentUser.name}
                          </span>
                          {currentUser.isVerifiedMentor && currentUser.role === 'mentor' ? (
                            <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                              ✓ Mentor
                            </span>
                          ) : (
                            <span className="text-[10px] font-semibold text-slate-600 bg-slate-200 px-1.5 py-0.5 rounded capitalize">
                              {currentUser.role}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                        <div className="mt-2 pt-1.5 border-t border-slate-200/60 flex items-center gap-1.5 text-[10px] text-indigo-700 font-medium">
                          <Shield className="w-3 h-3 text-indigo-600 shrink-0" />
                          <span>Identity shielded on public doubts</span>
                        </div>
                      </div>

                      {/* Menu Options */}
                      <div className="space-y-1">
                        <button
                          id="dropdown-dashboard-btn"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate('dashboard');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium text-left cursor-pointer"
                        >
                          <LayoutDashboard className="w-4 h-4 text-indigo-600" />
                          <span>Command Center</span>
                        </button>

                        <button
                          id="dropdown-my-activity-btn"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate('activity');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium text-left cursor-pointer"
                        >
                          <User className="w-4 h-4 text-slate-500" />
                          <span>My Doubts & Answers</span>
                        </button>

                        <button
                          id="dropdown-leaderboard-btn"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate('leaderboard');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium text-left cursor-pointer"
                        >
                          <Trophy className="w-4 h-4 text-amber-500" />
                          <span>Leaderboard & XP</span>
                        </button>

                        <button
                          id="dropdown-settings-btn"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate('settings');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-slate-100 rounded-lg transition-colors font-medium text-left cursor-pointer"
                        >
                          <Settings className="w-4 h-4 text-slate-500" />
                          <span>Settings & Preferences</span>
                        </button>

                        {currentUser.role === 'admin' && (
                          <>
                            <button
                              id="dropdown-admin-dashboard-btn"
                              onClick={() => {
                                setProfileDropdownOpen(false);
                                onNavigate('admin');
                              }}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-indigo-700 hover:bg-indigo-50 rounded-lg transition-colors font-semibold text-left cursor-pointer"
                            >
                              <Settings className="w-4 h-4 text-indigo-600" />
                              <span>Admin Moderation</span>
                            </button>

                            <button
                              id="dropdown-doubt-analytics-btn"
                              onClick={() => {
                                setProfileDropdownOpen(false);
                                onNavigate('analytics');
                              }}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-indigo-700 hover:bg-indigo-50 rounded-lg transition-colors font-semibold text-left cursor-pointer"
                            >
                              <BarChart3 className="w-4 h-4 text-indigo-600" />
                              <span>Doubt Analytics Console</span>
                            </button>
                          </>
                        )}

                        <button
                          id="dropdown-logout-btn"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            logout();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-lg transition-colors font-medium text-left cursor-pointer pt-2 border-t border-slate-100"
                        >
                          <LogOut className="w-4 h-4 text-rose-500" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="navbar-login-btn"
                  onClick={() => openAuthModal('login')}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-700 hover:text-indigo-600 transition-colors cursor-pointer"
                >
                  Log In
                </button>
                <button
                  id="navbar-signup-btn"
                  onClick={() => openAuthModal('register')}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl shadow-2xs transition-colors cursor-pointer"
                >
                  Sign Up
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sub-Header Horizontal Navigation Strip */}
      <div className="border-t border-slate-100 bg-slate-50/80 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-1.5 py-1.5">
          {navTabs.map(tab => {
            const Icon = tab.icon;
            const isActive = currentPage === tab.id;

            return (
              <button
                key={tab.id}
                id={`subnav-link-${tab.id}`}
                onClick={() => onNavigate(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  tab.hideOnSmall ? 'hidden lg:flex' : 'flex'
                } ${
                  isActive
                    ? 'bg-white text-indigo-700 shadow-2xs ring-1 ring-slate-200'
                    : tab.highlight
                    ? 'text-indigo-700 hover:bg-indigo-50/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
                }`}
              >
                <Icon
                  className={`w-3.5 h-3.5 ${
                    isActive
                      ? 'text-indigo-600'
                      : tab.highlight
                      ? 'text-purple-600'
                      : 'text-slate-400'
                  }`}
                />
                <span>{tab.label}</span>
                {tab.highlight && (
                  <span className="text-[9px] bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-extrabold px-1.5 py-0.2 rounded-full uppercase tracking-wider">
                    Voice AI
                  </span>
                )}
                {tab.badge && !tab.highlight && (
                  <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-md">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
