import React from 'react';
import { useOnlineStatus } from '../utils/useOnlineStatus';
import { Wifi, WifiOff } from 'lucide-react';

export const ConnectionStatusIndicator: React.FC = () => {
  const { connectionState } = useOnlineStatus();

  return (
    <div
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium transition-colors select-none"
      title={`Network status: ${connectionState}`}
    >
      {connectionState === 'online' && (
        <span className="flex items-center gap-1 text-emerald-600 bg-emerald-50 border border-emerald-200/80 px-2 py-0.5 rounded-full">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Online</span>
        </span>
      )}

      {connectionState === 'connecting' && (
        <span className="flex items-center gap-1 text-amber-600 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-full">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
          <span>Connecting</span>
        </span>
      )}

      {connectionState === 'offline' && (
        <span className="flex items-center gap-1 text-rose-600 bg-rose-50 border border-rose-200/80 px-2 py-0.5 rounded-full">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
          <span>Offline</span>
        </span>
      )}
    </div>
  );
};
