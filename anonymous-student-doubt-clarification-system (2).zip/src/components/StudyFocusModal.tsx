import React, { useState, useEffect, useRef } from 'react';
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Sparkles,
  BookOpen,
  X,
  Flame,
  Star,
  Award,
} from 'lucide-react';
import { logCompletedStudySession } from '../services/adaptiveService';
import { recordActivityEvent } from '../services/gamificationService';

interface StudyFocusModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTopic?: string;
  initialSubject?: string;
  initialMinutes?: number;
}

export const StudyFocusModal: React.FC<StudyFocusModalProps> = ({
  isOpen,
  onClose,
  initialTopic = 'Core Concept Deep Dive',
  initialSubject = 'Computer Science',
  initialMinutes = 25,
}) => {
  const [topic, setTopic] = useState(initialTopic);
  const [subject, setSubject] = useState(initialSubject);
  const [targetMinutes, setTargetMinutes] = useState(initialMinutes);
  const [secondsRemaining, setSecondsRemaining] = useState(initialMinutes * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  // Reflection form
  const [reflection, setReflection] = useState('');
  const [focusRating, setFocusRating] = useState(5);
  const [earnedXP, setEarnedXP] = useState(0);

  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen) {
      setTopic(initialTopic);
      setSubject(initialSubject);
      setTargetMinutes(initialMinutes);
      setSecondsRemaining(initialMinutes * 60);
      setIsRunning(false);
      setIsFinished(false);
      setReflection('');
      setFocusRating(5);
    }
  }, [isOpen, initialTopic, initialSubject, initialMinutes]);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setSecondsRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            setIsRunning(false);
            setIsFinished(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning]);

  const handleSetDuration = (mins: number) => {
    setTargetMinutes(mins);
    setSecondsRemaining(mins * 60);
    setIsRunning(false);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progressPercent = Math.round(
    ((targetMinutes * 60 - secondsRemaining) / (targetMinutes * 60)) * 100
  );

  const handleSaveReflection = () => {
    const session = logCompletedStudySession({
      userId: 'local_student',
      subject,
      topic,
      goal: `Deep focus sprint on ${topic}`,
      durationMinutes: targetMinutes,
      reflection,
      focusRating,
    });

    const xpResult = recordActivityEvent({
      type: 'study_session',
      value: targetMinutes,
    });

    setEarnedXP(20 + Math.round(targetMinutes * 0.5));
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl border border-slate-200 max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1 rounded-xl hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {!isFinished ? (
          <div className="space-y-6 text-center">
            {/* Header */}
            <div className="space-y-1">
              <span className="inline-flex items-center gap-1.5 bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold px-3 py-1 rounded-full">
                <Timer className="w-3.5 h-3.5" />
                Distraction-Free Deep Study Sprint
              </span>
              <h2 className="text-xl font-bold text-slate-900 pt-2">{topic}</h2>
              <p className="text-xs text-slate-500 font-medium">{subject}</p>
            </div>

            {/* Circular Timer Visual */}
            <div className="relative w-48 h-48 mx-auto flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="84"
                  stroke="#f1f5f9"
                  strokeWidth="10"
                  fill="transparent"
                />
                <circle
                  cx="96"
                  cy="96"
                  r="84"
                  stroke="#4f46e5"
                  strokeWidth="10"
                  strokeDasharray={528}
                  strokeDashoffset={528 - (528 * progressPercent) / 100}
                  strokeLinecap="round"
                  fill="transparent"
                  className="transition-all duration-1000 ease-linear"
                />
              </svg>

              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-4xl font-extrabold text-slate-900 tracking-tight font-mono">
                  {formatTime(secondsRemaining)}
                </span>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mt-1">
                  {isRunning ? 'Focus In Progress' : 'Paused'}
                </span>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="flex items-center justify-center gap-2">
              {[15, 25, 45, 60].map(mins => (
                <button
                  key={mins}
                  type="button"
                  onClick={() => handleSetDuration(mins)}
                  disabled={isRunning}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                    targetMinutes === mins
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 disabled:opacity-50'
                  }`}
                >
                  {mins} min
                </button>
              ))}
            </div>

            {/* Timer Controls */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsRunning(!isRunning)}
                className={`px-6 py-3 rounded-2xl font-bold text-sm flex items-center gap-2 shadow-md transition-all cursor-pointer ${
                  isRunning
                    ? 'bg-amber-500 hover:bg-amber-600 text-white'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                }`}
              >
                {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                <span>{isRunning ? 'Pause Focus' : 'Start Focus Session'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsRunning(false);
                  setSecondsRemaining(targetMinutes * 60);
                }}
                className="p-3 text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-2xl transition-colors cursor-pointer"
                title="Reset timer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Finished Reflection Screen */
          <div className="space-y-5 text-center">
            <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h2 className="text-xl font-bold text-slate-900">Study Sprint Completed! 🎉</h2>
              <p className="text-xs text-slate-500">
                You focused for {targetMinutes} minutes on <strong>{topic}</strong>.
              </p>
            </div>

            {/* Reflection form */}
            <div className="space-y-3 text-left bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <label className="text-xs font-bold text-slate-800 block">
                Session Reflection & Key Insights:
              </label>
              <textarea
                value={reflection}
                onChange={e => setReflection(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:ring-1 focus:ring-indigo-500 focus:outline-none resize-none"
                placeholder="What concept did you master? Any doubts remaining to ask AI Tutor?"
              />

              <div className="flex items-center justify-between pt-1">
                <span className="text-xs font-semibold text-slate-600">Focus Rating:</span>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setFocusRating(star)}
                      className={`p-1 ${focusRating >= star ? 'text-amber-500' : 'text-slate-300'}`}
                    >
                      <Star className="w-4 h-4 fill-current" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-indigo-700 bg-indigo-50 p-3 rounded-xl border border-indigo-100">
              <span className="font-semibold flex items-center gap-1.5">
                <Award className="w-4 h-4" /> Study XP Reward:
              </span>
              <span className="font-bold">+{20 + Math.round(targetMinutes * 0.5)} XP Earned</span>
            </div>

            <button
              type="button"
              onClick={handleSaveReflection}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-xs transition-colors"
            >
              Save Session & Collect XP
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
