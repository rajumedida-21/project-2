import React, { useState } from 'react';
import {
  FileText,
  Sparkles,
  Download,
  Copy,
  Check,
  X,
  Printer,
  Brain,
  Award,
  AlertCircle,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { generateAILearningReport } from '../services/aiService';
import { getGamificationData } from '../services/gamificationService';
import { getFlashcardStats } from '../services/revisionService';

interface AILearningReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  quizHistory?: any[];
  doubtsAsked?: any[];
}

export const AILearningReportModal: React.FC<AILearningReportModalProps> = ({
  isOpen,
  onClose,
  quizHistory = [],
  doubtsAsked = [],
}) => {
  const [report, setReport] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [generatedDate, setGeneratedDate] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    setLoading(true);
    setReport(null);

    const gamification = getGamificationData();
    const flashcardStats = getFlashcardStats();

    try {
      const res = await generateAILearningReport({
        quizzesTaken: gamification.quizzesCompletedCount || 3,
        averageScore: 78,
        quizHistory: quizHistory.length > 0 ? quizHistory : [{ title: 'DSA & Algorithms', score: 85 }, { title: 'DBMS Fundamentals', score: 70 }],
        doubtsAsked: doubtsAsked.length > 0 ? doubtsAsked : ['Recursion tree complexity', 'B-Tree vs B+ Tree in MySQL'],
        completedTasks: ['Master DFS & BFS', 'Study 3NF Normalization'],
        streakDays: gamification.streak || 3,
        flashcardsCount: flashcardStats.total,
        flashcardMastery: {
          mastered: flashcardStats.mastered,
          difficult: flashcardStats.difficult,
          learning: flashcardStats.learning,
          new: flashcardStats.newCards,
        },
        studyMinutes: gamification.totalStudyMinutes || 75,
      });

      setReport(res.reportText);
      setGeneratedDate(res.generatedAt);
    } catch (err: any) {
      alert(err.message || 'Failed to generate learning report.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!report) return;
    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!report) return;
    const blob = new Blob([report], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Student_Learning_Report_${new Date().toISOString().slice(0, 10)}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl border border-slate-200 max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 flex items-center justify-between shrink-0 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">AI Comprehensive Learning Report</h2>
              <p className="text-xs text-slate-500">
                In-depth analytical evaluation of your academic progress, strengths, and retention curves.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {!report && !loading && (
            <div className="text-center py-12 space-y-4 max-w-md mx-auto">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Ready to Generate Your AI Report?</h3>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                The Academic AI Advisor will synthesize your quiz history, question inquiries, flashcard spaced repetition recall rates, and study streaks into a comprehensive report.
              </p>
              <button
                onClick={handleGenerate}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
              >
                Synthesize & Generate Report
              </button>
            </div>
          )}

          {loading && (
            <div className="text-center py-16 space-y-4">
              <div className="w-12 h-12 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-900">Analyzing Learning Telemetry...</h4>
                <p className="text-xs text-slate-500">Evaluating concept mastery, recall curves, and study gaps.</p>
              </div>
            </div>
          )}

          {report && !loading && (
            <div className="space-y-6 animate-in fade-in">
              <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-slate-100 text-xs">
                <span className="text-slate-500 font-medium">
                  Status: <strong className="text-emerald-600">Generated successfully</strong>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleDownload}
                    className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download (.md)</span>
                  </button>
                </div>
              </div>

              <div className="prose prose-xs sm:prose-sm max-w-none text-slate-800 leading-relaxed">
                <div className="markdown-body">
                  <ReactMarkdown>{report}</ReactMarkdown>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {report && (
          <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500 shrink-0">
            <span>Confidential Academic Report • AI Studio Doubt Platform</span>
            <button
              onClick={handleGenerate}
              className="text-indigo-600 hover:underline font-semibold flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Regenerate Fresh Report</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
