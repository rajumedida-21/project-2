import React from 'react';
import {
  Sparkles,
  Brain,
  Target,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  BookOpen,
} from 'lucide-react';
import { generateSmartRecommendations } from '../services/adaptiveService';
import { AdaptiveRecommendation } from '../types';

interface AdaptiveRecommendationsProps {
  onNavigateToFlashcards?: () => void;
  onNavigateToTutor?: (initialPrompt?: string) => void;
  onStartFocusSession?: (topic: string, subject: string, minutes: number) => void;
  onNavigateToQuiz?: () => void;
}

export const AdaptiveRecommendations: React.FC<AdaptiveRecommendationsProps> = ({
  onNavigateToFlashcards,
  onNavigateToTutor,
  onStartFocusSession,
  onNavigateToQuiz,
}) => {
  const recommendations: AdaptiveRecommendation[] = generateSmartRecommendations();

  const handleAction = (rec: AdaptiveRecommendation) => {
    switch (rec.targetPage) {
      case 'flashcards':
        if (onNavigateToFlashcards) onNavigateToFlashcards();
        break;
      case 'tutor':
        if (onNavigateToTutor) onNavigateToTutor(rec.targetParams?.initialPrompt);
        break;
      case 'focus':
        if (onStartFocusSession) {
          onStartFocusSession(
            rec.targetParams?.topic || rec.title,
            rec.targetParams?.subject || 'Computer Science',
            rec.estimatedMinutes || 25
          );
        }
        break;
      case 'quiz':
        if (onNavigateToQuiz) onNavigateToQuiz();
        break;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">Personalized Adaptive Recommendations</h3>
            <p className="text-xs text-slate-500">
              Dynamically derived from your active recall logs, quiz accuracy, and spaced review schedules.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {recommendations.map(rec => (
          <div
            key={rec.id}
            className="p-4 rounded-2xl border border-slate-200 hover:border-indigo-300 bg-slate-50/50 hover:bg-white transition-all flex flex-col justify-between space-y-3 shadow-2xs"
          >
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                    rec.priority === 'high'
                      ? 'bg-rose-50 text-rose-700'
                      : rec.priority === 'medium'
                      ? 'bg-amber-50 text-amber-700'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {rec.priority.toUpperCase()} PRIORITY
                </span>
                <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                  <Clock className="w-3 h-3" /> ~{rec.estimatedMinutes} min
                </span>
              </div>

              <h4 className="text-sm font-bold text-slate-900">{rec.title}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{rec.reason}</p>
            </div>

            <div className="pt-2 border-t border-slate-200/70 flex items-center justify-between">
              <span className="text-[11px] font-medium text-slate-400">
                {rec.isPersonalized ? '🎯 AI Telemetry Grounded' : '💡 Recommended Practice'}
              </span>
              <button
                type="button"
                onClick={() => handleAction(rec)}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <span>{rec.actionLabel}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
