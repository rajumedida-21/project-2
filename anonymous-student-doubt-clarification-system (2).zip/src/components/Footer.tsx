import React from 'react';
import { GraduationCap, ShieldCheck, Database, Sparkles, Heart } from 'lucide-react';

export const Footer: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2 text-white">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-base tracking-tight">
                Anonymous Student Doubt Clarification System
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-md">
              A safe, anonymous academic sanctuary designed for college students to ask genuine conceptual questions without hesitation or fear of judgment, answered by peers, teachers, and verified mentors.
            </p>
            <div className="flex items-center gap-3 pt-2 text-slate-300">
              <span className="inline-flex items-center gap-1 text-[11px] bg-slate-800 px-2.5 py-1 rounded-md border border-slate-700">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Zero Identity Exposure
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] bg-slate-800 px-2.5 py-1 rounded-md border border-slate-700">
                <Database className="w-3.5 h-3.5 text-indigo-400" />
                Firestore Powered
              </span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-white font-semibold text-xs mb-3 tracking-wider uppercase">Navigation</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  All Academic Doubts
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('mentors')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Verified Academic Mentors
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('subjects')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Computer Science & Engineering Subjects
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('activity')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  My Private Activity
                </button>
              </li>
            </ul>
          </div>

          {/* Guidelines */}
          <div>
            <h4 className="text-white font-semibold text-xs mb-3 tracking-wider uppercase">Academic Integrity</h4>
            <p className="text-slate-400 text-xs leading-relaxed">
              We promote learning and conceptual understanding. Please do not post direct exam answers or copyrighted test banks. Maintain respectful language at all times.
            </p>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <p>© {new Date().getFullYear()} Anonymous Student Doubt Clarification System. Built with React & Firebase.</p>
          <div className="flex items-center gap-4">
            <span>Identity Protected</span>
            <span>•</span>
            <span>ABAC Zero-Trust Rules</span>
            <span>•</span>
            <span>Production Ready</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
