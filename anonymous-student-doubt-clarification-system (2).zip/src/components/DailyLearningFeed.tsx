import React, { useState, useEffect } from 'react';
import {
  Sun,
  Calendar,
  CheckCircle2,
  Circle,
  Sparkles,
  ArrowRight,
  Clock,
  BookOpen,
  Brain,
  HelpCircle,
  Play,
} from 'lucide-react';
import { fetchPersonalizedDailyFeed } from '../services/aiService';
import { getGamificationData } from '../services/gamificationService';
import { getDueFlashcards } from '../services/revisionService';

interface DailyLearningFeedProps {
  onStartFocusSession?: (topic: string, subject: string, minutes: number) => void;
  onNavigateToFlashcards?: () => void;
  onNavigateToQuiz?: () => void;
  onNavigateToTutor?: () => void;
}

interface FeedTask {
  id: string;
  title: string;
  category: 'study' | 'flashcard' | 'quiz' | 'practice';
  durationMinutes: number;
  subject?: string;
  completed?: boolean;
}

export const DailyLearningFeed: React.FC<DailyLearningFeedProps> = ({
  onStartFocusSession,
  onNavigateToFlashcards,
  onNavigateToQuiz,
  onNavigateToTutor,
}) => {
  const [greeting, setGreeting] = useState('Good day! Ready for your study sprint? 🚀');
  const [summaryMessage, setSummaryMessage] = useState('Steady daily practice turns difficult concepts into second nature.');
  const [tasks, setTasks] = useState<FeedTask[]>([
    { id: 'f1', title: '20 min — Core concept review and lecture synthesis', category: 'study', durationMinutes: 20, subject: 'Computer Science', completed: false },
    { id: 'f2', title: '10 min — Review due active recall flashcards', category: 'flashcard', durationMinutes: 10, subject: 'Revision', completed: false },
    { id: 'f3', title: '15 min — Test understanding with an interactive quiz', category: 'quiz', durationMinutes: 15, subject: 'Assessment', completed: false },
  ]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const gamification = getGamificationData();
    const dueCards = getDueFlashcards();

    setLoading(true);
    fetchPersonalizedDailyFeed({
      streakDays: gamification.streak || 3,
      dueFlashcardsCount: dueCards.length,
      weakTopics: ['Algorithms', 'DBMS Normalization'],
      recentDoubts: ['Recursion tree', 'TCP vs UDP'],
    })
      .then(res => {
        if (res) {
          if (res.greeting) setGreeting(res.greeting);
          if (res.summaryMessage) setSummaryMessage(res.summaryMessage);
          if (res.tasks && res.tasks.length > 0) {
            setTasks(res.tasks.map(t => ({ ...t, completed: false })));
          }
        }
      })
      .finally(() => setLoading(false));
  }, []);

  const toggleTask = (id: string) => {
    setTasks(prev =>
      prev.map(t => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const completedCount = tasks.filter(t => t.completed).length;
  const progressPercent = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  return (
    <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden space-y-6">
      {/* Background Decorative Rings */}
      <div className="absolute top-0 right-0 -mt-8 -mr-8 w-48 h-48 rounded-full bg-indigo-500/10 blur-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-48 h-48 rounded-full bg-purple-500/10 blur-2xl pointer-events-none" />

      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 bg-white/10 backdrop-blur-xs text-indigo-200 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-white/10">
              <Sun className="w-3.5 h-3.5 text-amber-400" /> Daily AI Study Routine
            </span>
            <span className="text-xs text-slate-300 font-medium">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">{greeting}</h2>
          <p className="text-xs sm:text-sm text-indigo-200/90 leading-relaxed max-w-2xl">
            {summaryMessage}
          </p>
        </div>

        {/* Progress pill */}
        <div className="bg-white/10 backdrop-blur-xs border border-white/15 rounded-2xl p-3 px-4 flex items-center gap-3 shrink-0">
          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-indigo-300 block">Daily Target</span>
            <span className="text-sm font-bold text-white">{completedCount}/{tasks.length} Done</span>
          </div>
          <div className="w-10 h-10 rounded-full border-2 border-indigo-400/40 flex items-center justify-center font-bold text-xs text-indigo-200">
            {progressPercent}%
          </div>
        </div>
      </div>

      {/* Tasks list */}
      <div className="space-y-2.5 relative z-10">
        {tasks.map(task => (
          <div
            key={task.id}
            className={`p-3.5 sm:p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
              task.completed
                ? 'bg-white/5 border-white/10 text-slate-400 line-through'
                : 'bg-white/10 hover:bg-white/15 border-white/15 text-white'
            }`}
          >
            <div
              onClick={() => toggleTask(task.id)}
              className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer select-none"
            >
              {task.completed ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <Circle className="w-5 h-5 text-indigo-300 hover:text-white shrink-0" />
              )}
              <div>
                <span className="text-xs sm:text-sm font-semibold block truncate">
                  {task.title}
                </span>
                {task.subject && (
                  <span className="text-[10px] text-indigo-300 font-medium">
                    {task.subject}
                  </span>
                )}
              </div>
            </div>

            {/* Quick Action Button based on category */}
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-indigo-200 font-mono hidden sm:inline flex items-center gap-1">
                <Clock className="w-3 h-3 text-indigo-300" /> {task.durationMinutes}m
              </span>

              {task.category === 'study' && onStartFocusSession && (
                <button
                  type="button"
                  onClick={() => onStartFocusSession(task.title, task.subject || 'General', task.durationMinutes)}
                  className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-xs transition-colors cursor-pointer"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span className="hidden sm:inline">Focus</span>
                </button>
              )}

              {task.category === 'flashcard' && onNavigateToFlashcards && (
                <button
                  type="button"
                  onClick={onNavigateToFlashcards}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-xs transition-colors cursor-pointer"
                >
                  <Brain className="w-3 h-3" />
                  <span className="hidden sm:inline">Review</span>
                </button>
              )}

              {task.category === 'quiz' && onNavigateToQuiz && (
                <button
                  type="button"
                  onClick={onNavigateToQuiz}
                  className="px-3 py-1.5 bg-purple-500 hover:bg-purple-600 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-xs transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3 h-3" />
                  <span className="hidden sm:inline">Take Quiz</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
