import React, { useState } from 'react';
import { X, AlertTriangle, CheckCircle, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { createReport } from '../services/reportService';
import { Report } from '../types';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  contentType: 'question' | 'answer';
  contentId: string;
  contentSnippet?: string;
}

const REPORT_REASONS: Report['reason'][] = [
  'Spam',
  'Offensive content',
  'Incorrect information',
  'Harassment',
  'Other',
];

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  contentType,
  contentId,
  contentSnippet,
}) => {
  const { currentUser, openAuthModal } = useAuth();
  const [reason, setReason] = useState<Report['reason']>('Spam');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      openAuthModal('login');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      await createReport({
        reportedBy: currentUser.uid,
        contentType,
        contentId,
        contentSnippet: contentSnippet?.slice(0, 150),
        reason,
        details,
      });
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        onClose();
      }, 1800);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to submit report. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      id="report-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        id="report-modal"
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 relative"
        onClick={e => e.stopPropagation()}
      >
        <button
          id="close-report-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-8 text-center">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Report Submitted</h3>
            <p className="text-xs text-slate-500 mt-1">
              Thank you for keeping our academic community safe. Moderators will review this content.
            </p>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-3">
              <div className="p-2 bg-rose-50 text-rose-600 rounded-xl">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Report {contentType === 'question' ? 'Question' : 'Answer'}</h3>
                <p className="text-xs text-slate-500">Flag inappropriate content for moderation</p>
              </div>
            </div>

            {contentSnippet && (
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 italic mb-4 line-clamp-2">
                &ldquo;{contentSnippet}&rdquo;
              </div>
            )}

            {error && (
              <div className="mb-3 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Reason for reporting:
                </label>
                <div className="space-y-1.5">
                  {REPORT_REASONS.map(r => (
                    <label
                      key={r}
                      className={`flex items-center gap-2.5 p-2 rounded-lg border text-xs cursor-pointer transition-colors ${
                        reason === r
                          ? 'bg-rose-50/70 border-rose-300 text-rose-900 font-medium'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="report-reason"
                        value={r}
                        checked={reason === r}
                        onChange={() => setReason(r)}
                        className="text-rose-600 focus:ring-rose-500 w-3.5 h-3.5"
                      />
                      <span>{r}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Additional Details (optional):
                </label>
                <textarea
                  id="report-details-input"
                  rows={3}
                  placeholder="Explain why this content violates academic rules or safety guidelines..."
                  value={details}
                  onChange={e => setDetails(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="submit-report-btn"
                  disabled={submitting}
                  className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  {submitting && <span className="w-3 h-3 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
                  <span>Submit Report</span>
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
