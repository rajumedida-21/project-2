import React from 'react';
import { WifiOff, CloudOff, Info } from 'lucide-react';
import { useOnlineStatus } from '../utils/useOnlineStatus';

export const OfflineBanner: React.FC = () => {
  const { isOnline } = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="alert"
      className="bg-amber-600 text-white px-4 py-2 text-xs font-medium flex items-center justify-between shadow-sm sticky top-0 z-50 animate-in fade-in slide-in-from-top"
    >
      <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
        <WifiOff className="w-4 h-4 shrink-0 text-amber-100 animate-pulse" />
        <span className="font-bold">You're offline.</span>
        <span className="text-amber-100 hidden sm:inline">
          Accessing cached study plans, flashcards, and previously loaded content. Cloud AI queries are paused until connection is restored.
        </span>
        <span className="text-amber-100 sm:hidden">
          Using cached study content offline.
        </span>
      </div>
    </div>
  );
};
