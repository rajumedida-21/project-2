import React, { useState, useEffect } from 'react';
import { X, HelpCircle, Image as ImageIcon, Shield, Upload, Trash2, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { createQuestion, getQuestions } from '../services/questionService';
import { Subject, Question } from '../types';
import { processImageUpload } from '../utils/storageHelper';
import { SimilarDoubtsWidget } from './SimilarDoubtsWidget';

interface AskDoubtModalProps {
  isOpen: boolean;
  onClose: () => void;
  subjects: Subject[];
  onQuestionCreated: (questionId: string) => void;
}

export const AskDoubtModal: React.FC<AskDoubtModalProps> = ({
  isOpen,
  onClose,
  subjects,
  onQuestionCreated,
}) => {
  const { currentUser, openAuthModal } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subjectId, setSubjectId] = useState(subjects[0]?.subjectId || 'data-structures');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [allQuestions, setAllQuestions] = useState<Question[]>([]);

  useEffect(() => {
    if (isOpen) {
      getQuestions().then(res => {
        if (Array.isArray(res)) setAllQuestions(res);
      }).catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) {
        setError('Image file is too large (max 5MB)');
        return;
      }
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
      setError(null);
    }
  };

  const removeImage = () => {
    setImageFile(null);
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    setImagePreview(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      openAuthModal('login');
      return;
    }

    if (title.trim().length < 5) {
      setError('Title must be at least 5 characters long.');
      return;
    }
    if (description.trim().length < 10) {
      setError('Please provide a more detailed description of your doubt (min 10 characters).');
      return;
    }
    if (!subjectId) {
      setError('Please select an academic subject.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      let finalImageUrl = '';
      if (imageFile) {
        finalImageUrl = await processImageUpload(imageFile);
      }

      const selectedSubject = subjects.find(s => s.subjectId === subjectId);

      const newQ = await createQuestion({
        title: title.trim(),
        description: description.trim(),
        subjectId,
        subjectName: selectedSubject?.name,
        imageUrl: finalImageUrl,
        isAnonymous: isAnonymous,
        authorId: currentUser.uid,
      });

      // Clean up form
      setTitle('');
      setDescription('');
      removeImage();
      onClose();
      onQuestionCreated(newQ.questionId);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to post question. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      id="ask-doubt-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="ask-doubt-modal"
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 sm:p-7 border border-slate-200 relative my-6 max-h-[92vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <button
          id="close-ask-doubt-btn"
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5 shrink-0">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl shadow-2xs">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900">Ask an Academic Doubt</h2>
            <p className="text-xs text-slate-500">
              Get answers from classmates, teachers, and verified mentors.
            </p>
          </div>
        </div>

        {/* Anonymity Assurance Banner */}
        <div className="mb-4 p-3 bg-indigo-50/70 border border-indigo-200/80 rounded-xl flex items-start gap-2.5 text-xs text-indigo-950 shrink-0">
          <Shield className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-semibold">Protected Student Anonymity: </span>
            <span>
              Your real name, email, and user account will <strong>never</strong> be displayed publicly. Other students and teachers will only see <strong>&ldquo;Anonymous Student&rdquo;</strong>.
            </span>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl shrink-0">
            {error}
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 flex-1 overflow-y-auto pr-1">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Subject / Topic <span className="text-rose-500">*</span>
            </label>
            <select
              id="doubt-subject-select"
              value={subjectId}
              onChange={e => setSubjectId(e.target.value)}
              className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden font-medium text-slate-800 cursor-pointer"
            >
              {subjects.map(s => (
                <option key={s.subjectId} value={s.subjectId}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Question Title <span className="text-rose-500">*</span>
            </label>
            <input
              id="doubt-title-input"
              type="text"
              required
              placeholder="e.g. What is the difference between BFS and DFS in a cyclic graph?"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden transition-all"
            />
          </div>

          {/* Real-time Similar Doubts Detector */}
          <SimilarDoubtsWidget
            title={title}
            description={description}
            subjectId={subjectId}
            allQuestions={allQuestions}
            onOpenQuestion={qId => {
              onClose();
              onQuestionCreated(qId);
            }}
          />

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Detailed Description <span className="text-rose-500">*</span>
            </label>
            <textarea
              id="doubt-description-input"
              required
              rows={5}
              placeholder="Explain where you are stuck, what you have tried, or include code snippets / logic..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden leading-relaxed font-sans"
            />
          </div>

          {/* Image Attachment */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Attach Diagram or Code Screenshot (Optional)
            </label>
            {imagePreview ? (
              <div className="relative inline-block border border-slate-200 rounded-xl overflow-hidden group">
                <img
                  src={imagePreview}
                  alt="Doubt attachment preview"
                  className="max-h-44 max-w-full rounded-lg object-contain bg-slate-900"
                />
                <button
                  type="button"
                  id="remove-attached-image-btn"
                  onClick={removeImage}
                  className="absolute top-2 right-2 p-1.5 bg-rose-600/90 text-white rounded-lg hover:bg-rose-700 transition-colors shadow-xs"
                  title="Remove image"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <label
                htmlFor="doubt-image-upload"
                className="border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-slate-50/60 hover:bg-slate-50 p-4 rounded-xl flex flex-col items-center justify-center cursor-pointer transition-colors"
              >
                <Upload className="w-6 h-6 text-slate-400 mb-1" />
                <span className="text-xs font-medium text-slate-700">Click to upload screenshot / diagram</span>
                <span className="text-[10px] text-slate-400 mt-0.5">PNG, JPG, WebP up to 5MB</span>
                <input
                  id="doubt-image-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </label>
            )}
          </div>

          {/* Anonymous toggle */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <input
                id="doubt-anonymous-checkbox"
                type="checkbox"
                checked={isAnonymous}
                onChange={e => setIsAnonymous(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded-md focus:ring-indigo-500 border-slate-300 cursor-pointer"
              />
              <label htmlFor="doubt-anonymous-checkbox" className="text-xs text-slate-700 font-medium cursor-pointer">
                Post anonymously (display as &ldquo;Anonymous Student&rdquo;)
              </label>
            </div>
            <span className="text-[11px] text-emerald-600 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Identity shielded
            </span>
          </div>

          {/* Action Footer */}
          <div className="pt-3 flex items-center justify-end gap-2.5 shrink-0 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="submit-doubt-btn"
              disabled={submitting}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-2"
            >
              {submitting && <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
              <span>Post Doubt</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
