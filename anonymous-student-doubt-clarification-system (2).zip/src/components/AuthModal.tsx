import React, { useState } from 'react';
import { X, Lock, Mail, User, Shield, GraduationCap, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mapFirebaseAuthError } from '../services/authService';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    authModalMode,
    closeAuthModal,
    openAuthModal,
    login,
    register,
    resetPassword,
    demoLogin,
    isConfigured,
  } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'student' | 'mentor'>('student');
  const [specialization, setSpecialization] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setLoading(true);

    try {
      if (authModalMode === 'login') {
        await login(email, password);
        closeAuthModal();
      } else if (authModalMode === 'register') {
        if (!name.trim()) throw new Error('Please enter your full name');
        if (password.length < 6) throw new Error('Password must be at least 6 characters');
        await register({
          name: name.trim(),
          email: email.trim(),
          password,
          role,
          subjectSpecialization: role === 'mentor' ? specialization : undefined,
        });
        closeAuthModal();
      } else if (authModalMode === 'forgot') {
        await resetPassword(email);
        setSuccessMessage('Password reset link sent! Check your inbox.');
      }
    } catch (err: unknown) {
      setError(mapFirebaseAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      id="auth-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={closeAuthModal}
    >
      <div
        id="auth-modal"
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 sm:p-7 border border-slate-100 relative my-6"
        onClick={e => e.stopPropagation()}
      >
        <button
          id="close-auth-modal-btn"
          onClick={closeAuthModal}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="inline-flex p-3 bg-indigo-50 text-indigo-600 rounded-2xl mb-3 shadow-2xs">
            <GraduationCap className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-slate-900">
            {authModalMode === 'login' && 'Welcome Back'}
            {authModalMode === 'register' && 'Join the Doubt Clarification Community'}
            {authModalMode === 'forgot' && 'Reset Password'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {authModalMode === 'login' && 'Log in to ask anonymous questions or assist your peers.'}
            {authModalMode === 'register' && 'Your personal identity stays private. Post doubts 100% anonymously.'}
            {authModalMode === 'forgot' && 'Enter your account email to receive a password reset link.'}
          </p>
        </div>

        {/* Error / Success Notifications */}
        {error && (
          <div
            id="auth-error-banner"
            className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-start gap-2"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
            <span>{error}</span>
          </div>
        )}
        {successMessage && (
          <div
            id="auth-success-banner"
            className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-xl flex items-start gap-2"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {authModalMode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  id="register-name-input"
                  type="text"
                  required
                  placeholder="Your Name (kept private publicly)"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full text-xs pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden transition-all"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                id="auth-email-input"
                type="email"
                required
                placeholder="college.student@university.edu"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden transition-all"
              />
            </div>
          </div>

          {authModalMode !== 'forgot' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">Password</label>
                {authModalMode === 'login' && (
                  <button
                    type="button"
                    id="link-forgot-password"
                    onClick={() => openAuthModal('forgot')}
                    className="text-[11px] text-indigo-600 hover:text-indigo-700 font-medium"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  id="auth-password-input"
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full text-xs pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden transition-all"
                />
              </div>
            </div>
          )}

          {authModalMode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Select Role</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="role-student-btn"
                  onClick={() => setRole('student')}
                  className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-all ${
                    role === 'student'
                      ? 'bg-indigo-50/80 border-indigo-500 text-indigo-900 ring-2 ring-indigo-200'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>Student</span>
                </button>
                <button
                  type="button"
                  id="role-mentor-btn"
                  onClick={() => setRole('mentor')}
                  className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-all ${
                    role === 'mentor'
                      ? 'bg-emerald-50/80 border-emerald-500 text-emerald-900 ring-2 ring-emerald-200'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  <span>Mentor/Teacher</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Note: Admin roles are protected and granted exclusively by administrators.
              </p>

              {role === 'mentor' && (
                <div className="mt-2.5">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Subject Specialization
                  </label>
                  <input
                    id="mentor-specialization-input"
                    type="text"
                    placeholder="e.g. Data Structures, DBMS, Machine Learning"
                    value={specialization}
                    onChange={e => setSpecialization(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                  <p className="text-[10px] text-emerald-700 mt-1">
                    Mentors receive a &ldquo;Verified Mentor&rdquo; badge once verified by an Admin.
                  </p>
                </div>
              )}
            </div>
          )}

          <button
            type="submit"
            id="auth-submit-btn"
            disabled={loading}
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors mt-2 cursor-pointer flex items-center justify-center gap-2"
          >
            {loading && <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
            <span>
              {authModalMode === 'login' && 'Sign In'}
              {authModalMode === 'register' && 'Create Account'}
              {authModalMode === 'forgot' && 'Send Reset Email'}
            </span>
          </button>
        </form>

        {/* Switch mode links */}
        <div className="mt-4 pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
          {authModalMode === 'login' && (
            <p>
              Don&apos;t have an account?{' '}
              <button
                type="button"
                id="switch-to-register-btn"
                onClick={() => openAuthModal('register')}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Sign up free
              </button>
            </p>
          )}
          {authModalMode === 'register' && (
            <p>
              Already have an account?{' '}
              <button
                type="button"
                id="switch-to-login-btn"
                onClick={() => openAuthModal('login')}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Sign in
              </button>
            </p>
          )}
          {authModalMode === 'forgot' && (
            <p>
              Remember your password?{' '}
              <button
                type="button"
                id="switch-back-to-login-btn"
                onClick={() => openAuthModal('login')}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Back to Sign in
              </button>
            </p>
          )}
        </div>

        {/* Quick Testing Role Switcher */}
        <div className="mt-5 p-3 bg-slate-50 border border-slate-200/80 rounded-xl">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Instant Preview Tester:</span>
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              id="demo-login-student-btn"
              onClick={() => demoLogin('student')}
              className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-medium text-slate-700 text-center cursor-pointer transition-colors"
            >
              🎓 Student
            </button>
            <button
              type="button"
              id="demo-login-mentor-btn"
              onClick={() => demoLogin('mentor')}
              className="py-1.5 px-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-[11px] font-medium text-emerald-800 text-center cursor-pointer transition-colors"
            >
              ✓ Mentor
            </button>
            <button
              type="button"
              id="demo-login-admin-btn"
              onClick={() => demoLogin('admin')}
              className="py-1.5 px-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg text-[11px] font-medium text-indigo-800 text-center cursor-pointer transition-colors"
            >
              ⚡ Admin
            </button>
          </div>
          <p className="text-[10px] text-slate-400 mt-1.5 text-center">
            Instantly switch roles to test Student anonymity, Mentor badges, or Admin moderation.
          </p>
        </div>
      </div>
    </div>
  );
};
