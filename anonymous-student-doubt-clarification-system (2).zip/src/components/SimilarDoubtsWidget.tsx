import React, { useEffect, useState } from 'react';
import { Sparkles, HelpCircle, ArrowRight, CheckCircle2, ChevronRight } from 'lucide-react';
import { findSimilarDoubts } from '../services/aiService';
import { Question } from '../types';

interface SimilarDoubtsWidgetProps {
  currentQuestionId?: string;
  title: string;
  description?: string;
  subjectId?: string;
  allQuestions: Question[];
  onOpenQuestion?: (questionId: string) => void;
}

export const SimilarDoubtsWidget: React.FC<SimilarDoubtsWidgetProps> = ({
  currentQuestionId,
  title,
  description,
  subjectId,
  allQuestions,
  onOpenQuestion,
}) => {
  const [similar, setSimilar] = useState<Array<{
    questionId: string;
    title: string;
    subjectName: string;
    similarityScore: number;
    matchedConcept?: string;
  }>>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!title || title.trim().length < 6) {
      setSimilar([]);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const results = await findSimilarDoubts({
          currentQuestionId,
          title: title.trim(),
          description: description?.trim(),
          subjectId,
          allQuestions: allQuestions.map(q => ({
            questionId: q.questionId,
            title: q.title,
            description: q.description,
            subjectId: q.subjectId,
            subjectName: q.subjectName,
          })),
        });
        setSimilar(results);
      } catch {
        setSimilar([]);
      } finally {
        setLoading(false);
      }
    }, 450);

    return () => clearTimeout(timer);
  }, [title, description, subjectId, currentQuestionId, allQuestions.length]);

  if (similar.length === 0 && !loading) return null;

  return (
    <div className="rounded-2xl border border-indigo-100 bg-linear-to-b from-indigo-50/50 via-white to-white p-4 shadow-2xs">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900">Similar Doubts Asked by Others</h4>
            <p className="text-[11px] text-slate-500">
              AI concept matching to prevent duplicate questions and find instant answers
            </p>
          </div>
        </div>
        {loading && (
          <span className="text-[11px] text-indigo-600 flex items-center gap-1.5 font-medium animate-pulse">
            <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
            Analyzing...
          </span>
        )}
      </div>

      <div className="space-y-2">
        {similar.map(item => (
          <div
            key={item.questionId}
            onClick={() => onOpenQuestion && onOpenQuestion(item.questionId)}
            className="p-2.5 rounded-xl bg-white hover:bg-indigo-50/70 border border-slate-200/80 hover:border-indigo-200 transition-all cursor-pointer flex items-center justify-between gap-3 group"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                  {item.similarityScore}% Match
                </span>
                <span className="text-[10px] text-slate-400 font-medium">
                  {item.subjectName}
                </span>
                {item.matchedConcept && (
                  <span className="text-[10px] text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded">
                    {item.matchedConcept}
                  </span>
                )}
              </div>
              <p className="text-xs font-medium text-slate-800 line-clamp-1 group-hover:text-indigo-600 transition-colors">
                {item.title}
              </p>
            </div>

            <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all shrink-0" />
          </div>
        ))}
      </div>
    </div>
  );
};
