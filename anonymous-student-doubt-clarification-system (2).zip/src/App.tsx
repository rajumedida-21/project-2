import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';
import { SettingsProvider } from './context/SettingsContext';
import { ThemeProvider } from './context/ThemeContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { FirebaseSetupBanner } from './components/FirebaseSetupBanner';
import { AuthModal } from './components/AuthModal';
import { AskDoubtModal } from './components/AskDoubtModal';
import { ReportModal } from './components/ReportModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { HomePage } from './pages/HomePage';
import { QuestionDetailPage } from './pages/QuestionDetailPage';
import { MyActivityPage } from './pages/MyActivityPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { MentorsPage } from './pages/MentorsPage';
import { SubjectsPage } from './pages/SubjectsPage';
import { DashboardPage } from './pages/DashboardPage';
import { AITutorPage } from './pages/AITutorPage';
import { StudyAdvisorPage } from './pages/StudyAdvisorPage';
import { QuizPage } from './pages/QuizPage';
import { StudyPlannerPage } from './pages/StudyPlannerPage';
import { LearningProgressPage } from './pages/LearningProgressPage';
import { AchievementsPage } from './pages/AchievementsPage';
import { SmartRevisionPage } from './pages/SmartRevisionPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { SettingsPage } from './pages/SettingsPage';
import { DoubtAnalytics } from './components/DoubtAnalytics';
import { Subject, Question } from './types';
import { getSubjects, DEFAULT_SUBJECTS } from './services/subjectService';

function MainApp() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [activeQuestionId, setActiveQuestionId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('all');
  const [subjects, setSubjects] = useState<Subject[]>(DEFAULT_SUBJECTS);
  const [tutorInitialPrompt, setTutorInitialPrompt] = useState<string | undefined>(undefined);

  // Modals
  const [isAskModalOpen, setIsAskModalOpen] = useState(false);
  const [reportConfig, setReportConfig] = useState<{
    isOpen: boolean;
    contentType: 'question' | 'answer';
    contentId: string;
    contentSnippet?: string;
  }>({
    isOpen: false,
    contentType: 'question',
    contentId: '',
  });

  // Load subjects
  useEffect(() => {
    getSubjects().then(subs => {
      if (subs && subs.length > 0) setSubjects(subs);
    });
  }, []);

  // Handle browser URL hash for direct links like #question/xyz
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash.startsWith('question/')) {
        const qId = hash.replace('question/', '');
        setActiveQuestionId(qId);
        setCurrentPage('question');
      } else if (hash === 'dashboard') {
        setCurrentPage('dashboard');
      } else if (hash === 'tutor' || hash === 'ai-tutor') {
        setCurrentPage('tutor');
      } else if (hash === 'revision' || hash === 'flashcards') {
        setCurrentPage('revision');
      } else if (hash === 'leaderboard' || hash === 'rankings') {
        setCurrentPage('leaderboard');
      } else if (hash === 'settings' || hash === 'preferences') {
        setCurrentPage('settings');
      } else if (hash === 'advisor' || hash === 'study-advisor') {
        setCurrentPage('advisor');
      } else if (hash === 'quiz' || hash === 'ai-quiz') {
        setCurrentPage('quiz');
      } else if (hash === 'planner' || hash === 'study-planner') {
        setCurrentPage('planner');
      } else if (hash === 'progress' || hash === 'learning-progress') {
        setCurrentPage('progress');
      } else if (hash === 'achievements' || hash === 'badges') {
        setCurrentPage('achievements');
      } else if (hash === 'activity') {
        setCurrentPage('activity');
      } else if (hash === 'admin') {
        setCurrentPage('admin');
      } else if (hash === 'analytics' || hash === 'doubt-analytics') {
        setCurrentPage('analytics');
      } else if (hash === 'mentors') {
        setCurrentPage('mentors');
      } else if (hash === 'subjects') {
        setCurrentPage('subjects');
      } else {
        setCurrentPage('home');
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (page: string, params?: { prompt?: string }) => {
    if (params?.prompt) {
      setTutorInitialPrompt(params.prompt);
    }
    window.location.hash = page === 'home' ? '' : page;
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openQuestionDetail = (qId: string) => {
    setActiveQuestionId(qId);
    window.location.hash = `question/${qId}`;
    setCurrentPage('question');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenReport = (
    contentType: 'question' | 'answer',
    contentId: string,
    snippet?: string
  ) => {
    setReportConfig({
      isOpen: true,
      contentType,
      contentId,
      contentSnippet: snippet,
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Firebase Setup status banner */}
      <FirebaseSetupBanner />

      {/* Main Navigation */}
      <Navbar
        searchQuery={searchQuery}
        onSearchChange={val => {
          setSearchQuery(val);
          if (currentPage !== 'home') navigateTo('home');
        }}
        onOpenAskModal={() => setIsAskModalOpen(true)}
        currentPage={currentPage}
        onNavigate={navigateTo}
      />

      {/* Page Routing */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            subjects={subjects}
            selectedSubjectId={selectedSubjectId}
            onSelectSubject={id => setSelectedSubjectId(id)}
            searchQuery={searchQuery}
            onOpenQuestion={openQuestionDetail}
            onOpenAskModal={() => setIsAskModalOpen(true)}
            onOpenReport={q => handleOpenReport('question', q.questionId, q.title)}
            onNavigate={navigateTo}
          />
        )}

        {currentPage === 'question' && activeQuestionId && (
          <QuestionDetailPage
            questionId={activeQuestionId}
            onBack={() => navigateTo('home')}
            onOpenReport={(type, id, snippet) => handleOpenReport(type, id, snippet)}
          />
        )}

        {currentPage === 'dashboard' && (
          <DashboardPage
            onNavigateToAdvisor={() => navigateTo('advisor')}
            onNavigateToQuiz={() => navigateTo('quiz')}
            onNavigateToPlanner={() => navigateTo('planner')}
            onNavigateToTutor={(prompt?: string) => navigateTo('tutor', { prompt })}
            onNavigateToProgress={() => navigateTo('progress')}
            onNavigateToRevision={() => navigateTo('revision')}
            onNavigateToLeaderboard={() => navigateTo('leaderboard')}
            onOpenQuestion={openQuestionDetail}
            onOpenAskModal={() => setIsAskModalOpen(true)}
          />
        )}

        {currentPage === 'tutor' && (
          <AITutorPage
            onNavigateToQuiz={() => navigateTo('quiz')}
            onNavigateToAdvisor={() => navigateTo('advisor')}
            initialPrompt={tutorInitialPrompt}
          />
        )}

        {currentPage === 'revision' && (
          <SmartRevisionPage
            onNavigateToTutor={prompt => navigateTo('tutor', { prompt })}
          />
        )}

        {currentPage === 'leaderboard' && (
          <LeaderboardPage />
        )}

        {currentPage === 'settings' && (
          <SettingsPage />
        )}

        {currentPage === 'advisor' && (
          <StudyAdvisorPage
            onNavigateToPlanner={() => navigateTo('planner')}
          />
        )}

        {currentPage === 'quiz' && (
          <QuizPage
            onNavigateToProgress={() => navigateTo('progress')}
          />
        )}

        {currentPage === 'planner' && (
          <StudyPlannerPage />
        )}

        {currentPage === 'progress' && (
          <LearningProgressPage
            onNavigateToQuiz={() => navigateTo('quiz')}
            onNavigateToTutor={() => navigateTo('tutor')}
          />
        )}

        {currentPage === 'achievements' && (
          <AchievementsPage />
        )}

        {currentPage === 'activity' && (
          <MyActivityPage
            onOpenQuestion={openQuestionDetail}
            onOpenAskModal={() => setIsAskModalOpen(true)}
          />
        )}

        {currentPage === 'admin' && (
          <AdminDashboardPage onOpenQuestion={openQuestionDetail} />
        )}

        {currentPage === 'analytics' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <DoubtAnalytics onOpenQuestion={openQuestionDetail} />
          </div>
        )}

        {currentPage === 'mentors' && (
          <MentorsPage onOpenAskModal={() => setIsAskModalOpen(true)} />
        )}

        {currentPage === 'subjects' && (
          <SubjectsPage
            subjects={subjects}
            onSelectSubjectAndNavigate={id => {
              setSelectedSubjectId(id);
              navigateTo('home');
            }}
            onOpenAskModal={() => setIsAskModalOpen(true)}
          />
        )}
      </main>

      {/* Modals & Drawers */}
      <AuthModal />

      <AskDoubtModal
        isOpen={isAskModalOpen}
        onClose={() => setIsAskModalOpen(false)}
        subjects={subjects}
        onQuestionCreated={qId => openQuestionDetail(qId)}
      />

      <ReportModal
        isOpen={reportConfig.isOpen}
        onClose={() => setReportConfig(prev => ({ ...prev, isOpen: false }))}
        contentType={reportConfig.contentType}
        contentId={reportConfig.contentId}
        contentSnippet={reportConfig.contentSnippet}
      />

      <NotificationDrawer onSelectQuestion={openQuestionDetail} />

      {/* Global Footer */}
      <Footer onNavigate={navigateTo} />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <SettingsProvider>
        <AuthProvider>
          <NotificationProvider>
            <MainApp />
          </NotificationProvider>
        </AuthProvider>
      </SettingsProvider>
    </ThemeProvider>
  );
}
