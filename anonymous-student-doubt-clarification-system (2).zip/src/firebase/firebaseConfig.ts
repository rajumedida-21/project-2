import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDocFromServer } from 'firebase/firestore';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import { initializeAppCheck, ReCaptchaEnterpriseProvider, AppCheck } from 'firebase/app-check';

export interface FirebaseCustomConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId: string;
  firestoreDatabaseId?: string;
  appCheckKey?: string;
}

const LOCAL_STORAGE_KEY = 'doubt_clarification_firebase_config';

export function getStoredFirebaseConfig(): FirebaseCustomConfig | null {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.warn('Failed to parse stored Firebase config', e);
  }
  return null;
}

export function saveStoredFirebaseConfig(config: FirebaseCustomConfig) {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(config));
  window.location.reload();
}

export function clearStoredFirebaseConfig() {
  localStorage.removeItem(LOCAL_STORAGE_KEY);
  window.location.reload();
}

const clean = (val?: string | null): string => {
  if (!val) return '';
  return val.replace(/^["'\s]+|["',\s]+$/g, '').trim();
};

// 1. Check environment variables
const envConfig: FirebaseCustomConfig = {
  apiKey: clean(import.meta.env.VITE_FIREBASE_API_KEY),
  authDomain: clean(import.meta.env.VITE_FIREBASE_AUTH_DOMAIN),
  projectId: clean(import.meta.env.VITE_FIREBASE_PROJECT_ID),
  storageBucket: clean(import.meta.env.VITE_FIREBASE_STORAGE_BUCKET),
  messagingSenderId: clean(import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID),
  appId: clean(import.meta.env.VITE_FIREBASE_APP_ID),
  appCheckKey: clean(import.meta.env.VITE_FIREBASE_APPCHECK_KEY) || '6LdmFLQtAAAAAPtbHTcj3NHZZZVZiu17DuDaVoGZ',
};

// 2. Check localStorage override
const storedConfig = getStoredFirebaseConfig();

export const activeFirebaseConfig: FirebaseCustomConfig = {
  apiKey: clean(storedConfig?.apiKey) || envConfig.apiKey,
  authDomain: clean(storedConfig?.authDomain) || envConfig.authDomain,
  projectId: clean(storedConfig?.projectId) || envConfig.projectId,
  storageBucket: clean(storedConfig?.storageBucket) || envConfig.storageBucket,
  messagingSenderId: clean(storedConfig?.messagingSenderId) || envConfig.messagingSenderId,
  appId: clean(storedConfig?.appId) || envConfig.appId,
  firestoreDatabaseId: storedConfig?.firestoreDatabaseId || '(default)',
  appCheckKey: clean(storedConfig?.appCheckKey) || envConfig.appCheckKey || '6LdmFLQtAAAAAPtbHTcj3NHZZZVZiu17DuDaVoGZ',
};

export const isFirebaseConfigured = Boolean(
  activeFirebaseConfig.apiKey &&
  activeFirebaseConfig.projectId &&
  activeFirebaseConfig.appId &&
  !activeFirebaseConfig.apiKey.includes('YOUR_') &&
  !activeFirebaseConfig.projectId.includes('YOUR_')
);

let appInstance: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;
let storageInstance: FirebaseStorage | null = null;
let appCheckInstance: AppCheck | null = null;

if (isFirebaseConfigured) {
  try {
    appInstance = getApps().length > 0 ? getApp() : initializeApp(activeFirebaseConfig);
    authInstance = getAuth(appInstance);
    dbInstance = getFirestore(appInstance);

    // Initialize App Check with reCAPTCHA Enterprise key
    try {
      const siteKey = activeFirebaseConfig.appCheckKey || '6LdmFLQtAAAAAPtbHTcj3NHZZZVZiu17DuDaVoGZ';
      if (typeof window !== 'undefined' && siteKey) {
        // Enable debug token in development mode if not already set
        if (import.meta.env.DEV && !(window as unknown as { FIREBASE_APPCHECK_DEBUG_TOKEN?: boolean | string }).FIREBASE_APPCHECK_DEBUG_TOKEN) {
          (window as unknown as { FIREBASE_APPCHECK_DEBUG_TOKEN?: boolean | string }).FIREBASE_APPCHECK_DEBUG_TOKEN = true;
        }

        appCheckInstance = initializeAppCheck(appInstance, {
          provider: new ReCaptchaEnterpriseProvider(siteKey),
          isTokenAutoRefreshEnabled: true,
        });
        console.log('Firebase App Check initialized successfully with reCAPTCHA Enterprise');
      }
    } catch (appCheckErr) {
      console.warn('Firebase App Check initialization skipped or warning:', appCheckErr);
    }

    try {
      storageInstance = getStorage(appInstance);
    } catch {
      // Storage optional
    }
  } catch (err) {
    console.error('Failed to initialize Firebase SDK with current config:', err);
  }
}

export const app = appInstance as FirebaseApp;
export const auth = authInstance as Auth;
export const db = dbInstance as Firestore;
export const storage = storageInstance as FirebaseStorage;
export const appCheck = appCheckInstance as AppCheck | null;

// Connection validation mandated by Firebase skill
export async function validateFirestoreConnection(): Promise<{ success: boolean; message: string }> {
  if (!isFirebaseConfigured || !dbInstance) {
    return {
      success: false,
      message: 'Firebase configuration is missing or incomplete.',
    };
  }

  try {
    await getDocFromServer(doc(dbInstance, 'test', 'connection'));
    return { success: true, message: 'Connected to Firestore successfully.' };
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      return { success: false, message: 'Please check your Firebase configuration or internet connection (client is offline).' };
    }
    // Any other error like permission-denied is fine because 'test/connection' doc doesn't exist and rules may deny it
    return { success: true, message: 'Firestore instance initialized.' };
  }
}
