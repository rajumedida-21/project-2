import { useState, useEffect, useRef, useCallback } from 'react';
import { SupportedLanguage } from '../types';

export function useTextToSpeech() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentTextId, setCurrentTextId] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(false);

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    setIsSupported(typeof window !== 'undefined' && 'speechSynthesis' in window);

    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const cleanMarkdownForSpeech = (text: string): string => {
    return text
      .replace(/```[\s\S]*?```/g, ' Code snippet omitted for audio reading. ') // skip large code blocks in speech
      .replace(/`([^`]+)`/g, '$1') // inline code
      .replace(/#{1,6}\s+/g, '') // headers
      .replace(/\*\*([^*]+)\*\*/g, '$1') // bold
      .replace(/\*([^*]+)\*/g, '$1') // italic
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // links
      .replace(/>\s+/g, '') // quotes
      .replace(/[-*+]\s+/g, '') // bullets
      .replace(/\n{2,}/g, '. ') // newlines to pause
      .replace(/\n/g, ' ')
      .trim();
  };

  const speak = useCallback((
    text: string,
    id: string,
    language: SupportedLanguage = 'English',
    rate: number = 1.0,
    pitch: number = 1.0
  ) => {
    if (!isSupported) return;

    window.speechSynthesis.cancel();

    const cleanedText = cleanMarkdownForSpeech(text);
    if (!cleanedText) return;

    const utterance = new SpeechSynthesisUtterance(cleanedText);
    utterance.rate = rate;
    utterance.pitch = pitch;

    // Pick voice
    const voices = window.speechSynthesis.getVoices();
    let selectedVoice: SpeechSynthesisVoice | undefined;

    if (language === 'Telugu') {
      utterance.lang = 'te-IN';
      selectedVoice = voices.find(v => v.lang.startsWith('te') || v.name.toLowerCase().includes('telugu'));
    } else if (language === 'Hindi') {
      utterance.lang = 'hi-IN';
      selectedVoice = voices.find(v => v.lang.startsWith('hi') || v.name.toLowerCase().includes('hindi'));
    } else {
      utterance.lang = 'en-US';
      selectedVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha')));
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    utterance.onstart = () => {
      setIsPlaying(true);
      setIsPaused(false);
      setCurrentTextId(id);
    };

    utterance.onend = () => {
      setIsPlaying(false);
      setIsPaused(false);
      setCurrentTextId(null);
    };

    utterance.onerror = (e) => {
      console.warn('Speech synthesis error:', e);
      setIsPlaying(false);
      setIsPaused(false);
      setCurrentTextId(null);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [isSupported]);

  const pause = useCallback(() => {
    if (!isSupported) return;
    if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  }, [isSupported]);

  const resume = useCallback(() => {
    if (!isSupported) return;
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    }
  }, [isSupported]);

  const stop = useCallback(() => {
    if (!isSupported) return;
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    setIsPaused(false);
    setCurrentTextId(null);
  }, [isSupported]);

  return {
    isSupported,
    isPlaying,
    isPaused,
    currentTextId,
    speak,
    pause,
    resume,
    stop,
  };
}
