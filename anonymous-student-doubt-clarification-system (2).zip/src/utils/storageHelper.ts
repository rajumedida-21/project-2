import { storage } from '../firebase/firebaseConfig';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export async function processImageUpload(file: File): Promise<string> {
  // Compress image client side if larger than 1MB
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const img = new Image();
      img.onload = async () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1200;
        const MAX_HEIGHT = 1200;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.82);

        // If Firebase Storage is available and configured, upload to storage
        if (storage && storage.app) {
          try {
            const blob = await (await fetch(compressedDataUrl)).blob();
            const storageRef = ref(storage, `doubt_attachments/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`);
            const snapshot = await uploadBytes(storageRef, blob);
            const downloadUrl = await getDownloadURL(snapshot.ref);
            resolve(downloadUrl);
            return;
          } catch (storageErr) {
            console.warn('Firebase Storage upload failed, falling back to embedded image data URL:', storageErr);
            resolve(compressedDataUrl);
            return;
          }
        }

        // Fallback: return compressed base64 data URL
        resolve(compressedDataUrl);
      };

      img.onerror = () => reject(new Error('Invalid image file'));
      img.src = e.target?.result as string;
    };

    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}
