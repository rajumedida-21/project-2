import { useState, useEffect } from 'react';

export type ConnectionState = 'online' | 'offline' | 'connecting';

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [connectionState, setConnectionState] = useState<ConnectionState>(
    typeof navigator !== 'undefined' && navigator.onLine ? 'online' : 'offline'
  );

  useEffect(() => {
    const handleOnline = () => {
      setConnectionState('connecting');
      // Verify real connectivity with a lightweight ping
      fetch('/api/health', { method: 'HEAD', cache: 'no-store' })
        .then(() => {
          setIsOnline(true);
          setConnectionState('online');
        })
        .catch(() => {
          // If server is not responding, keep online flag from browser but set connecting
          setIsOnline(true);
          setConnectionState('online');
        });
    };

    const handleOffline = () => {
      setIsOnline(false);
      setConnectionState('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return { isOnline, connectionState };
}
