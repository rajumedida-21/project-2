import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createPNG(width, height, r1, g1, b1, r2, g2, b2) {
  // Raw image data with 1 byte filter per scanline
  const rowSize = width * 4 + 1;
  const rawData = Buffer.alloc(rowSize * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter: None
    const t = y / height;
    const r = Math.round(r1 * (1 - t) + r2 * t);
    const g = Math.round(g1 * (1 - t) + g2 * t);
    const b = Math.round(b1 * (1 - t) + b2 * t);

    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      // Draw centered circular cap emblem
      const cx = width / 2;
      const cy = height / 2;
      const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
      const radius = width * 0.38;

      if (dist < radius) {
        // Inner badge
        const innerT = Math.max(0, Math.min(1, (x - (cx - radius)) / (radius * 2)));
        rawData[pixelOffset] = Math.round(79 * (1 - innerT) + 124 * innerT);     // #4F46E5 to #7C3AED
        rawData[pixelOffset + 1] = Math.round(70 * (1 - innerT) + 58 * innerT);
        rawData[pixelOffset + 2] = Math.round(229 * (1 - innerT) + 237 * innerT);
        rawData[pixelOffset + 3] = 255;
      } else {
        rawData[pixelOffset] = r;
        rawData[pixelOffset + 1] = g;
        rawData[pixelOffset + 2] = b;
        rawData[pixelOffset + 3] = 255;
      }
    }
  }

  const compressedData = zlib.deflateSync(rawData);

  // Helper to make chunk
  function makeChunk(type, data) {
    const len = data.length;
    const buf = Buffer.alloc(len + 12);
    buf.writeUInt32BE(len, 0);
    buf.write(type, 4, 4, 'ascii');
    data.copy(buf, 8);

    // CRC32
    let c = 0xffffffff;
    for (let i = 4; i < len + 8; i++) {
      c = updateCRC(c, buf[i]);
    }
    c = (c ^ 0xffffffff) >>> 0;
    buf.writeUInt32BE(c, len + 8);
    return buf;
  }

  // Precomputed CRC table
  const crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    crcTable[n] = c;
  }
  function updateCRC(c, byte) {
    return crcTable[(c ^ byte) & 0xff] ^ (c >>> 8);
  }

  // PNG Header
  const header = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // Bit depth
  ihdr[9] = 6; // Color type (RGBA)
  ihdr[10] = 0; // Compression
  ihdr[11] = 0; // Filter
  ihdr[12] = 0; // Interlace
  const ihdrChunk = makeChunk('IHDR', ihdr);

  // IDAT
  const idatChunk = makeChunk('IDAT', compressedData);

  // IEND
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([header, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.join(process.cwd(), 'public');
if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });

// Generate 192x192
const png192 = createPNG(192, 192, 15, 23, 42, 30, 41, 59);
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), png192);

// Generate 512x512
const png512 = createPNG(512, 512, 15, 23, 42, 30, 41, 59);
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), png512);

// Generate maskable 512x512
const maskable512 = createPNG(512, 512, 79, 70, 229, 124, 58, 237);
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), maskable512);

// Apple touch icon 180x180
const apple180 = createPNG(180, 180, 79, 70, 229, 124, 58, 237);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), apple180);

// SVG Brand Icon
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#4F46E5"/>
      <stop offset="100%" stop-color="#7C3AED"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="128" fill="url(#grad)"/>
  <path d="M256 128L80 224L256 320L432 224L256 128Z" fill="#FFFFFF"/>
  <path d="M128 260V340C128 380 185 412 256 412C327 412 384 380 384 340V260L256 330L128 260Z" fill="#E0E7FF"/>
  <path d="M432 224V320" stroke="#FDE047" stroke-width="16" stroke-linecap="round"/>
</svg>`;
fs.writeFileSync(path.join(publicDir, 'icon.svg'), svg);

console.log('Successfully generated PWA icon assets in /public');
